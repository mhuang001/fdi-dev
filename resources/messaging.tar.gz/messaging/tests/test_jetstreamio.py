"""
JetStreamIo test file
"""
import logging
import os
import sys
import types
import time
from unittest import mock
from nats.aio.client import Client as NATS
import pytest

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
from package.svom.messaging.jetstreamio import JetStreamIo

log = logging.getLogger("test_natsio")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)


@pytest.fixture(
    scope="module",
    params=[
        {"host": "48.15.16.23", "port": "42"},
        {"host": "48.15.16.23", "port": 42},
        {"host": "48.15.16.23:42"},
        {"host": "nats://48.15.16.23:42"},
    ],
)
def host_port_(request):
    """return host (and port) as dict"""
    return request.param


FAIL_NB = 0
MAX_FAIL = 2


def status_side_effect(*args, **kwargs):  # pylint: disable = unused-argument
    """returns 'disconnected' {max_fail} times then 'connected'"""
    global FAIL_NB
    global MAX_FAIL
    if FAIL_NB == MAX_FAIL:
        return "connected"
    FAIL_NB += 1
    return "disconnected"


def nats_init_side_effect(*args, **kwargs):  # pylint: disable = unused-argument
    cli = NATS()
    cli._current_server = mock.MagicMock()
    return cli


def test_hostport_init(host_port_):  # pylint: disable=redefined-outer-name
    """test connect on init with various ways of passing host and port"""
    global FAIL_NB
    global MAX_FAIL
    FAIL_NB = 0
    MAX_FAIL = 2

    # JetStreamIo will be initialized using a new not running async loop
    # the connection should be done through a run_until_complete call in
    # a dedicated thread
    conn_patch = "nats.aio.client.Client.connect"
    status_patch = "package.svom.messaging.jetstreamio.JetStreamIo._nats_status"
    flush_patch = "nats.aio.client.Client.flush"
    pend_patch = "nats.aio.client.Client._flush_pending"
    serv_patch = "package.svom.messaging.jetstreamio.NATS"
    with mock.patch(conn_patch, return_value=None) as conn_mock, mock.patch(
        serv_patch, side_effect=nats_init_side_effect
    ), mock.patch(
        status_patch, side_effect=status_side_effect
    ) as status_mock, mock.patch(
        flush_patch, return_value=None
    ) as flush_mock, mock.patch(
        pend_patch, return_value=None
    ) as pend_mock:
        # init client and check thread was created and running
        client = JetStreamIo(**host_port_)
        # fake NATS connection
        # client._nats._status = 1
        # client._nats._current_server = mock.MagicMock()
        # client._nats._current_server.uri.geturl.return_value = 'nats://48.15.16.23:42'
        assert client.thread is not None
        assert client.thread.is_alive()
        # stop client right away to force all futures to finish
        client.is_connecting = False
        client.stop()
        # check thread was stopped and thread dieded
        time.sleep(0.5)
        assert not client.loop.is_running()
        assert not client.thread.is_alive()
        # check connect call was the right ones
        expected_kwargs = {
            "servers": ["nats://48.15.16.23:42"],
            "user": None,
            "password": None,
            "loop": client.loop,
            "error_cb": client._on_nats_error,
            "disconnected_cb": client._on_nats_disconnect,
            "reconnected_cb": client._on_nats_reconnect,
            "allow_reconnect": True,
            "max_reconnect_attempts": 5,
        }
        conn_mock.assert_called_once_with(**expected_kwargs)


@pytest.mark.asyncio
async def test_loop_init(event_loop):  # pylint: disable=redefined-outer-name
    """test init with loop argument"""
    global FAIL_NB
    global MAX_FAIL
    FAIL_NB = 0
    MAX_FAIL = 2

    # JetStreamIo will be initialized using already running {event_loop}
    # the connection should be done through a run_coroutine_threadsafe call
    coro_patch = "asyncio.run_coroutine_threadsafe"
    conn_patch = "nats.aio.client.Client.connect"
    status_patch = "package.svom.messaging.jetstreamio.JetStreamIo._nats_status"
    flush_patch = "nats.aio.client.Client.flush"
    pend_patch = "nats.aio.client.Client._flush_pending"
    serv_patch = "package.svom.messaging.jetstreamio.NATS"
    with mock.patch(coro_patch) as coro_mock, mock.patch(
        conn_patch, return_value=None
    ) as conn_mock, mock.patch(
        serv_patch, side_effect=nats_init_side_effect
    ), mock.patch(
        status_patch, side_effect=status_side_effect
    ) as status_mock, mock.patch(
        flush_patch, return_value=None
    ) as flush_mock, mock.patch(
        pend_patch, return_value=None
    ) as pend_mock:
        coro_mock.assert_not_called()
        conn_mock.assert_not_called()
        # init client with already running loop
        client = JetStreamIo(
            host="nats://48.15.16.23:42", streaming_id="id", loop=event_loop
        )
        # check run_coroutine_threadsafe was called
        coro_mock.assert_called_once()
        assert "JetStreamIo._connect" in repr(coro_mock.mock_calls[0][1][0])
        # actually await _connect coroutine (since run_coroutine_threadsafe was mocked)
        await coro_mock.mock_calls[0][1][0]
        # check client has no thread
        assert client.thread is None


@pytest.mark.asyncio
async def test_max_reconnect_init(event_loop):  # pylint: disable=redefined-outer-name
    """test init with max_reconnect_attempts argument"""
    global FAIL_NB
    global MAX_FAIL
    FAIL_NB = 0
    MAX_FAIL = 4

    # JetStreamIo will be initialized using already running {event_loop}
    # the connection should be done through a run_coroutine_threadsafe call
    coro_patch = "asyncio.run_coroutine_threadsafe"
    conn_patch = "nats.aio.client.Client.connect"
    status_patch = "package.svom.messaging.jetstreamio.JetStreamIo._nats_status"
    flush_patch = "nats.aio.client.Client.flush"
    pend_patch = "nats.aio.client.Client._flush_pending"
    serv_patch = "package.svom.messaging.jetstreamio.NATS"
    with mock.patch(coro_patch) as coro_mock, mock.patch(
        serv_patch, side_effect=nats_init_side_effect
    ), mock.patch(conn_patch, return_value=None) as conn_mock, mock.patch(
        status_patch, side_effect=status_side_effect
    ) as status_mock, mock.patch(
        flush_patch, return_value=None
    ) as flush_mock, mock.patch(
        pend_patch, return_value=None
    ) as pend_mock:
        coro_mock.assert_not_called()
        conn_mock.assert_not_called()
        # init client with already running loop
        client = JetStreamIo(
            host="nats://48.15.16.23:42", streaming_id="id", max_reconnect_attempts=666
        )
        # check run_coroutine_threadsafe was called
        coro_mock.assert_called_once()
        assert "JetStreamIo._connect" in repr(coro_mock.mock_calls[0][1][0])
        # actually await _connect coroutine (since run_coroutine_threadsafe was mocked)
        await coro_mock.mock_calls[0][1][0]
        conn_mock.assert_called_once()
        assert conn_mock.mock_calls[0][2]["max_reconnect_attempts"] == 666
        # check client has no thread
        assert client.thread is None


@pytest.mark.asyncio
async def test_callbacks(event_loop):  # pylint: disable=redefined-outer-name
    """test connect on init with various ways of passing host and port"""
    global FAIL_NB
    global MAX_FAIL
    FAIL_NB = 0
    MAX_FAIL = 0

    conn_patch = "package.svom.messaging.jetstreamio.JetStreamIo._connect"
    pend_patch = "nats.aio.client.Client._flush_pending"
    url_patch = "nats.aio.client.Client.connected_url"
    log_patch = "package.svom.messaging.jetstreamio.log.info"
    err_patch = "package.svom.messaging.jetstreamio.log.error"
    serv_patch = "package.svom.messaging.jetstreamio.NATS"
    with mock.patch(conn_patch, return_value=None) as conn_mock, mock.patch(
        serv_patch, side_effect=nats_init_side_effect
    ), mock.patch(pend_patch, return_value=None) as pend_mock, mock.patch(
        url_patch, return_value=None
    ), mock.patch(
        log_patch, return_value=None
    ) as log_mock, mock.patch(
        err_patch, return_value=None
    ) as err_mock:
        # init client
        client = JetStreamIo(
            host="nats://48.15.16.23:42", streaming_id="id", loop=event_loop
        )
        # fake NATS connection
        conn_mock.assert_called_once_with(servers=["nats://48.15.16.23:42"])
        client._nats._status = 1
        client._nats._current_server = mock.MagicMock()
        client._nats._current_server.uri.geturl.return_value = "nats://48.15.16.23:42"
        # check log length before testing
        before_test = len(log_mock.mock_calls)
        # nothing bad should happen but logger should be called
        await client._on_nats_reconnect()
        assert len(log_mock.mock_calls) == before_test + 1
        # nothing bad should happen but logger should be called
        err_mock.assert_not_called()
        await client._on_nats_disconnect()
        err_mock.assert_called_once()
        # on auth violation reconnect should be disabled
        await client._on_nats_error(RuntimeError("Authorization Violation"))
        assert client._nats.options["allow_reconnect"] is False
        # close nats client
        await client._nats.close()


@pytest.mark.asyncio
async def test_get_status(event_loop):  # pylint: disable=redefined-outer-name
    """test connect on init with various ways of passing host and port"""
    global FAIL_NB
    global MAX_FAIL
    FAIL_NB = 0
    MAX_FAIL = 0

    conn_patch = "package.svom.messaging.jetstreamio.JetStreamIo._connect"
    pend_patch = "nats.aio.client.Client._flush_pending"
    url_patch = "nats.aio.client.Client.connected_url"
    sub_patch = "nats.aio.client.Client.subscribe"
    serv_patch = "package.svom.messaging.jetstreamio.NATS"
    with mock.patch(conn_patch, return_value=None) as conn_mock, mock.patch(
        serv_patch, side_effect=nats_init_side_effect
    ), mock.patch(pend_patch, return_value=None) as pend_mock, mock.patch(
        url_patch, return_value=None
    ), mock.patch(
        sub_patch, return_value=None
    ) as sub_mock:
        # init client
        client = JetStreamIo(
            host="nats://48.15.16.23:42", streaming_id="id", loop=event_loop
        )
        # fake NATS connection
        conn_mock.assert_called_once_with(servers=["nats://48.15.16.23:42"])
        client._nats._status = 1
        # check get_server_status return values
        assert client.get_server_status() == "connected"
        await client._nats.close()
        assert client.get_server_status() == "closed"


def test_jetstream_pubsub():
    """test JetStream publishing/subscription"""

    async def fake_reaction(msg):
        print(msg.data)

    nats_resp = types.SimpleNamespace()
    nats_resp.data = b'{"created": {"this": "is ok"}}'

    global FAIL_NB
    global MAX_FAIL
    FAIL_NB = 0
    MAX_FAIL = 0
    conn_patch = "package.svom.messaging.jetstreamio.JetStreamIo._connect"
    pend_patch = "nats.aio.client.Client._flush_pending"
    sub_patch = "nats.aio.client.Client.subscribe"
    req_patch = "nats.aio.client.Client.request"
    serv_patch = "package.svom.messaging.jetstreamio.NATS"
    with mock.patch(conn_patch, return_value=None) as conn_mock, mock.patch(
        serv_patch, side_effect=nats_init_side_effect
    ), mock.patch(pend_patch, return_value=None) as pend_mock, mock.patch(
        sub_patch, return_value=None
    ) as sub_mock, mock.patch(
        req_patch, return_value=nats_resp
    ) as req_mock:
        # init client
        client = JetStreamIo(host="nats://48.15.16.23:42", streaming_id="id")
        # fake NATS connection
        conn_mock.assert_called_once_with(servers=["nats://48.15.16.23:42"])
        client._nats._status = 1
        client._nats.options = {"max_reconnect_attempts": 5}
        try:
            client.subscribe("sub_test", fake_reaction)
            client.publish("pub_test", "the cake is a LIE")
        finally:
            client.is_connecting = False
            client.stop()
        # three requests for consumer info + consumer creation + publication
        expected_calls = [
            mock.call("$JS.API.CONSUMER.INFO.sub_test.sub_test_id", b""),
            mock.call(
                "$JS.API.CONSUMER.DURABLE.CREATE.sub_test.sub_test_id",
                b'{"stream_name": "sub_test", "config": {"durable_name": "sub_test_id", '
                b'"deliver_subject": "sub_test.id", "deliver_policy": "last", "ack_policy": '
                b'"none", "max_deliver": -1, "filter_subject": "sub_test", "replay_policy": '
                b'"instant"}}',
            ),
            mock.call("pub_test", b"the cake is a LIE"),
        ]
        assert req_mock.mock_calls == expected_calls
        sub_mock.assert_called_once_with("sub_test.id", cb=fake_reaction)


def test_nats_pubsub():
    """test NATS publishing/subscription"""

    async def fake_reaction(msg):
        print(msg.data)

    global FAIL_NB
    global MAX_FAIL
    FAIL_NB = 0
    MAX_FAIL = 0
    conn_patch = "package.svom.messaging.jetstreamio.JetStreamIo._connect"
    pend_patch = "nats.aio.client.Client._flush_pending"
    sub_patch = "nats.aio.client.Client.subscribe"
    pub_patch = "nats.aio.client.Client.publish"
    serv_patch = "package.svom.messaging.jetstreamio.NATS"
    with mock.patch(conn_patch, return_value=None) as conn_mock, mock.patch(
        serv_patch, side_effect=nats_init_side_effect
    ), mock.patch(pend_patch, return_value=None) as pend_mock, mock.patch(
        sub_patch, return_value=None
    ) as sub_mock, mock.patch(
        pub_patch, return_value=None
    ) as pub_mock:
        # init client
        client = JetStreamIo(host="nats://48.15.16.23:42")
        # fake NATS connection
        conn_mock.assert_called_once_with(servers=["nats://48.15.16.23:42"])
        client._nats._status = 1
        try:
            client.subscribe("sub_test", fake_reaction)
            client.publish("pub_test", "the cake is a LIE")
        finally:
            client.is_connecting = False
            client.stop()
        sub_mock.assert_called_once_with("sub_test", cb=fake_reaction)
        pub_mock.assert_called_once_with("pub_test", b"the cake is a LIE")


def test_jetstream_create_stream():
    """test JetStream create stream method"""
    nats_resp = types.SimpleNamespace()
    nats_resp.data = b'{"request_return": {"this": "should create"}}'

    global FAIL_NB
    global MAX_FAIL
    FAIL_NB = 0
    MAX_FAIL = 0
    conn_patch = "package.svom.messaging.jetstreamio.JetStreamIo._connect"
    pend_patch = "nats.aio.client.Client._flush_pending"
    req_patch = "nats.aio.client.Client.request"
    serv_patch = "package.svom.messaging.jetstreamio.NATS"
    with mock.patch(conn_patch, return_value=None) as conn_mock, mock.patch(
        serv_patch, side_effect=nats_init_side_effect
    ), mock.patch(pend_patch, return_value=None) as pend_mock, mock.patch(
        req_patch, return_value=nats_resp
    ) as req_mock:
        # init client
        client = JetStreamIo(host="nats://48.15.16.23:42")
        # fake NATS connection
        conn_mock.assert_called_once_with(servers=["nats://48.15.16.23:42"])
        client._nats._status = 1
        try:
            client.create_or_update_stream(name="my_stream", subjects="all_subs")
        finally:
            client.is_connecting = False
            client.stop()
        # two request calls  should have been made
        assert len(req_mock.mock_calls) == 2
        # one call for retrieving existing stream names
        assert req_mock.mock_calls[0][1][0] == "$JS.API.STREAM.NAMES"
        # one call for creating new stream
        assert req_mock.mock_calls[1][1][0] == "$JS.API.STREAM.CREATE.my_stream"


def test_jetstream_update_stream():
    """test JetStream create stream method"""
    nats_resp = types.SimpleNamespace()
    nats_resp.data = (
        b'{"request_return": {"this": "should update"},' b'"streams": ["my_stream"]}'
    )
    global FAIL_NB
    global MAX_FAIL
    FAIL_NB = 0
    MAX_FAIL = 0
    conn_patch = "package.svom.messaging.jetstreamio.JetStreamIo._connect"
    pend_patch = "nats.aio.client.Client._flush_pending"
    req_patch = "nats.aio.client.Client.request"
    serv_patch = "package.svom.messaging.jetstreamio.NATS"
    with mock.patch(conn_patch, return_value=None) as conn_mock, mock.patch(
        serv_patch, side_effect=nats_init_side_effect
    ), mock.patch(pend_patch, return_value=None) as pend_mock, mock.patch(
        req_patch, return_value=nats_resp
    ) as req_mock:
        # init client
        client = JetStreamIo(host="nats://48.15.16.23:42")
        # fake NATS connection
        conn_mock.assert_called_once_with(servers=["nats://48.15.16.23:42"])
        client._nats._status = 1
        try:
            client.create_or_update_stream(name="my_stream", subjects="all_subs")
        finally:
            client.is_connecting = False
            client.stop()
        # two request calls  should have been made
        assert len(req_mock.mock_calls) == 2
        # one call for retrieving existing stream names
        assert req_mock.mock_calls[0][1][0] == "$JS.API.STREAM.NAMES"
        # one call for creating new stream
        assert req_mock.mock_calls[1][1][0] == "$JS.API.STREAM.UPDATE.my_stream"
