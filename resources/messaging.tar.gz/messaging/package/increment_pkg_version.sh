#!/bin/sh

current_version=$(grep -m 1 current_version .bumpversion.cfg | sed -r s,"^.*=",,)
echo $current_version

minor=$(echo $current_version | cut -d. -f2)
patch=$(echo $current_version | cut -d. -f3)
echo $minor
echo $patch

if [ $patch -eq 9 ]
then
    if [ $minor -eq 9 ]
    then
        increment="major"
    else
	increment="minor"
    fi
else
    increment="patch"
fi

echo $increment
bump2version $increment


#echo "Add a temporary remote, named CI_remote."
## Need to add a remote URL to not use the token used by the CI
## First try to add the remote and if already existing (when updating a MR) then
## make sure it points to corect URL by restting it.
git remote add CI_remote $MESSAGING_GIT_URL || git remote set-url CI_remote $MESSAGING_GIT_URL
echo "Do not pay attention of the message stating fatal error on line above, if any."
#
## Need to specify that the source branch from the CI is HEAD
## JSON and FITS are generated within the gitlab CI


echo " "
echo "Push changes to production branch."
git push CI_remote HEAD:$BRANCH_PROD || exit 1

echo " "
echo "Push changes to develop branch."
#Need to add the -f here in case we use the option squash the commit
git push -f CI_remote HEAD:$BRANCH_DEV || exit 1

echo " "
echo "Remove remote CI_remote."
# Remove remote CI_remote
git remote remove CI_remote
