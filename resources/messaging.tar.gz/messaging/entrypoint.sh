#!/bin/ash
#_____________________________________________________________________________
#
# Henri Louvin - September 2021
#
# Starts the NATS server and uses custom script for JetStream configuration
#_____________________________________________________________________________
set -e
if [ -z ${1} ]; then
    echo "--"
    echo 'Starting NATS+JetStream server in background'
    echo "--"
    nats-server -c /etc/server.cfg &
    # give time to server to start
    sleep 2
    if [ $(ps -o pid | grep \ $!$ | wc -l) -eq 0 ]; then
        # nats-server command finished meaning server failed to start
        echo "Server failed to start. Exiting"
        exit 1
    else
        # server is still running so it must have started okay
        echo "--"
        echo 'Executing configuration script'
        echo "--"
        python3 entrypoint.py
        # give time to entrypoint script to finish
        sleep 2
        [ $? -eq 0 ]  || exit 1
    fi
else
    exec "$@"
fi

# ---------------------------------------------------------------------------
