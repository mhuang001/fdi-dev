import connexion
import six

from swagger_server.models.generatebad import Generatebad  # noqa: E501
from swagger_server.models.generateok import Generateok  # noqa: E501
from swagger_server.models.hkdata import Hkdata  # noqa: E501
from swagger_server.models.hkdata_specific import HkdataSpecific  # noqa: E501
from swagger_server.models.product import Product  # noqa: E501
from swagger_server.models.productref import Productref  # noqa: E501
from swagger_server import util


def poolid_dataclass_index_delete(poolid, dataclass, index):  # noqa: E501
    """delete a data item from server

    delete specific data item from server by passing poolID, data class, and index # noqa: E501

    :param poolid: pool ID (also called pool name)
    :type poolid: str
    :param dataclass: type of data. e.g. names of software class or \&quot;card\&quot; name.
    :type dataclass: str
    :param index: unique serial number in the given data class of the data item
    :type index: int

    :rtype: None
    """
    return 'do some magic!'


def poolid_dataclass_index_get(poolid, dataclass, index):  # noqa: E501
    """Returns a data item in the pool.

    requests a data item in the pool by pool ID, data class and its index. # noqa: E501

    :param poolid: pool ID (also called pool name)
    :type poolid: str
    :param dataclass: type of data. e.g. names of software class or \&quot;card\&quot; name.
    :type dataclass: str
    :param index: unique serial number in the given data class of the data item
    :type index: int

    :rtype: Product
    """
    return 'do some magic!'


def poolid_dataclass_index_post(poolid, dataclass, index):  # noqa: E501
    """upload a data item to to the pool on the server

    upload a data item to the pool on the server # noqa: E501

    :param poolid: pool ID (also called pool name)
    :type poolid: str
    :param dataclass: type of data. e.g. names of software class or \&quot;card\&quot; name.
    :type dataclass: str
    :param index: unique serial number in the given data class of the data item
    :type index: int

    :rtype: Productref
    """
    return 'do some magic!'


def poolid_delete(poolid):  # noqa: E501
    """Removes all contents of the pool.

    requests all data in the pool be removed by passing pool ID. # noqa: E501

    :param poolid: pool ID (also called pool name)
    :type poolid: str

    :rtype: Generateok
    """
    return 'do some magic!'


def poolid_hk_get(poolid):  # noqa: E501
    """All kinds of pool housekeeping data.

    return all pool housekeeping data according to pool ID. # noqa: E501

    :param poolid: pool ID (also called pool name)
    :type poolid: str

    :rtype: Hkdata
    """
    return 'do some magic!'


def poolid_hk_kind_get(poolid, kind):  # noqa: E501
    """Returns the given kind of pool housekeeping.

    requests pool housekeeping data of specified kind: classes or urns or tags # noqa: E501

    :param poolid: pool ID (also called pool name)
    :type poolid: str
    :param kind: one of \&quot;classes\&quot;, \&quot;urns\&quot;, \&quot;tags\&quot; kinds.
    :type kind: str

    :rtype: HkdataSpecific
    """
    return 'do some magic!'
