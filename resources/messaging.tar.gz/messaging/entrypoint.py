#!/usr/bin/env python3
"""
 Configures JetStream server

 Henri Louvin - henri.louvin@cea.fr

"""

# System
import os
import sys
import time
import logging
import json
import asyncio
import subprocess
from nats.aio.errors import ErrTimeout

# Svom
from svom.messaging import jetstreamio_from_env

# Declare log
log = logging.getLogger('jetstream-config')
logging.basicConfig(stream=sys.stdout, level=logging.DEBUG,
                    format='%(asctime)s %(levelname)s [%(name)s] %(message)s')
log.write = lambda msg: log.info(msg.strip()) if msg.strip() else None
log.flush = lambda: None
sys.stderr = log
sys.stdout = log

# Start NATS server
log.info('Starting NATS+JetStream server in background...')
command_line = ['nats-server', '-c', '/etc/server.cfg']
process = subprocess.Popen(command_line, stderr=subprocess.STDOUT, stdout=subprocess.PIPE)
# wait a few seconds before checking if the process did crash
time.sleep(5)
# the method process.poll() should return None as the subprocess is not supposed to terminate
if process.poll() is not None:
    # read the log
    for line in process.stdout:
        log.info(line)
    # exit with status 1
    log.error('Server failed to start. Exiting')
    sys.exit(1)

# Global variables
PRETTY_PRINT = True
NATS_CLIENT = jetstreamio_from_env(streaming_id='nats-web', max_reconnect_attempts=-1)
PING_INTERVAL = int(os.environ.get('PING_INTERVAL', '3600'))

# Read config from file
JS_CONFIG_FILE = os.environ.get('JS_CONFIG_FILE', '/etc/jetstream.json')
log.info("Reading NATS JetStream configuration from '%s'", JS_CONFIG_FILE)
JS_CONFIG = {}
with open(JS_CONFIG_FILE) as js_config:
    JS_CONFIG = json.load(js_config)

# Create JetStream streams from config
FAILURES = 0
NATS_CHANS = []
for entry, conf in JS_CONFIG.items():
    while(True):
        try:
            if entry.startswith("stream_"):
                resp = NATS_CLIENT.create_or_update_stream(**conf)
                if resp is None or b'error' in resp.data:
                    log.error("Stream '%s' creation failed.", conf.get('name'))
                    FAILURES += 1
                NATS_CHANS += conf["subjects"]
            elif entry.startswith("consumer_"):
                resp = NATS_CLIENT.create_or_update_consumer(**conf)
                if resp is None or b'error' in resp.data:
                    log.error("Consumer '%s' creation failed.", conf.get('name'))
                    FAILURES += 1
            else:
                log.error("JSON config file keys should start with 'stream_' or 'consumer_'")
                raise ValueError('Unhandled key in JSON config file')
        except ErrTimeout:
            log.error('Request timed out. Retrying in 2sec')
            time.sleep(2)
        except:
            log.exception('Caught exception in JetStream stream creation, stopping NATS client')
            NATS_CLIENT.stop()
            sys.exit(1)
        finally:
            # exit with 1 if failures were met
            if FAILURES > 0:
                log.error("%s errors in JetStream configuration attempt. Exiting with status 1", FAILURES)
                NATS_CLIENT.stop()
                sys.exit(1)
            break

# define ping function
async def async_ping(timeout):
    """
    Asynchronous periodic ping to NATS:test
    """
    try:
        ping_msg = f"[{os.environ.get('HOSTNAME','localhost')}] PING"
        await asyncio.sleep(1)
        while True:
            await NATS_CLIENT._request('test', ping_msg)
            await asyncio.sleep(timeout)
    except KeyboardInterrupt:
        log.warning('Caught KeyboardInterrupt event')
        NATS_CLIENT.stop()
        sys.exit(1)
    except:
        log.exception('Caught exception in async_ping, stopping NATS client')
        NATS_CLIENT.stop()
        sys.exit(1)

# retrieve event loop
LOOP = None
try:
    LOOP = asyncio.get_event_loop()
except RuntimeError:
    log.info('Failed to retrieve asyncio event loop. Creating a new one...')
    LOOP = asyncio.new_event_loop()

# start async ping loop
asyncio.run_coroutine_threadsafe(async_ping(PING_INTERVAL), loop=LOOP)
