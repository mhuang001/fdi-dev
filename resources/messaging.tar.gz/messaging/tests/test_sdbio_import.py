"""
SdbIo test file
"""
import logging
import os
import sys
import io
import types
import json
from unittest import mock
from requests import Response
import pytest

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
from package.svom.messaging.sdbio import SdbIo

log = logging.getLogger("test_sdbio")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)

# test products for import
TEST_PRODS = [
    "QPO_ECL_sb22011754_1",
    "PO_ECL_sb21013044_1",
    "MXT-EVT-CNV_1996488992_1",
    "MXT-EVT-CAL_1996488992_1",
    "OBPHOTMM_MXT_n.a_1",
]


HTTPIO_REQUEST = "package.svom.messaging.httpio.requests.Session.request"


@pytest.fixture(scope="module")
def sdb_client():
    """return sync SdbIo"""
    # with mock.patch('svom.messaging.tokens.KcTokens._request_tokens'):
    sync_client = SdbIo(max_tries=3, use_tokens=False)
    return sync_client


@pytest.fixture(params=[200, 201])
def sync_2xx_response(request):
    """mimics 'requests' success response"""
    fake_response = Response()
    fake_response.status_code = request.param
    fake_response.json = lambda: {"breakfast": "eggs"}
    return fake_response


@pytest.fixture(params=TEST_PRODS)
def product(request):
    """return scientific products"""
    return_value = types.SimpleNamespace()
    return_value.fits_filename = f"{BASE_DIR}/tests/{request.param}.fits"
    # build fake SDB response
    json_resp = {"export": [], "metadata": []}
    with open(f"{BASE_DIR}/tests/{request.param}.json") as json_file:
        json_resp = json.load(json_file)
    if "burst_id" in json_resp["search"].keys():
        if json_resp["search"]["burst_id"] == "None":
            json_resp["search"]["burst_id"] = None
    # search args
    return_value.search = json_resp["search"]
    # search resp
    return_value.export_resp = Response()
    return_value.export_resp.status_code = 200
    return_value.export_resp.json = lambda: json_resp.get("short_export")
    # search resp
    return_value.raw_resp = Response()
    return_value.raw_resp.status_code = 200
    return_value.raw_resp.json = lambda: json_resp.get("raw_short_export")
    # metadata_search resp
    return_value.metadata_resp = Response()
    return_value.metadata_resp.status_code = 200
    return_value.metadata_resp.json = lambda: json_resp["metadata"]
    return return_value


def test_init():
    """Check that the use_tokens param is correctly passed to super()"""

    os.environ["KC_TYPE"] = "pipelines"
    client = SdbIo()
    assert client.kc_tokens is not None
    assert client.kc_tokens.tokens_with_expirations_dates is None


def test_init_urls():
    """test url usage priorities"""
    # with mock.patch('svom.messaging.tokens.KcTokens._request_tokens'):
    # order should be env > arguments > default
    test_client = SdbIo(
        import_url="http://import/from:arg",
        export_url="http://export/from:arg",
        use_tokens=False,
    )
    assert test_client.import_endpoint == "http://import/from:arg/v0/add_product"
    assert (
        test_client.search_endpoint == "http://export/from:arg/server/search/products"
    )
    # order should be env > arguments > default
    os.environ["SDB_IMPORT_URL"] = "http://import/from:env"
    os.environ["SDB_EXPORT_URL"] = "http://export/from:env"
    test_client = SdbIo(
        import_url="http://import/from:arg",
        export_url="http://export/from:arg",
        use_tokens=False,
    )
    assert test_client.import_endpoint == "http://import/from:env/v0/add_product"
    assert (
        test_client.search_endpoint == "http://export/from:env/server/search/products"
    )
    # order should be env > arguments > default
    os.environ.pop("SDB_IMPORT_URL")
    os.environ.pop("SDB_EXPORT_URL")
    test_client = SdbIo(max_tries=3, use_tokens=False)
    assert (
        test_client.import_endpoint == "https://fsc.svom.org/sdb-import/v0/add_product"
    )
    assert (
        test_client.search_endpoint == "https://fsc.svom.org/sdb/server/search/products"
    )


def test_import(sdb_client, sync_2xx_response):  # pylint: disable=redefined-outer-name
    """test import"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        sdb_client.import_product(f"{BASE_DIR}/tests/test.fits")

        calls = mocked.call_args
        assert calls[0] == (
            "POST",
            "https://fsc.svom.org/sdb-import/v0/add_product",
        )
        files_arg = calls[1]["files"]["product"]
        assert files_arg[0] == f"{BASE_DIR}/tests/test.fits"
        assert isinstance(files_arg[1], io.BufferedReader)


def test_replace(sdb_client, sync_2xx_response):  # pylint: disable=redefined-outer-name
    """Test replace"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        sdb_client.update_product(306, f"{BASE_DIR}/tests/test.fits")

        calls = mocked.call_args
        assert calls[0] == (
            "POST",
            "https://fsc.svom.org/sdb-import/v0/update_product/306",
        )
        files_arg = calls[1]["files"]["product"]
        assert files_arg[0] == f"{BASE_DIR}/tests/test.fits"
        assert isinstance(files_arg[1], io.BufferedReader)

        sdb_client.update_product("306", f"{BASE_DIR}/tests/test.fits")
        calls = mocked.call_args
        assert calls[0] == (
            "POST",
            "https://fsc.svom.org/sdb-import/v0/update_product/306",
        )
        files_arg = calls[1]["files"]["product"]
        assert files_arg[0] == f"{BASE_DIR}/tests/test.fits"
        assert isinstance(files_arg[1], io.BufferedReader)


def test_import_or_update(sdb_client, product):
    """Test import or update"""
    sdb_client.has_astropy = False
    with pytest.raises(SystemExit):
        sdb_client.import_or_update("filename")
    from package.svom.messaging.sdbio import HAS_ASTROPY

    if not HAS_ASTROPY:
        pytest.skip("astropy not found. Skipping content retrieval methods")
    sdb_client.has_astropy = True

    # update test
    with mock.patch.object(
        sdb_client, "update_product", return_value=None
    ) as update_mocked, mock.patch.object(
        sdb_client, "search", return_value=product.export_resp
    ) as search_mocked, mock.patch.object(
        sdb_client, "raw_search", return_value=product.raw_resp
    ) as raw_mocked, mock.patch.object(
        sdb_client, "metadata_search", return_value=product.metadata_resp
    ):
        if product.raw_resp.json() is None:
            # Q*, L2+ products
            sdb_client.import_or_update(product.fits_filename)
            raw_mocked.assert_not_called()
            search_mocked.assert_called_once_with(**product.search)
            update_mocked.assert_called_once_with(
                product.export_resp.json()[0]["product_id"], product.fits_filename
            )
        else:
            # L0/L1 products
            sdb_client.import_or_update(product.fits_filename)
            raw_mocked.assert_called_once_with(**product.search)
            search_mocked.assert_not_called()
            update_mocked.assert_called_once_with(
                product.raw_resp.json()[0]["product_id"], product.fits_filename
            )
    # import test
    with mock.patch.object(
        sdb_client, "import_product", return_value=None
    ) as import_mocked, mock.patch.object(
        sdb_client, "search", return_value=product.export_resp
    ) as search_mocked, mock.patch.object(
        sdb_client, "raw_search", return_value=product.raw_resp
    ) as raw_mocked, mock.patch.object(
        sdb_client, "metadata_search", return_value=product.metadata_resp
    ):
        # fake empty response to trigger import
        if product.raw_resp.json() is None:
            # Q*, L2+ products
            search_mocked.return_value.json = lambda: []
            sdb_client.import_or_update(product.fits_filename)
            raw_mocked.assert_not_called()
            search_mocked.assert_called_once_with(**product.search)
        else:
            # L0/L1 products
            raw_mocked.return_value.json = lambda: []
            sdb_client.import_or_update(product.fits_filename)
            raw_mocked.assert_called_once_with(**product.search)
            search_mocked.assert_not_called()
        import_mocked.assert_called_once_with(product.fits_filename)


def test_update_procver(sdb_client, product):
    """Test update proc ver"""
    sdb_client.has_astropy = False
    with pytest.raises(SystemExit):
        sdb_client.import_or_update("filename")
    from package.svom.messaging.sdbio import HAS_ASTROPY

    if not HAS_ASTROPY:
        pytest.skip("astropy not found. Skipping content retrieval methods")
    sdb_client.has_astropy = True
    from astropy.io import fits

    # make sure fits file has PROC_VER=1 so that we can test the increment
    with fits.open(product.fits_filename) as fits_file:
        for hdu in fits_file:
            if "PROC_VER" in hdu.header:
                hdu.header["PROC_VER"] = 1
        fits_file.writeto(product.fits_filename, overwrite=True)

    # update test
    with mock.patch.object(
        sdb_client, "import_product", return_value=None
    ) as import_mocked, mock.patch.object(
        sdb_client, "search", return_value=product.export_resp
    ) as search_mocked, mock.patch.object(
        sdb_client, "raw_search", return_value=product.raw_resp
    ) as raw_mocked, mock.patch.object(
        sdb_client, "metadata_search", return_value=product.metadata_resp
    ):
        if product.raw_resp.json() is None:
            # Q*, L2+ products
            sdb_client.update_procver_and_import(product.fits_filename)
            raw_mocked.assert_not_called()
            search_mocked.assert_called_once_with(**product.search)
        else:
            # L0/L1 products
            sdb_client.update_procver_and_import(product.fits_filename)
            raw_mocked.assert_called_once_with(**product.search)
            search_mocked.assert_not_called()
        import_mocked.assert_called_once_with(product.fits_filename)

    # PROC_VER should have been updated
    with fits.open(product.fits_filename) as fits_file:
        assert fits_file[0].header["PROC_VER"] == 2
        for hdu in fits_file[1:]:
            assert hdu.header.get("PROC_VER", 2) == 2

    # import test (PROC_VER in the file being 2 it should be put back to 1)
    with mock.patch.object(
        sdb_client, "import_product", return_value=None
    ) as import_mocked, mock.patch.object(
        sdb_client, "search", return_value=product.export_resp
    ) as search_mocked, mock.patch.object(
        sdb_client, "raw_search", return_value=product.raw_resp
    ) as raw_mocked, mock.patch.object(
        sdb_client, "metadata_search", return_value=product.metadata_resp
    ):
        # fake empty response to trigger import
        if product.raw_resp.json() is None:
            # Q*, L2+ products
            search_mocked.return_value.json = lambda: []
            sdb_client.update_procver_and_import(product.fits_filename)
            raw_mocked.assert_not_called()
            search_mocked.assert_called_once_with(**product.search)
        else:
            # L0/L1 products
            raw_mocked.return_value.json = lambda: []
            sdb_client.update_procver_and_import(product.fits_filename)
            raw_mocked.assert_called_once_with(**product.search)
            search_mocked.assert_not_called()
        import_mocked.assert_called_once_with(product.fits_filename)

    # PROC_VER should have been put back to 1
    with fits.open(product.fits_filename) as fits_file:
        assert fits_file[0].header["PROC_VER"] == 1
        for hdu in fits_file:
            if "PROC_VER" in hdu.header:
                assert hdu.header["PROC_VER"] == 1
