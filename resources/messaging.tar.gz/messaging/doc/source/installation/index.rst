.. _installation:

Python module installation
**************************

Direct installation via pip
===========================

To install the `svom.messaging` module *without cloning* the messaging project:

::

    pip3 install "setuptools>=40.1.0" --user
    pip3 install git+ssh://git@drf-gitlab.cea.fr/svom/messaging.git#subdirectory=python --user


or through https protocol:

::

    pip3 install git+https://drf-gitlab.cea.fr/svom/messaging.git#subdirectory=python --user


Anaconda users
==============

For anaconda users the following commands should be used to make sure that the pip-installation
is done in the right directory:

::

    pip install "setuptools>=40.1.0"
    pip install git+ssh://git@drf-gitlab.cea.fr/svom/messaging.git#subdirectory=python

and to properly update it:

::

    pip install --upgrade --force-reinstall git+ssh://git@drf-gitlab.cea.fr/svom/messaging.git#subdirectory=python

From the project directory
==========================

::

    pip3 install "setuptools>=40.1.0" --user
    pip3 install -e . --user


This installs the requirements and the module in the default pip install directory.  The `-e` option tells pip to
install the module in *development mode*, meaning that changes to the files in this directory (for example
following a `git pull`) will immediately affect the installed package without needing to re-install.


