"""
HTTP client tool to get data from svom.messaging.he caldb data

@author: laurent.michel@astro.unistra.fr
"""
import json
import logging
import os
import pathlib

from svom.messaging.httpio import HttpIo
from svom.messaging.utils import get_caldb_url

log = logging.getLogger("caldb_client")

HTTP_200 = 200
HTTP_201 = 201

POINT_FITS = ".fits"
POINT_FIT = ".fit"
POINT_YAML = ".yaml"
POINT_YML = ".yml"


class CalDbIo(HttpIo):
    """
    Client class accessing the CALDB in read mode

    Parameters
    ----------
    server_url :  str, optional
        root server url share by all the endpoints.
    max_tries : int, optional
        Number of connection attemps
    use_tokens : bool, optional
        True if Authorization token has to be used.
    tokens : dict, optional
        if not None, these tokens will be used instead of requesting keycloak,
        except if the tokens is not valid anymore.
    """

    # pylint: disable=too-many-arguments
    def __init__(
        self,
        server_url="https://fsc.svom.org/caldb/",
        max_tries=1,
        use_tokens=True,
        tokens=None,
    ):
        server_url = get_caldb_url(server_url)
        super().__init__(
            server_url,
            max_tries=max_tries,
            use_tokens=use_tokens,
            tokens=tokens,
        )
        self.endpoints = {
            "map": "/api/user/map",
            "list": "/api/user/list",
            "search": "/api/user/search",
        }

    def global_map(self):
        """Return the CALDB map as a dict"""
        response = self.get(self.endpoints["map"])
        code = response.status_code
        if code == HTTP_200:
            return json.loads(response.text)
        log.error("Can't caldb map)")
        return None

    def ecl_map(self):
        """Return the CALDB map for ECLAIR as a dict"""
        global_map = self.global_map()
        if global_map is not None:
            return global_map["svom"]["ecl"]
        log.error("Can't caldb ECL map")
        return None

    def mxt_map(self):
        """Return the CALDB map for MXT as a dict"""
        global_map = self.global_map()
        if global_map is not None:
            return global_map["svom"]["mxt"]
        log.error("Can't caldb MXT map")
        return None

    def vt_map(self):
        """Return the CALDB map for VT as a dict"""
        global_map = self.global_map()
        if global_map is not None:
            return global_map["svom"]["vt"]
        log.error("Can't caldb VT map")
        return None

    def grm_map(self):
        """Return the CALDB map for GRM as a dict"""
        global_map = self.global_map()
        if global_map is not None:
            return global_map["svom"]["grm"]
        log.error("Can't caldb GRM map")
        return None

    def list(self, instrument, code):
        """Return the list of calibration files

        Return the list of calibration files for instrument and matching the code

        Parameters
        ----------
        instrument : str
            instrument acronym: 'ecl', 'mxt', 'vt, 'grm'
        code : str
            calibration type: 'rmf_matrix', 'irf_matrix', 'arf_effarea',
            'gain_coef', 'teldef' or 'saa_lim_high'

        Returns
        -------
        file_list : list
            list of calibration files for a given instrument and code
        """
        response = self.get(f"{self.endpoints['list']}/{instrument.lower()}/{code.lower()}")
        resp_code = response.status_code
        if resp_code == HTTP_200:
            file_list = json.loads(response.text)["files"]
        else:
            log.error(
                "Can't retrieve list of calibration files %s/%s (code %s)",
                instrument,
                code,
                resp_code,
            )
            file_list = []

        return file_list

    def get_latest_filename(self, instrument, code):
        """Return the name of the latest calibration file

        Return latest calibration file name for a given instrument and code

        Parameters
        ----------
        instrument : str
            instrument acronym: 'ecl', 'mxt', 'vt', 'grm'
        code : str
            calibration type: 'rmf_matrix', 'irf_matrix', 'arf_effarea',
            'gain_coef', 'teldef' or 'saa_lim_high'

        Returns
        -------
        filename : str
            filename of latest calibration file
        """
        response = self.get(f"{self.endpoints['search']}/{instrument.lower()}/{code.lower()}/now")
        resp_code = response.status_code
        if resp_code == HTTP_200:
            filename = response.headers.get("Content-Disposition").split("=")[1].replace('"', "")
        else:
            log.error(
                "Can't retrieve calibration file %s/%s/now (code %s)",
                instrument,
                code,
                resp_code,
            )

            filename = None

        return filename

    def search(self, instrument, code, date="now", download_path=None, download_fname=None):
        """Download the calibration  file

        Download the calibration calibration file of instrument, matching the code
        and valid at date

        Parameters
        ----------
        instrument : str
            instrument acronym: 'ecl', 'mxt', 'vt, 'grm'
        code : str
            calibration type: 'rmf_matrix', 'irf_matrix', 'arf_effarea', 'gain_coef'
                              'teldef' or 'saa_lim_high'
        date : str, optional
            selected date. 'now' for the latest file
        download_path : str or None, optional
            path where to store the downloaded calibration file
        download_fname : str or None, optional
            rename downloaded file if not None.

        Returns
        -------
        output_file : str or None
            path to downloaded file
        """
        response = self.get(
            f"{self.endpoints['search']}/{instrument.lower()}/{code.lower()}/{date}"
        )
        resp_code = response.status_code
        if resp_code == HTTP_200:
            filename = response.headers.get("Content-Disposition").split("=")[1].replace('"', "")
            # Rename downloaded file if required
            if download_fname:
                # Check whether '.fits' extension is missing
                fname, ext = os.path.splitext(download_fname)
                if ext != POINT_FITS:
                    log.info("Adding '.fits' extension to 'download_fname'.")
                    download_fname = fname + POINT_FITS

            output_fname = download_fname if download_fname else filename

            # Make sure download_path exists
            if download_path:
                os.makedirs(download_path, exist_ok=True)
            else:
                download_path = "."
            output_file = os.path.join(download_path, output_fname)

            with open(output_file, "wb") as calib_file:
                calib_file.write(response.content)
                log.info("%s saved in %s", filename, output_file)
        else:
            log.error(
                "Can't retrieve calibration file %s/%s/%s (code %s)",
                instrument,
                code,
                date,
                resp_code,
            )
            output_file = None
        return output_file

    def upload_file(self, filepath):
        """Upload the file into the caldb.

        The file type (fits or yaml) is checked locally,
        all other actions are achieved on server side.
        It is to be noted that upload actions (succeeded or failed)
        are logged on NATS
        Parameters

        ----------
        filepath: str
            full path of the file to be uploaded
        Return
        -------
        status : boolean
            true if succeeded False otherwise
        """
        filename = os.path.basename(filepath)
        file_extension = pathlib.Path(filepath).suffix

        if file_extension.lower() in [POINT_FITS, POINT_FITS]:
            mime_type = "application-x/fits"
        elif file_extension.lower() in [POINT_YML, POINT_YAML]:
            mime_type = "text/yaml"
        else:
            message = {
                "valid": False,
                "name_org": filename,
                "message": (
                    "Cannot be uploaded: seems not to be "
                    f"fits or yaml either ({file_extension}) "
                ),
            }
            log.error(message["message"])
            return False

        try:
            with open(filepath, "rb") as fits_file:
                files = {"data": (filename, fits_file, mime_type)}
                response = self.post("api/admin/", files=files)
                resp_code = response.status_code
                text = response.text.strip()
                if resp_code == HTTP_201:
                    log.info(text)
                    return True
                log.error(text)
                return False
        except Exception:
            log.exception("upload failed")
            return False
        log.error("Cannot open %s", filepath)
        return False

    def valid_file(self, filepath):
        """Test the validity of the input file

        Test the validity of the input file and tells where it would be stored if valid

        Parameters
        ----------
        filepath: str
            full path of the file to be uploaded
        Return
        -------
        status : dictionary
            {'valid': True, 'name_org': ..., 'stored_as': ..., 'stored_in': ..., 'valid_from': ...s}
            or
            {'valid': False, 'name_org: ..., 'message': ...}
        """
        filename = os.path.basename(filepath)
        file_extension = pathlib.Path(filepath).suffix

        if file_extension.lower() in [POINT_FITS, POINT_FITS]:
            mime_type = "application-x/fits"
        elif file_extension.lower() in [POINT_YML, POINT_YAML]:
            mime_type = "text/yaml"
        else:
            message = {
                "valid": False,
                "name_org": filename,
                "message": (
                    "Couldn't be uploaded: "
                    f"seems not to be fits or yaml either ({file_extension}) "
                ),
            }
            log.error(message["message"])
            return message

        try:
            with open(filepath, "rb") as fits_file:
                files = {"data": (filename, fits_file, mime_type)}
                response = self.post("api/admin/valid", files=files)
                return json.loads(response.text)
        except Exception as exception:
            return {"valid": False, "message": f"{str(exception)}"}
        return {"valid": False, "message": f"Cannot open {filepath}"}
