fdi.pal.resources package
=========================

.. automodule:: fdi.pal.resources
   :members:
   :undoc-members:
   :show-inheritance:
