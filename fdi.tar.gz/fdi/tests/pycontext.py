# -*- coding: utf-8 -*-
# This is to be able to test w/ or w/o installing the package
# https://docs.python-guide.org/writing/structure/
import os
import sys
sys.path.insert(0, os.path.abspath(
    os.path.join(os.path.dirname(__file__), '..')))

import fdi
#from fdi import dataset
#from fdi import pal
#from fdi import pns
#from fdi import tests
# print(dir(dataset))
