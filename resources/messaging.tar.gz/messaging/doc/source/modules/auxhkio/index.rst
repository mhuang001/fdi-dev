.. _auxhkio:

*******
AuxHkIo
*******

Reference/API
=============

.. automodapi:: package.svom.messaging.auxhkio
    :no-inheritance-diagram:
    :include-all-objects: