#!/usr/scripts/package3
"""
Here is an example to publish a message to the topic test by default
(you can change the topic or the message giving a --chanels (one or several)
or --message to the command line). For several channel like test1 and test2,
has to be given --channels "test1" "test2"

To connect to the Mqtt broker example at IJCLAB, try:
package3 mqtt_pub_example.py --host svom-fsc-2.lal.in2p3.fr --port 20083
adding the password
"""

from svom.messaging import MqttIo
from svom.messaging import mqttio_from_args


def main():
    """
    Instantiate MQTT client and subscribe to {args.channels}
    """
    mqtt_client, args = mqttio_from_args(clean_session=True)

    if args.message is None:
        args.message = "Hello you"
    if args.channels is None:
        args.channels = ["test"]
    for channel in args.channels:
        mqtt_client.publish(channel, args.message, qos=1)

    mqtt_client.stop()


if __name__ == "__main__":
    main()
