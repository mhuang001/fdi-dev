.. _db_communication:

REST API interfaces
*******************


Several databases are deployed to the FSC. The python module include a multitude of classes with specific methods to simplify the communications
with them. All those classes inherits from the `HttpIo` instance that wraps `requests` and `aiohttp` methods for
simple synchronous or asynchronous REST messaging in python.

HttpIo and all the classes that inherit from it, can use :ref:`KcTokens <tokens>` class to allow users or apps to get an access token before requesting.
More details in the :ref:`Authentification section <authentification>`.

Once the :ref:`python messaging module installed <installation>`, the different classes that
allow easier communication with the FSC databases can be imported as follow:

::

    from svom.messaging import SdbIo
    from svom.messaging import VhfDbIo
    from svom.messaging import XbandDbIo
    from svom.messaging import CrestDbIo
    from svom.messaging import AuxHkIo
    from svom.messaging import CalDbIo


HttpIo
======

The class is using the `Requests <https://pypi.org/project/requests/>`_
python package to request servers, or fetch access tokens. It provides REST API interfaces (using standard HTTP protocol) for synchronous and asynchronous client.

HttpIo can use `KcTokens` class for the user authentification, more details in the :ref:`Authentification section <authentification>`.

To use `KcTokens` in HttpIo:

::

    from svom.messaging import HttpIo
    my_client = HttpIo(use_tokens=True)     # will raise ValueError if KcTokens environment variables are missing.

Synchronous client
~~~~~~~~~~~~~~~~~~

::

    from svom.messaging import HttpIo
    sync_client = HttpIo('http://127.0.0.1', max_tries=5)       # no tokens in Authorization Header
    # GET
    response = sync_client.get('/', params={'spam': 'eggs'})
    print(response.json(), response.status_code)
    # POST
    sync_client.post('/import/endpoint', json={'spam': 'eggs'})
    print(response.json(), response.status_code)

For now, the module will relaunch any request that returns a response with a status other than 2xx
`max_tries` times before it stops trying.

Asynchronous client:
~~~~~~~~~~~~~~~~~~~~

::

    async_client = HttpIo('http://127.0.0.1', max_tries=5, asynchronous=True)       # no tokens in Authorization Header

    future = asyncio.run_coroutine_threadsafe(
        async_client.async_post('/', json={'spam': 'eggs'},
        loop=asyncio.get_event_loop()
    )
    response = future.result()

or from an `async` function:

::

    response = await async_client.async_get('/', json={'bacon': 'sausage'})


Update usage to delegate to bricks the token management
~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~

From the `1.6.9` version, an optional `tokens` keyword argument is added when instanciating a `KcTokens` object.
This allow users to directly set the `KcTokens.tokens_with_expirations_dates` attribute with tokens retrieved from local files, for instance.
This behaviour is added in all Io classes to deleguate tokens management to the bricks scheduler.

From a client side, this would go as such:

::

    import json
    import os
    from svom.messaging.tokens import TokensWithExpirationsDates
    from svom.messaging import SdbIo

    my_tokens = None
    if os.environ["whereAmI"] == "fsc":     # don't know.. but surely for local pipeline testing that might be useful
        with open("runtime_params.json", "r") as fpi:
            r_params = json.load(fpi)
            my_tokens = r_params["tokens"]

    # create a client that uses tokens (default value)
    # but add the tokens parameter to prevent KcTokens to request Keycloak
    # (except if the tokens is expired -> then Keycloak request).

    ## ATTENTION: you must pass a TokensWithExpirationsDates instance to the KcTokens constructor.
    imported_tokens = TokensWithExpirationsDates.from_dict(my_tokens)

    sdb = SdbIo(tokens=imported_tokens)    # default is: (..., use_tokens=True, tokens=None)

    sdb.update_product(whatever, whatever)


What happens then is that the `KcTokens.get_authorization_header` method will only format a header from the tokens, rather
that requesting or refreshing one from Keycloak. Of course, if the access token or the refresh token in bricks is expired (Booh),
this method WILL request or refresh the token from Keycloak.

SdbIo
=====

The :ref:`SdbIo <sdbio>` python client class interacts with the SDB. `SdbIo` inherits
from `HttpIo` so the HttpIo methods are available and adds on top of those some convenient methods to download and import products.
**Please read carefully the** :ref:`KcTokens <authentification>` **paragraph to properly set KcTokens configuration.**
The SDB is checking tokens and roles: an access token must be set in an "Authorization"
header in each request to the SDB. `SdbIo` uses `KcTokens` by default.

::

    from svom.messaging import SdbIo
    my_sdb_client = SdbIo()             # will raise ValueError if KcTokens env var not properly set.

`SdbIo` can be parametrized using the environment variables `SDB_IMPORT_URL` and `SDB_EXPORT_URL`.
To use SdbIo from inside the FSC network just set those variables to 'http://sdb_api-import' and
'http://sdb_proxy/' respectively. From outside the FSC network the current import API URL is https://fsc.svom.org/sdb-import
and the export API URL https://fsc.svom.org/sdb.

Syntax examples:

::

    from svom.messaging import SdbIo
    sdb_client = SdbIo()
    response = sdb_client.search(obs_id=1, acronym='QPO_ECL')
    response.status_code
    response.json()
    urls = sdb_client.get_fits_urls(obs_id=1, acronym='QPO_ECL')
    sdb_client.save_fits_files(product_id=123, dirname='./fits_dir')


The following keyword arguments are available for the three functions: `product_id, obs_id, acronym, version, program, instrument`

and the fields in the JSON results of the `search()` function are: `'product_id', 'obs_id', 'acronym', 'filename', 'criteria', 'date', 'version', 'program', 'instrument', 'type'`

They can be used to limit the JSON response as such:

::

    smaller_json = sdb_client.search(obs_id=1, outputs=['product_id', 'acronym', 'date']

As for HttpIo, the module will relaunch any request that returns a response with a status other than 2xx
`max_tries` times before it stops trying.

VhfDbIo
=======

The :ref:`VhfDbIo <vhfdbio>` python client class interacts with the SDB. `SdbIo` inherits
from `HttpIo` so the HttpIo methods are available and adds on top of those some convenient methods to download and import products.
**Please read carefully the** :ref:`KcTokens <authentification>` ** paragraph to properly set KcTokens configuration.**
The VHF-DB is checking tokens and roles: an access token must be set in an "Authorization"
header in each request to the SDB. `VhfDbIo` uses `KcTokens` by default.

::

    from svom.messaging import VhfDbIo
    my_vhf_client = VhfDbIo()             # will raise ValueError if KcTokens env var not properly set.


`VhfDbIo` uses as default the VHF-DB server URL: 'https://fsc.svom.org/vhfdb'.

`VhfDbIo` can be parametrized using the environment variable `VHFDB_SERVER_URL`.
To use VhfDbIo from inside the FSC network just set this variable to 'http://vhfmgr_service:8080'

As for HttpIo, the module will relaunch any request that returns a response with a status other than 2xx `max_tries` times before it stops trying.

Please refer to `this wiki <https://drf-gitlab.cea.fr/svom/common/Tools/-/wikis/VHF-API-Examples>`_

XBandDbIo
=========

The :ref:`XbandDbIo <xbanddbio>` python client class interacts with the SDB. `XBandDbIo` inherits
from `HttpIo` so the HttpIo methods are available and adds on top of those some convenient methods to download and import products.
**Please read carefully the :ref:`KcTokens <authentification>` paragraph to properly set KcTokens configuration.**
The XBAND-DB is checking tokens and roles: an access token must be set in an "Authorization"
header in each request to the SDB. `XBandDbIo` uses `KcTokens` by default.

::

    from svom.messaging import XBandDbIo
    my_xband_client = XBandDbIo()             # will raise ValueError if KcTokens env var not properly set.

As for HttpIo, the module will relaunch any request that returns a response with a status other than 2xx `max_tries` times before it stops trying.

`XBandDbIo` uses as default the XBAND-DB server URL: 'https://fsc.svom.org/xband-server'

`XBandDbIo` can be parametrized using the environment variable `XBANDDB_SERVER_URL`.
To use XBandDbIo from inside the FSC network just set this variable to 'http://xbandmgr_http:8080'

CrestDbIo
=========

The :ref:`CrestDbIo <crestdbio>` python client class interacts with the SDB. `CrestDbIo` inherits
from `HttpIo` so the HttpIo methods are available and adds on top of those some convenient methods to download and import products.
**Please read carefully the :ref:`KcTokens <authentification>` paragraph to properly set KcTokens configuration.**
The CREST-DB is checking tokens and roles: an access token must be set in an "Authorization"
header in each request to the SDB. `CrestDbIo` uses `KcTokens` by default.

::

    from svom.messaging import CrestDbIo
    my_xband_client = CrestDbIo()             # will raise ValueError if KcTokens env var not properly set.

As for HttpIo, the module will relaunch any request that returns a response with a status other than 2xx `max_tries` times before it stops trying.

`CrestDbIo` uses as default the CREST-DB server URL: 'https://fsc.svom.org/crestdb/api'

`CrestDbIo` can be parametrized using the environment variable `CRESTDB_SERVER_URL`.
To use CrestDbIo from inside the FSC network just set this variable to 'http://auxhkmgr_service:8080'


AuxHkIo
=======

The :ref:`AuxHkIo <auxhkio>` python client class interacts with the SDB. `AuxHkIo` inherits
from `HttpIo` so the HttpIo methods are available and adds on top of those some convenient methods to download and import products.
**Please read carefully the :ref:`KcTokens <authentification>` paragraph to properly set KcTokens configuration.**
The AUXHK-DB is checking tokens and roles: an access token must be set in an "Authorization"
header in each request to the SDB. `AuxHkIo` uses `KcTokens` by default.

::

    from svom.messaging import AuxHkIo
    my_xband_client = AuxHkIo()             # will raise ValueError if KcTokens env var not properly set.

As for HttpIo, the module will relaunch any request that returns a response with a status other than 2xx `max_tries` times before it stops trying.

`AuxHkIo` uses as default the AUXHK-DB server URL: 'https://fsc.svom.org/auxhkmgr'

`AuxHkIo` can be parametrized using the environment variable `AUXHKDB_SERVER_URL`.
To use AuxHkIo from inside the FSC network just set this variable to 'http://auxhkmgr_service:8080'

CalDbIo
=======

The :ref:`CalDbIo <caldbio>` python client class interacts with the SDB. `CalDbIo` inherits
from `HttpIo` so the HttpIo methods are available and adds on top of those some convenient methods to download products.
**Please read carefully the :ref:`KcTokens <authentification>` paragraph to properly set KcTokens configuration.**
The CAL-DB is checking tokens and roles: an access token must be set in an "Authorization"
header in each request to the SDB. `CalDbIo` uses `KcTokens` by default.

::

    from svom.messaging import CalDbIo
    my_xband_client = CalDbIo()             # will raise ValueError if KcTokens env var not properly set.

As for HttpIo, the module will relaunch any request that returns a response with a status other than 2xx `max_tries` times before it stops trying.

`CalDbIo` uses as default the CALDB-DB server URL: 'https://fsc.svom.org/caldb/'

`CalDbIo` can be parametrized using the environment variable `CALDB_SERVER_URL`.
To use CalDbIo from inside the FSC network just set this variable to 'http://caldb_caldb:5000'
