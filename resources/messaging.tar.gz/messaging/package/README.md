## Python Module svom.messaging

This directory contains a package module :

- The two clients for NATS and MQTT messaging system: `JetStreamIo` and `MqqtIo`. 
  [Click here](https://fsc.svom.org/documentation/messaging/messaging_system/index.html) for the complete overview.
-  The classes with specific methods to simplify the interaction with the different datbases deployed at FSC.
  [Click here](https://fsc.svom.org/documentation/messaging/db_communication/index.html) for the complete overview.