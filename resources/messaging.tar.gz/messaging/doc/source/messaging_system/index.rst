.. _messaging_system:

Messaging system
****************

The FSC is composed of different services. Distinct services have two ways of
communicating between each other :

* One-to-one communications are performed through REST API interfaces (using standard HTTP protocol) described in the :ref:`REST API section <db_communication>`
* One-to-many communications, such as broadcasts, are made using a centralized messaging system : NATS messaging in the FSC and Mqtt messaging in the CSC.

In this section, we describe the tools included in the messaging project for the One-to-many communications.
We briefly describe the NATS and MQTT messaging system and the two clients we
developed for those: `JetStreamIo` and `MqqtIo`. In the last part is explained how to deploy and configure a NATS server to mimic locally the FSC one.

NATS and MQTT messaging system
==============================

FSC NATS messaging
==================

Message exchanges at FSC
~~~~~~~~~~~~~~~~~~~~~~~~

NATS is an open-source messaging system :

* that makes it easy for applications to communicate by sending and receiving messages

* lightweight pub/sub messaging system

* the messages are addressed and identified by subject strings

The centralized messaging system at the FSC is based on JetStream that is a log-based streaming system built
on top of NATS with enables new functionalities and higher qualities of service
on top of the base 'Core NATS' functionalities :

* stores messages in streams defining how messages are stored and how long they persist

* streams consume normal NATS subjects

* any message published on those subjects will be captured in the defined storage system

Messaging channels FSC
~~~~~~~~~~~~~~~~~~~~~~

The current FSC NATS2.2 + JetStream server configuration can be found `here <https://drf-gitlab.cea.fr/svom/messaging/-/blob/master/config/jetstream.json>`_.

In the FSC design, we have the 4 following  **streams** and the associated *subjects*:

* **data** :

    #. *data.vhf*

    #. *data.vhfba*

    #. *data.sdbxband*

    #. *data.voeventdb*

    #. *data.too*

    #. *data.tooalert*

    #. *data.crest*

    #. *data.auxhk*

    #. *data.csc*

* **science**

    #. *science.calibration*

    #. *science.core_program*

    #. *science.general_program*

    #. *science.too*


* **activity**

    #. *activity.infrastructure*

    #. *activity.calibration*

    #. *activity.core_program*

    #. *activity.general_program*

    #. *activity.too*


* **test**

    #. *test*

NATS monitoring at FSC
~~~~~~~~~~~~~~~~~~~~~~

The messages on the different stream can be monitored on this `web page <https://fsc.svom.org/jetstream/>`_ for the FSC at IJcLab and on this
`web page <https://fsc.svom.eu/jetstream/>`_ for the CC FSC.

python client JetStreamIo
~~~~~~~~~~~~~~~~~~~~~~~~~

The Python client implemented to in messaging based on Jetstream is named  :ref:`JetStreamIo <jetstreamio>`. It wraps
asyncio-nats-client and asyncio-nats-streaming methods for simple asynchronous NATS/NATS Streaming messaging
in python for fsc communication.

Once  the :ref:`python messaging module installed <installation>`, the JetStreamIo class can be imported as follows:

::

    from svom.messaging import JetStreamIo

This class can instantiate both standard NATS clients and JetStream clients:

::

    client = JetStreamIo(host, port)
    client = JetStreamIo(host, port, streaming_id='SOME_ID')


`JetStreamIo` can be parametrized using the environment variables `NATS_HOST` and `NATS_PORT`.
The associated server runs at IJCLab and can be accessed within the FSC architecture at `nats://messaging_jetstream:4222`.
To use JetStreamIo from inside the FSC network just set those variables to 'messaging_jetstream' and '4222' respectively.


The `JetStreamIo` class is designed to be able to use both standard NATS and the JetStream streaming
system in a transparent way (for the user). Either way, the client can easily publish to channels as
such:

::

    client.publish(subject,'MESSAGE_TO_PUBLISH')


The subscription to a channel is done after defining a reaction function:

::

    @asyncio.coroutine
    def reaction(msg):
        print(msg.subject)
        print(msg.data)

    client.subscribe(subject,reaction)


Behind the curtains, if a `streaming_id` was provided in initialization, JetStreamIo handles the
creation of a dedicated JetStream "Consumer" to make the subscription durable, so that a service
with a given `streaming_id` is ensured exactly once delivery of messages. In the event of a
disconnection from the server, the missed messages shall be automatically received upon reconnexion.


A program `js_sub_example.py` listening to the `example` channel on `nats://localhost:4222` can be found
`here <https://drf-gitlab.cea.fr/svom/messaging/-/blob/master/package/scripts/js_sub_example.py>`_. To listen to the test
and data.vhf channels, simply launch :

::

    python3 bin/sub_example.py --user svom --password ******** --channels test data.vhf ...

The password is defined at the NATS configuration if the server is run locally (see section on NATS configuration below).

A small publisher script `js_pub_example.py` is also available `here <https://drf-gitlab.cea.fr/svom/messaging/-/blob/master/package/scripts/js_pub_example.py>`_.
To publish the message "My name is groot" on the channel data.sdb, simply launch

::

    python3 bin/pub_example.py --user svom --password ******** --msg "My name is groot" --channels data.sdb

For more information:

::

    ./bin/js_sub_example.py --help
    ./bin/js_pub_example.py --help


CSC MQTT messaging
==================

Message exchanges at CSC
~~~~~~~~~~~~~~~~~~~~~~~~

The centralized messaging system at CSC makes use of the RabbitMQ broker with a MQTT (MQ Telemetry Transport) protocol:

* lightweight open messaging protocol that provides resource-constrained network clients with a simple way to distribute telemetry information in low-bandwidth environments

* send and receive messages on topic : string that the broker uses to filter messages for each connected client

* topic consists of one or more topic levels. Each topic level is separated by a forward slash (topic level separator) : easy filtering on the levels


At CSC, the topics are made with three components: {category}/{action}/{status}.


Python Client MqttIo
~~~~~~~~~~~~~~~~~~~~

In order to be able to receive the messages from the CSC (new product in the CSC dB, vhf beidou messages ...etc) and to be able to
send notifications to the CSC (new product in the SDB, Too alert..etc), we developed a Python Client that wraps
`asyncio-mqtt-client <https://github.com/sbtinstruments/asyncio-mqtt>`_  and `paho-client <https://github.com/eclipse/paho.mqtt.python>`_
for simple asynchronous MQTT messaging in python for csc-fsc communication.

The python Client we developed is named :ref:`MqttIo <mqttio>`. The services deployed at FSC to listen or to publish
to the CSC MQTT topics are based on this client. This client enables applications to connect to the CSC RabbitMQ broker and to publish
MQTT messages or/and to subscribe to topics and receive the published MQTT messages from CSC.


Once  the :ref:`python messaging module installed <installation>`, the MqttIo class can be imported as follows:

::

    from svom.messaging import MqttIo

This class can instantiate MQTT clients:

::

    client = MqttIo(host, port)

`MqttIo` can be parametrized using the environment variables `MQTT_HOST`, `MQTT_PORT` and `MQTT_USER`.

The client can easily publish to topic of the Mqtt broker. Below an example to
publish on the topic test:

::

    topic="test"
    client.publish(topic,'MESSAGE_TO_PUBLISH')

The subscription to a topic is done after defining a call back function for printing
the message received on the channel (a default one is attributed during the initialisation
if none is given):

::

    def on_message(self,client, userdata, message):
        topic = message.topic
        message_decode = message.payload.decode('utf-8')
        log.info('Message received on channel \'%s\': %s', topic,
                message_decode)

    client = MqttIo(host, port, on_message=on_message)
    client.subscribe(topic)


In the event of a disconnection from the server, the missed messages shall be
automatically received upon reconnexion. For that to happen, we need to create a
persistent client putting the clean session argument to False and defining a unique
client id when initialising the client for subscribing to a topic.

::

    client = MqttIo(host, port, client_id="unique_id", clean_session=False)


A program listening to the topics of a RabbiMQ broker can be found:
`here <https://drf-gitlab.cea.fr/svom/messaging/-/blob/master/package/scripts/mqtt_sub_example.py>`_. Let's consider the RabbiMQ
broker installed at IJCLab `svom-fsc-2.lal.in2p3.fr:20083`, if we want to listen to the `test` and `data.vhf`, simply launch

::

    python3 bin/mqtt_sub_example.py --host host --port 20083 --user svom --password ******** --channels test data.vhf


A small publisher script is also available:
`here <https://drf-gitlab.cea.fr/svom/messaging/-/blob/master/package/scripts/mqtt_sub_example.py>`_.
If we want to publish the message "My name is groot" to the topic `test`, Simply launch:

::

    python3 bin/mqtt_pub_example.py --host host --port 20083 --user svom --msg "My name is groot" --password ******** --channels test




Deployment of NATS server and configuration
===========================================

Configuration
~~~~~~~~~~~~~

The NATS Streaming server configuration defines the message channels available to the users of the NATS Streaming server and is described in
`config/jetstream.json <https://drf-gitlab.cea.fr/svom/messaging/-/blob/master/config/jetstream.json>`_. More details concerning NATS configuration
files can be found `here <https://github.com/nats-io/nats-streaming-server#configuration-file>`_.

Deployment
~~~~~~~~~~

The instructions for the deployment of the NATS server are contained in
`docker-compose.yml <https://drf-gitlab.cea.fr/svom/messaging/-/blob/master/docker-compose.yml>`_.

The generated docker stack is build from official docker images, so that the only prerequisite is to have a
docker network ready to use at swarm level. For example:

::

    docker network create -d overlay fscnet


Before deploying, change the config use by the NATS server in `config/nats.conf <https://drf-gitlab.cea.fr/svom/messaging/-/blob/master/config/nats.conf>`_. By default, when you connect
to the NATS server, you will be considered as svom user. Change the password ****** associated to the *svom user* in the
configuration. For example, let's choose *gamma_power*.

Then, the NATS server can be deployed as follows:

::

    docker stack deploy --with-registry-auth -c docker-compose.yml messaging

or using the Makefile

::

    make deploy

Basic usage example
~~~~~~~~~~~~~~~~~~~

The service used for the NATS server is the one named messaging_jetstream. To get more information on how to use the deployed NATS server with the class JetstreamIo
please refer to the section above.

Below are two basic examples
of subscription and publication to the NATS stream *data.sdb* using the two scripts in the `package/scripts <https://drf-gitlab.cea.fr/svom/messaging/-/blob/master/package/scripts>`_
`js_sub_example.py <https://drf-gitlab.cea.fr/svom/messaging/-/blob/master/package/scripts/js_sub_example.py>`_  for subscription and
`js_pub_example.py <https://drf-gitlab.cea.fr/svom/messaging/-/blob/master/package/scripts/js_pub_example.py>`_ for publication.

First, you have to create the nats_password docker secret with the password you choose for the svom user, here gamma_power:

::

    printf "gamma_power" | docker secret create nats_password -


let's listen to the `data.sdb` channel on `nats://localhost:4222`:

::

    python3 js_sub_example.py --host 127.0.0.1 --password gamma_power --channels data.sdb


Then let's publish a message on this channel that you should see where you subscribed.

::

    python3 js_pub_example.py --host 127.0.0.1 --password gamma_power --channels data.sdb --msg "You are great"


Accessibility
~~~~~~~~~~~~~

Any service on the `fscnet` docker network can access the NATS server at `nats://messaging_jetstream:4222`.
The server authentification user is `svom` and the password is stored in the docker secret `nats_password`.
A docker servicei `$NAME` of the swarm wanting to have access to NATS on the `fscnet` network should be
described as follows in its stack YAML file:

::

    services:
    ...
       $NAME:
          image: ...
          secrets:
              - nats_password
          networks:
              - fscnet
              ...
          ...
    ...

    networks:
        fscnet:
            external: true
        ...

    secrets:
        nats_password:
            external: true
