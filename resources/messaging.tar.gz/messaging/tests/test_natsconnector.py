"""
SdbIo test file
"""
import logging
import os
import sys
from unittest import mock
import pytest

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
from package.svom.messaging.connector import NatsConnector

log = logging.getLogger("test_natsconnector")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)


@pytest.fixture(scope="module")
def nats_config():
    """Mock nats config"""
    for key in os.environ:
        if key.startswith("NATS"):
            os.environ.pop(key)
    config = {}
    config["host"] = "svomtest.svom.fr"
    config["port"] = "4222"
    config["user"] = "svom"
    config["streaming_id"] = "my-module"
    config["password"] = "password"
    return config


@pytest.fixture(scope="module")
def connector(nats_config):
    """Connector mock"""
    connector = NatsConnector(nats_config)
    return connector


def test_init(connector, nats_config):  # pylint: disable=redefined-outer-name
    """Test init"""
    assert connector.config == nats_config


def test_user_from_env(connector, nats_config):  # pylint: disable=redefined-outer-name
    """Test user from svom.messaging.nv"""
    os.environ["NATS_USER"] = "user_from_env"
    connector.get_config(nats_config)
    assert connector.config["user"] == "user_from_env"


def test_gethost(connector, nats_config):  # pylint: disable=redefined-outer-name
    """Test gethost"""
    # test default value
    nats_config.pop("host")
    connector.get_host(nats_config)
    assert connector.config["host"] == "nats"
    # test env variable 1
    os.environ["NATS_HOST"] = "host_env"
    connector.get_host(nats_config)
    assert connector.config["host"] == "host_env"
    # test env variable 2
    os.environ["NATS_SERVER_HOST"] = "server_host_env"
    connector.get_host(nats_config)
    assert connector.config["host"] == "server_host_env"


def test_getport(connector, nats_config):  # pylint: disable=redefined-outer-name
    """Test getport"""
    # test default value
    nats_config.pop("port")
    connector.get_port(nats_config)
    assert connector.config["port"] == "5522"
    # test env variable 1
    os.environ["NATS_PORT"] = "port_env"
    connector.get_port(nats_config)
    assert connector.config["port"] == "port_env"
    # test env variable 2
    os.environ["NATS_SERVER_PORT"] = "server_port_env"
    connector.get_port(nats_config)
    assert connector.config["port"] == "server_port_env"


def test_getpassword(connector, nats_config):  # pylint: disable=redefined-outer-name
    """Test getpassword"""
    nats_config.pop("password")
    with pytest.raises(RuntimeError) as exc:
        connector.get_password(nats_config)
        err_msg = (
            "Something went wrong while getting the NATS password: "
            "NATS password is still None while a user is set"
        )
        assert str(exc) == err_msg

    os.environ["NATS_PASSWORD"] = "pwd_from_env"
    nats_config["password"] = "pwd_from_config"
    connector.get_password(nats_config)
    assert connector.config["password"] == "pwd_from_env"

    os.environ.pop("NATS_PASSWORD")
    nats_config.pop("password")
    with mock.patch(
        "package.svom.messaging.connector.get_docker_secret", return_value="Shush!"
    ) as mocked:
        connector.get_password(nats_config)
        os.environ["NATS_PWD_SECRET"] = "secret_from_env"
        connector.get_password(nats_config)
        calls = [
            mock.call("nats_password", secrets_dir="/run/secrets"),
            mock.call("secret_from_env", secrets_dir="/run/secrets"),
        ]
        mocked.assert_has_calls(calls)


def test_get():
    """Test get"""
    with mock.patch(
        "package.svom.messaging.connector.JetStreamIo.__init__", return_value=None
    ) as mocked:
        for key in os.environ:
            if key.startswith("NATS"):
                os.environ.pop(key)
        config = {}
        config["host"] = "svomtest.svom.fr"
        config["port"] = "4222"
        config["streaming_id"] = "my-module"
        config["password"] = "password"

        # Nats Streaming Client
        nats_client = NatsConnector(config).get()
        # Nats Server Client
        config["user"] = "svom"
        stan_client = NatsConnector(config).get()
        calls = [
            mock.call(
                config["host"], config["port"], streaming_id=config["streaming_id"]
            ),
            mock.call(
                config["host"],
                config["port"],
                streaming_id=config["streaming_id"],
                user=config["user"],
                password=config["password"],
            ),
        ]
        mocked.assert_has_calls(calls)
