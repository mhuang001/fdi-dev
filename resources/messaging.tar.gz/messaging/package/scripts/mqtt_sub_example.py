#!/usr/scripts/package3
"""
Here is an example to subscribe to the topic test (you can change the topic you
want to subsribe to by giving a --chanels (one or several) to the command line).
For several channel like test1 and test2, has to be given --channels "test1" "test2"

To connect to the Mqtt broker example at IJCLAB, try:
package3 mqtt_sub_example.py --host svom-fsc-2.lal.in2p3.fr --port 20083
adding the password
"""

from svom.messaging import MqttIo
from svom.messaging import mqttio_from_args
import logging
import sys

log = logging.getLogger("submit script")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)


# Define call back methods for the client. A number of callback functions are
# available in the Paho client library to receive data back from the broker.
# Below, we define the on_message (to print the message we publish on the topic).
# If None is given, it will take the default one of the MqttIo class.
def on_message(client, userdata, message):
    if hasattr(message, "topic"):
        # NATS
        topic = message.topic
    else:
        raise AttributeError(
            "Provided msg does not have the correct " "attributes for a 'Msg' class."
        )
    # Print to log
    log.info("Message received on channel '%s': %s", topic, message.payload.decode("utf-8"))


def main():
    """
    Instantiate MQTT client and subscribe to {args.channels}
    """
    # If a deconnection occured, the clean session argument should be False when
    # subcriscriptsg for the topic to be persistent. To get the messages sent during,
    # the deconnection, the same client id has to be used when connecting again.
    mqtt_client, args = mqttio_from_args(
        clean_session=False, client_id="Test", on_message=on_message
    )

    if args.channels is None:
        args.channels = ["test"]

    for channel in args.channels:
        mqtt_client.subscribe(channel, qos=1)


if __name__ == "__main__":
    main()
