# -*- coding: utf-8 -*-
class ContainerMockUp(object):
    pass


class SequenceMockUp(object):
    pass


class MappingMockUp(object):
    pass
