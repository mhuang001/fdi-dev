#!/bin/bash
##########################################################################
# This script first checks if a modification was made in your documentation
# folder defined in $SPHINX_FOLDER. 
# Then it performs:
#    - clone $FSC_DOCUMENTATION_PROJECT project within on the machine
#      hosting the gitlab-runner.
#    - compile your compilation with instructions provided in 
#      $DOC_COMPILATION_CMD
#    - copy the changes in new branch of $FSC_DOCUMENTATION_PROJECT
#      in the folder defined by $PROJECT_DOC_NAME.
#    - add and commit changes
#    - perform a Merge request to $FSC_DOCUMENTATION_PROJECT
#    - or a push if a merge request was already opened.

# Author: David Corre, corre@iap.fr
#######################################################################

# Load results of git diff
changes=`cat git_diff.txt`

if [ -z $changes ]
then
    # No changes in documentation folder
    echo "git diff found no changes in $SPHINX_FOLDER. No need to update published documentation."
else
    # Set path where to store your documentation in $FSC_DOCUMENTATION_PROJECT project
    if [ -z $PROJECT_DOC_NAME ]
    then
        doc_path=$CI_PROJECT_NAME;
    else
        doc_path=$PROJECT_DOC_NAME;
    fi

    # make sure there is no existing $FSC_DOCUMENTATION_PROJECT/
    cd .. && rm -fr $FSC_DOCUMENTATION_PROJECT

    # clone latest version of $FSC_DOCUMENTATION_PROJECT package
    git clone -b $FSC_DOCUMENTATION_BRANCH --single-branch $FSC_DOCUMENTATION_GIT
    cd $FSC_DOCUMENTATION_PROJECT
    
    echo "Add a temporary remote, named CI_remote.";
    # Need to add a remote URL to not use the token used by the CI
    # First try to add the remote and if already existing (when updating a MR) then
    # make sure it points to corect URL by resetting it.
    git remote add CI_remote $FSC_DOCUMENTATION_GIT || git remote set-url CI_remote $FSC_DOCUMENTATION_GIT
    echo "Do not pay attention of the message stating fatal error on line above, if any.";

    # Fetch branches from remote
    git fetch CI_remote    

    # Check if branch we will create already exists on origin remote
    branch_exists=$(git branch -r | grep "CI_remote/feature/$CI_PROJECT_NAME")
    
    # Create new branch
    if [ -z "$branch_exists" ]
    then
	echo "Branch feature/$CI_PROJECT_NAME does not exist on remote."
	# Create new branch from $FSC_DOCUMENTATION_BRANCH
        git switch -c "feature/"$CI_PROJECT_NAME;
    else
	echo "Branch feature/$CI_PROJECT_NAME already exists on remote."
	# Create new branch synchronised with the one on origin remote
	git checkout "feature/"$CI_PROJECT_NAME;
	# Make sure to be up-to-date with $FSC_DOCUMENTATION_BRANCH
	git pull origin $FSC_DOCUMENTATION_BRANCH;
    fi

    # Make directory and __init__.py, if not existing
    mkdir -p ui/$doc_path/templates/$doc_path
    touch ui/$doc_path/templates/__init__.py

    # Go back to your project folder
    cd ../$CI_PROJECT_NAME

    # Compile your documentation
    cd $SPHINX_FOLDER && eval $DOC_COMPILATION_CMD && cd ..

    # Copy sphinx compiled folder to $FSC_DOCUMENTATION_PROJECT project
    cp -r $SPHINX_FOLDER/build/html/* ../$FSC_DOCUMENTATION_PROJECT/ui/$doc_path/templates/$doc_path/.

    echo "The HTML pages are in $SPHINX_FOLDER/build/html."
    if mv $SPHINX_FOLDER/build/html/searchindex.js $SPHINX_FOLDER/build/html/_static/;
    then
        echo "File searchindex.js moved to _static."
    else
            echo "File searchindex.js not in $SPHINX_FOLDER/build/html."
    fi
    sed -i 's#"searchindex.js"#"_static/searchindex.js"#g' $SPHINX_FOLDER/build/html/search.html

    # Copy sphinx compiled folder to $FSC_DOCUMENTATION_PROJECT project
    cp -r $SPHINX_FOLDER/build/html/* ../$FSC_DOCUMENTATION_PROJECT/ui/$doc_path/templates/$doc_path/.

    # Go to $FSC_DOCUMENTATION_PROJECT folder
    cd ../$FSC_DOCUMENTATION_PROJECT

    # Simply add your whole documentation folder
    # Use -f if some files format are ignored by .gitignore
    git add ui/$doc_path

    # Display results of a git status, useful in case of a problem
    echo " ";
    echo "Git status after git add:";
    git status
    echo " ";

    echo "Commit changes modified files."
    # Commit changes with specific commit message
    git commit -m "CI commit for documentation update."

    # Check whether a merge request is already opened
    check_mr=$(curl --header "PRIVATE-TOKEN: NPCBQb3Qv6ARps9y3XAG" "https://drf-gitlab.cea.fr/api/v4/projects/1881/merge_requests?state=opened&source_branch=feature/$CI_PROJECT_NAME&target_branch=$FSC_DOCUMENTATION_BRANCH")

    if [ "$check_mr" == "[]" ]
    then
        # No opened merge request
        # Create merge request to $FSC_DOCUMENTATION_PROJECT project, on $FSC_DOCUMENTATION_BRANCH
        # assigning Maxime Bocquier.
        echo " "
        echo "Create Merge Request to $FSC_DOCUMENTATION_PROJECT project."
        git push -o merge_request.create CI_remote -o merge_request.target=$FSC_DOCUMENTATION_BRANCH -o merge_request.assign=282 -o merge_request.title="Update documentation for project $CI_PROJECT_NAME." "feature/"$CI_PROJECT_NAME || exit 1
    else
        # Merge request already opened
	# Push to branch to update opened MR
        echo " "
        echo "Push changes to already opened Merge Request in $FSC_DOCUMENTATION_PROJECT project."
	git push CI_remote HEAD:"feature/"$CI_PROJECT_NAME || exit 1
    fi
	    
    echo " "
    echo "Remove remote CI_remote."
    # Remove remote CI_remote
    git remote remove CI_remote
fi
