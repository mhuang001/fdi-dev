"""
HTTP client tool to exchange with SAT-DB

Retries requests with power law delays and a max tries limit

@author: andrea.formica@cea.fr
"""

# Log
import logging

# Time zone
import datetime
import pytz

# JSON
from svom.messaging.httpio import HttpIo
from svom.messaging.utils import get_auxhk_url
from svom.messaging.request_utils import kwargs_are_valid

log = logging.getLogger("auxhkdb_client")


def convert_iso_time_utc(since=None, until=None):
    """
    If the timefield is given in iso format, convert the given time zone to UTC+00.

    By default, take local time zone. If you want to specified the timezone, you should add a +
    at then end of the string like in the following for time zone UTC+2:
    since="2017-01-01T01:15:10+02:00".

    Parameters
    ----------
    since : string, optional
        Python ISO format string YYYY-MM-DDTHH:MM:SS
    until : string, optional
        Python ISO format string YYYY-MM-DDTHH:MM:SS

    Returns
    -------
    since_m, until_m : string
        ISO string in UTC YYYYMMDDTHHMMSSUTC
    """

    since_m = None
    until_m = None
    if since is not None:
        date_time = datetime.datetime
        strf_time = date_time.fromisoformat(since).astimezone(pytz.utc).strftime("%Y%m%dT%H%M%S%Z")
        since_m = strf_time
    if until is not None:
        date_time = datetime.datetime
        strf_time = date_time.fromisoformat(until).astimezone(pytz.utc).strftime("%Y%m%dT%H%M%S%Z")
        until_m = strf_time

    return since_m, until_m


def update_timefield_kwargs(since, until, timeformat, timefield, valid_keys):
    """Check the validity of timefield. If valid update the critria for the time request.

    Parameters
    ----------
    since : string
        start time specify in timefield
    until : string
        end time specify in timefield
    timeformat : string
        dateformat for the time argument search. Can be sec or Python ISO
        format string YYYY-MM-DDTHH:MM:SS.
    timefield : string
        Time name on which the query is made
    valid_keys : list of string
        valid list of Time name
    """
    # check request validity
    if timefield.lower() not in valid_keys:
        log.error("%s is not in the valid arguments list: %s", timefield.lower(), valid_keys)
        return False
    timefield_kwargs = {}
    # prepare request arguments
    if timeformat == "iso":
        since, until = convert_iso_time_utc(since, until)
    if since is not None:
        timefield_kwargs["since"] = since
    if until is not None:
        timefield_kwargs["until"] = until
    timefield_kwargs.update({"timeformat": timeformat, "timefield": timefield})
    return timefield_kwargs


class AuxHkIo(HttpIo):
    """(A)synchronous HTTP client with the Aux HK Database.

    Parameters
    ----------
    server_url :  str, optional
        root server url share by all the endpoints.
    max_tries : int, optional
        Number of connection attemps
    asynchronous : bool, optional
        True if asynchronous communication.
    loop : optional
        asyncio event loop to use if asynchronous is True. If none, start one.
    use_tokens : bool, optional
        True if Authorization token has to be used.
    tokens : dict, optional
        if not None, these tokens will be used instead of requesting keycloak,
        except if the tokens is not valid anymore.
    """

    def __init__(
        self,
        server_url="https://fsc.svom.org/auxhkmgr",
        max_tries=2,
        asynchronous=False,
        loop=None,
        use_tokens=True,
        tokens=None,
    ):
        server_url = get_auxhk_url(server_url)
        super().__init__(
            server_url,
            max_tries=max_tries,
            asynchronous=asynchronous,
            loop=loop,
            use_tokens=use_tokens,
            tokens=tokens,
        )
        self.endpoints = {
            "oem": "/api/fpoc/oem",
            "oef": "/api/fpoc/oef",
            "workplan": "/api/fpoc/workplan",
            "obsids": "/api/fpoc/obsids",
        }

        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def search_oem(
        self,
        since=None,
        until=None,
        timefield=None,
        timeformat="iso",
        page=0,
        size=100,
        sort="oemTime:ASC",
        **kwargs,
    ):
        """Request and export oem data from svom.messaging.he database in json format

        *Additional valid filters for the request in kwargs: oemid.*

        usage example:

        ::

            search_oem(timefield="oemtime", since="2020-01-30T10:00:00")

        Parameters
        ----------
        since : string, optional
            start time specify in timefield
        until : string, optional
            end time specify in timefield
        timefield : string, optional
            Time name on which the query is made. Possible name: "oemtime",
            "insertiontime", "updatetime"
        timeformat : string, optional
            dateformat for the time argument search. Can be sec or Python ISO
            format string YYYY-MM-DDTHH:MM:SS.
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        kwargs: dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Aux HK DB response
        """
        # define output fields
        valid_filters = ["oemid"]
        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}

        if timefield is not None:
            timefield_kwargs = update_timefield_kwargs(
                since=since,
                until=until,
                timefield=timefield,
                timeformat=timeformat,
                valid_keys=["oemtime", "insertiontime", "updatetime"],
            )
            if not timefield_kwargs:
                return {}
            kwargs.update(timefield_kwargs)

        kwargs.update({"page": page, "size": size, "sort": sort})
        # send request
        resp = self.get(self.endpoints["oem"], params=kwargs)
        return resp

    def search_oef(
        self,
        since=None,
        until=None,
        timefield=None,
        timeformat="iso",
        page=0,
        size=100,
        sort="oefTime:ASC",
        **kwargs,
    ):
        """Request and export oef data from svom.messaging.he database in json format

        *Additional valid filters for the request in kwargs: oefid, eventcode, hashid.*

        usage example:

        ::

            search_oef(timefield="oeftime", since="2020-01-30T10:00:00")

        Parameters
        ----------
        since : string, optional
            start time specify in timefield
        until : string, optional
            end time specify in timefield
        timefield : string, optional
            Time name on which the query is made. Possible name: "oeftime",
            "insertiontime", "updatetime".
        timeformat : string, optional
            dateformat for the time argument search. Can be sec or Python ISO
            format string YYYY-MM-DDTHH:MM:SS.
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        kwargs: dict, optional
            additional parameters given for the request. Should be in
            valid_filters. eventcode can be a comma separated list containing
            string of the event Code.

        Returns
        -------
        resp : `requests.models.Response`
            Aux HK DB response
        """
        # define output fields
        valid_filters = ["oefid", "eventcode", "hashid"]

        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}

        if "eventcode" in kwargs:
            # No space in the comma, separated list
            kwargs["eventcode"] = kwargs["eventcode"].replace(" ", "")
        if timefield is not None:
            timefield_kwargs = update_timefield_kwargs(
                since=since,
                until=until,
                timefield=timefield,
                timeformat=timeformat,
                valid_keys=["oeftime", "insertiontime", "updatetime"],
            )
            if not timefield_kwargs:
                return {}
            kwargs.update(timefield_kwargs)

        kwargs.update({"page": page, "size": size, "sort": sort})
        # send request
        resp = self.get(self.endpoints["oef"], params=kwargs)
        return resp

    def search_workplan(
        self,
        since=None,
        until=None,
        timefield=None,
        timeformat="iso",
        page=0,
        size=100,
        sort="productionDate:ASC",
        **kwargs,
    ):
        """Request and export workplan data from svom.messaging.he database in json format.

        *Additional valid filters for the request in kwargs: workplanid, workplantype,
        hashid*

        If timefield:

        * | = workplandate, it assumes that since > match the start date
          | and > until then end date. The request < > is made between the start and
          | the end date.
        * = workplanbegindate, the request < > is made only on the WP start date
        * = workplanenddate, the request < > is made only on the WP end date


        usage example:

        ::

            search_workplan(timefield="workplandate", "since="20200130T100000Z")

        Parameters
        ----------
        since : string, optional
            start time specify in timefield
        until : string, optional
            end time specify in timefield
        timefield : string, optional
            Time name on which the query is made. Possible name: "workplandate",
            "insertiontime", "updatetime", "workplanbegindate", "workplanenddate"
        timeformat : string, optional
            dateformat for the time argument search. Can be sec or Python ISO
            format string YYYY-MM-DDTHH:MM:SS.
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        kwargs: dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Aux HK DB response
        """
        # define output fields
        valid_filters = ["workplanid", "workplantype", "hashid"]
        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}

        if timefield is not None:
            timefield_kwargs = update_timefield_kwargs(
                since=since,
                until=until,
                timefield=timefield,
                timeformat=timeformat,
                valid_keys=[
                    "insertiontime",
                    "updatetime",
                    "workplandate",
                    "workplanbegindate",
                    "workplanenddate",
                ],
            )
            if not timefield_kwargs:
                return {}
            kwargs.update(timefield_kwargs)

        kwargs.update({"page": page, "size": size, "sort": sort})
        # send request
        resp = self.get(self.endpoints["workplan"], params=kwargs)
        return resp

    def search_obsid(
        self,
        since=None,
        until=None,
        timefield=None,
        timeformat="iso",
        page=0,
        size=100,
        sort="productionDate:ASC",
        **kwargs,
    ):
        """Request and export data from svom.messaging.he database in json format

        *Additional valid filters for the request in kwargs: obsid, obstype,
        hashid.*

        If timefield:

        * | = obsiddate, it assumes that since > match the start date
          | and > until then end date. The request < > is made between the start and
          | the end date.
        * = obsidbegindate, the request < > is made only on the WP start date
        * = obsidenddate, the request < > is made only on the WP end date

        usage example:

        ::

            search_obsid(timefield="workplandate", "since="20200130T100000Z")

        Parameters
        ----------
        since : string, optional
            start time specify in timefield
        until : string, optional
            end time specify in timefield
        timefield : string, optional
            Time name on which the query is made. Possible name: "obsiddate",
            "insertiontime", "updatetime", "obsidbegindate", "obsidenddate"
        timeformat : string, optional
            dateformat for the time argument search. Can be sec or Python ISO
            format string YYYY-MM-DDTHH:MM:SS.
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        kwargs: dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Aux HK DB response
        """
        # define output fields
        valid_filters = ["obsid", "obstype", "hashid"]
        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}

        if timefield is not None:
            timefield_kwargs = update_timefield_kwargs(
                since=since,
                until=until,
                timefield=timefield,
                timeformat=timeformat,
                valid_keys=[
                    "insertiontime",
                    "updatetime",
                    "obsiddate",
                    "obsidbegindate",
                    "obsidenddate",
                ],
            )
            if not timefield_kwargs:
                return {}
            kwargs.update(timefield_kwargs)

        kwargs.update({"page": page, "size": size, "sort": sort})
        # send request
        resp = self.get(self.endpoints["obsids"], params=kwargs)
        return resp

    def create_set(self, resources, resourcetype="oem", insmode="update", startdate=0):
        """Generate a set dto with appropriate resources for later storage

        Parameters
        ----------
        resources : list
            list of resources
        resourcetype : str, default oem
            type of resources: oem, oef or workplan
        insmode : str, default update
            inseration mode: update or force
        startdate : str, optional
            startdate of the resources in the form "%Y-%m-%dT%H:%M:%SZ.

        Returns
        -------
        resp : `requests.models.Response`
            Aux HK DB response
        """
        set_dic = {
            "oem": {"format": "OemSetDto", "datatype": "OemDto"},
            "oef": {"format": "OefSetDto", "datatype": "OefDto"},
            "workplan": {"format": "WorkplanSetDto", "datatype": "WorkplanDto"},
            "obsids": {"format": "ObsidTableSetDto", "datatype": "ObsidTableDto"},
        }
        # prepare request arguments
        body_req = {
            "insertionmode": insmode,
            "startdate": startdate,
            "size": len(resources),
            "format": set_dic[resourcetype]["format"],
            "datatype": set_dic[resourcetype]["datatype"],
            "resources": resources,
        }

        # send request
        resp = self.post(self.endpoints[resourcetype], json=body_req, headers=self.headers)

        return resp
