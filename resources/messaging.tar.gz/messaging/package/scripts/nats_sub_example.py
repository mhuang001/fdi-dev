#!/usr/scripts/package3
"""
 Simple subscriber example using the svom.messaging.natsio module
 Usage info: package3 sub_example.py --help

 Henri Louvin - henri.louvin@cea.fr
"""

# Log
import sys
import logging

log = logging.getLogger("sub_example")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
# NATS
from svom.messaging import natsio_from_args


async def print_to_log(msg):
    """
    Basic function printing message content to log
    """
    # 'Msg' object is different for streaming server
    channel = ""
    if hasattr(msg, "subject"):
        # NATS
        channel = msg.subject
    elif hasattr(msg, "proto"):
        # NATS Streaming
        channel = msg.proto.subject
    else:
        raise AttributeError(
            "Provided msg does not have the correct " "attributes for a 'Msg' class."
        )
    # Print to log
    log.info("Message received on channel '%s': %s", channel, msg.data)


def main():
    """
    Instantiate NATS client and subscribe to {args.channels}
    """
    # Retrieve nats_client and channels list from command line
    nats_client, args = natsio_from_args()

    # Subscribe logger to all channels
    for channel in args.channels:
        nats_client.subscribe(channel, print_to_log)


if __name__ == "__main__":
    main()
