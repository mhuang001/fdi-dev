"""
HTTP client tool to exchange with XBAND-DB

Retries requests with power law delays and a max tries limit

@author: lea.jouvin@cea.fr
"""

# Log
import logging

# Time zone
import datetime
import pytz
from requests_toolbelt.multipart import encoder

from svom.messaging.httpio import HttpIo
from svom.messaging.utils import get_xbanddb_urls
from svom.messaging.request_utils import kwargs_are_valid

log = logging.getLogger("xband_client")


def convert_iso_time_utc(kwargs):
    """If packettimefrom, packettimeto are in iso format, convert the given time zone to UTC+00.

    By default, take local time zone.
    """
    if "packettimefrom" in kwargs:
        date_time = datetime.datetime
        strf_time = (
            date_time.fromisoformat(kwargs["packettimefrom"])
            .astimezone(pytz.utc)
            .strftime("%Y%m%dT%H%M%S%Z")
        )
        kwargs["packettimefrom"] = strf_time
    if "packettimeto" in kwargs:
        date_time = datetime.datetime
        strf_time = (
            date_time.fromisoformat(kwargs["packettimeto"])
            .astimezone(pytz.utc)
            .strftime("%Y%m%dT%H%M%S%Z")
        )
        kwargs["packettimeto"] = strf_time


class XBandDbIo(HttpIo):
    """
    (A)synchronous HTTP client with the Xband Database.

    The Xband manager provding the Xband Database is made of two services:

        * xband-l0c : managing the tar and dat file
        * xband-packets : managing the packets

    Parameters
    ----------
    server_url_l0c :  str, optional
        root server url for the L0c service share by all the endpoints.
    server_url_packets : str, optional
        root server url for the packets service share by all the endpoints.
    max_tries : int, optional
        Number of connection attemps
    asynchronous : bool, optional
        True if asynchronous communication.
    loop : optional, optional
        asyncio event loop to use if asynchronous is True. If none, start one.
    use_tokens : bool, optional
        True if Authorization token has to be used.
    tokens : dict, optional
        if not None, these tokens will be used instead of requesting keycloak,
        except if the tokens is not valid anymore.
    """

    def __init__(
        self,
        server_url_l0c="https://fsc.svom.org/xbsvc_lc",
        server_url_packets="https://fsc.svom.org/xbsvc_packets",
        # pylint: disable=R0913
        max_tries=5,
        asynchronous=False,
        loop=None,
        use_tokens=True,
        tokens=None,
    ):
        server_url_l0c, server_url_packets = get_xbanddb_urls(server_url_l0c, server_url_packets)
        super().__init__(
            "",
            max_tries=max_tries,
            asynchronous=asynchronous,
            loop=loop,
            use_tokens=use_tokens,
            tokens=tokens,
        )
        self.endpoints = {
            "apids": f"{server_url_l0c.rstrip('/')}/api/apids",
            "dat": f"{server_url_l0c.rstrip('/')}/api/lc/dat",
            "tar": f"{server_url_l0c.rstrip('/')}/api/lc/tar",
            "passids": f"{server_url_l0c.rstrip('/')}/api/lc/passids",
            "view": f"{server_url_l0c.rstrip('/')}/api/lc/dat/view",
            "packets": f"{server_url_packets.rstrip('/')}/api/packets",
            "frames": f"{server_url_packets.rstrip('/')}/api/frames",
        }

        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }

    def search_apid_info(self, page=0, size=100, sort="apidValue:ASC", **kwargs):
        """Request and export apid info from svom.messaging.he database in json format.

        *Additional valid filters for the request in kwargs : pass_id*

        usage example:

        ::

            search_apid_info(name="ECL")

        Parameters
        ----------
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Xband DB response
        """
        valid_filters = ["pass_id"]

        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}

        # prepare request arguments
        kwargs.update({"page": page, "size": size, "sort": sort})
        # send request
        resp = self.get(self.endpoints["apids"], params=kwargs)
        return resp

    def search_obs_id_info_by_passid(self, pass_id, apid=None):
        """Return the obs id list for one specific pass_id and apid if given.

        usage example:

        ::

            search_obs_id_info_by_pass(pass_id="012012_02023")

        Parameters
        ----------
        pass_id : str
            pass id of the xband pass
        apid : int
            apid number

        Returns
        -------
        resp : `requests.models.Response`
            Xband DB response
        """
        # prepare request arguments
        kwargs = {"pass_id": pass_id}
        if apid is not None:
            kwargs.update({"apid": apid})

        # send request
        resp = self.get(self.endpoints["view"], params=kwargs)
        return resp

    def search_apid_info_by_passid(self, pass_id):
        """Return the apid list for one specific pass_id

        usage example:

        ::

            search_apid_info_by_pass(pass_id="012012_02023")

        Parameters
        ----------
        pass_id : str
            pass id of the xband pass

        Returns
        -------
        resp : `requests.models.Response`
            Xband DB response
        """
        # prepare request arguments
        kwargs = {"pass_id": pass_id, "field": "apid"}

        # send request
        resp = self.get(self.endpoints["view"], params=kwargs)
        return resp

    def search(self, page=0, size=100, sort="pktOrder:ASC", **kwargs):
        """Request and export data from svom.messaging.he database in json format

        *Additional valid filters for the request in kwargs : frameid, lc_filename, tar_filename,
        isframevalid, isframeduplicate, station, orbit, apid, obsidtype, obsidnum,
        packetid, packettimefrom, packettimeto, timeformat.*

        *The param packetid can be an integer or a comma separated list*

        The time selection is only allowed on the packettime, packettimefrom svom.messaging.nd
        packettimeto are the ranges of the selection. You can specify the time
        format in the parameter timeformat.

        *timeformat*: the format to digest previous arguments [iso], [sec], [svom] :

            * Time(iso) = Python ISO format YYYY-MM-DDTHH:MM:SS
            * Time(sec) = seconds
            * | [svom] = The packet time is in seconds (so [svom] format represents
              | seconds from svom.messaging.VOM epoch)

        If the timeformat is equal to iso, by default packettimefrom svom.messaging.nd
        packettimeto are in local time machine, automatically convert to UTC. If
        you want to specified the timezone, you should add a + at then end of
        the string like in the following for time zone UTC+2:
        packettimefrom="2017-01-01T01:15:10+02:00".

        usage example:

        ::

            search(apid=576, obsid=1002)

        Parameters
        ----------
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Xband DB response
        """
        # define output fields
        valid_filters = [
            "frameid",
            "lc_filename",
            "tar_filename",
            "isframevalid",
            "isframeduplicate",
            "station",
            "orbit",
            "apid",
            "obsidtype",
            "obsidnum",
            "packetid",
            "packettimefrom",
            "packettimeto",
            "timeformat",
        ]

        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}

        # prepare request arguments
        kwargs.update({"page": page, "size": size, "sort": sort})
        if "timeformat" in kwargs and kwargs["timeformat"] == "iso":
            convert_iso_time_utc(kwargs)

        # send request
        resp = self.get(self.endpoints["frames"], params=kwargs)
        return resp

    def search_lc(self, file_type="tar", page=0, size=100, sort=None, **kwargs):
        """Get the L0C filename ingest by the XBandDB.

        *Additional valid filters for the request in kwargs : lcfilename, station, orbit,
        pass_id (form: orbit_station), apid, starttime, timeformat*

        The time selection is only allowed on the packettime, packettimefrom svom.messaging.nd
        packettimeto are the ranges of the selection. You can specify the time
        format in the parameter timeformat.

        *timeformat*: the format to digest previous arguments [iso], [sec], [svom] :

            * Time(iso) = Python ISO format YYYY-MM-DDTHH:MM:SS
            * Time(sec) = seconds
            * | [svom] = The packet time is in seconds (so [svom] format represent
              | seconds from svom.messaging.VOM epoch).

        If the timeformat is equal to iso, by default packettimefrom svom.messaging.nd
        packettimeto are in local time machine, automatically convert to UTC. If
        you want to specified the timezone, you should add a + at then end of
        the string like in the following for time zone UTC+2:
        packettimefrom="2017-01-01T01:15:10+02:00".

        Parameters
        ----------
        file_type : str, optional
            tar or dat to speficy if we search for the tarfile or the datfile
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Xband DB response
        """
        # define output fields
        valid_filters = [
            "lcfilename",
            "station",
            "pass_id",
            "orbit",
            "apid",
            "starttime",
            "timeformat",
        ]
        if file_type == "dat":
            valid_filters.append("endtime")

        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}
        if "timeformat" in kwargs and kwargs["timeformat"] == "iso":
            convert_iso_time_utc(kwargs)
        # The request con be done only on station and orbit, it pass_id is given,
        # divides it in orbit and station
        if "pass_id" in kwargs:
            orbit = kwargs["pass_id"].split("_")[0]
            station = kwargs["pass_id"].split("_")[1]
            kwargs.pop("pass_id")
            kwargs.update({"station": station, "orbit": orbit})

        if sort is None and file_type == "tar":
            sort = "tarName:ASC"
        elif sort is None and file_type == "dat":
            sort = "lcfileName:ASC"
        # prepare request arguments
        kwargs.update({"page": page, "size": size, "sort": sort})

        resp = self.get(self.endpoints[file_type], params=kwargs)
        return resp

    def search_pass_ids(self, page=0, size=100, sort="pktOrder:ASC", **kwargs):
        """Request and export pass ids list from svom.messaging.he database in json format
        usage example: search_pass_ids(station="KR001")

        *Additional valid filters for the request in kwargs : station, orbit, starttime,
        timeformat.*

        Parameters
        ----------
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Xband DB response
        """
        # define output fields
        valid_filters = ["station", "orbit", "starttime"]

        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}

        # prepare request arguments
        kwargs.update({"page": page, "size": size, "sort": sort})

        # send request
        resp = self.get(self.endpoints["passids"], params=kwargs)
        return resp

    def download_l0c_file(self, lcfilename):
        """Download L0c file from svom.messaging.ilename

        Parameters
        ----------
        lcfilename : str
            l0c filename to download

        Returns
        -------
        status_resp : int
            Response status code
        """
        # NOTE the stream=True parameter below
        with self.get(self.endpoints["dat"] + f"/{lcfilename}", stream=True) as http_resp:
            http_resp.raise_for_status()
            status_resp = http_resp.status_code
            with open(lcfilename, "wb") as file:
                for chunk in http_resp.iter_content(chunk_size=8192):
                    # If you have chunk encoded response uncomment if
                    # and set chunk_size parameter to None.
                    # if chunk:
                    file.write(chunk)
        return status_resp

    def dump_packets(self, pass_id, apid, fout="./out.blob", obsid=None, packetid=None):
        """Retrieve data from svom.messaging.he database and dump the packets to a file with
        the name fout.

        Required parameters are pass_id and apid.

        usage example:

        ::

            dump_packets(obsid=1, apid=576, station="STA", orbit=1,
            packetid=1, fout="/tmp/out.blob")

        Parameters
        ----------
        pass_id : str
            pass id of the packets in the form orbit_station
        apid : int
            apid of the packets
        fout : str, optional
            filename where are dump the packets
        obsid : int, optional
            obs id of the packets
        packetid : int, optional
            packetid of the packets

        Returns
        -------
        status_resp : int
            Response status code
        """
        orbit = pass_id.split("_")[0]
        station = pass_id.split("_")[1]
        # prepare request arguments
        criteria = {"apid": apid, "station": station, "orbit": orbit}

        if obsid is not None:
            criteria["obsid"] = obsid
        if packetid is not None:
            criteria["packetid"] = packetid

        # send request
        pkt_url = self.endpoints["packets"]
        loc_url = pkt_url
        status_resp = 0
        with self.get(loc_url, params=criteria) as http_resp:
            status_resp = http_resp.status_code
            http_resp.raise_for_status()
            with open(fout, "wb") as file:
                for chunk in http_resp.iter_content(chunk_size=8192):
                    # If you have chunk encoded response uncomment if
                    # and set chunk_size parameter to None.
                    # if chunk:
                    file.write(chunk)
        return status_resp

    def dump_packets_by_time(
        self, since, until, apid, fout="./out.blob", obsid=None, packetid=None
    ):
        """Retrieve data betwen since and until from svom.messaging.he database and dump the packets to a file.

        Required parameters are since, until and apid

        usage example:

        ::

            dump_packets(apid=576, since=194758284, until=194758313, orbit=1,
            packetid=1, fout="/tmp/out.blob")

        Parameters
        ----------
        since : int
            Number of seconds since SVOM reference time
        until : int
            Number of seconds since SVOM reference time
        apid : int
            apid of the packets
        fout : str, optional
            filename where are dump the packets
        obsid : int, optional
            obs id of the packets
        packetid : int, optional
            packetid of the packets


        Returns
        -------
        status_resp : int
            Response status code
        """
        # prepare request arguments
        criteria = {"apid": apid, "since": since, "until": until}

        since_t = datetime.datetime.fromtimestamp(since)
        until_t = datetime.datetime.fromtimestamp(until)
        delta_max = datetime.timedelta(hours=12)
        if until_t - since_t > delta_max:
            raise ValueError("The maximum duration between since and until is 12 hours")

        if obsid is not None:
            criteria["obsid"] = obsid
        if packetid is not None:
            criteria["packetid"] = packetid

        # send request
        pkt_url = self.endpoints["packets"]
        loc_url = pkt_url
        status_resp = 0
        with self.get(loc_url, params=criteria) as http_resp:
            status_resp = http_resp.status_code
            http_resp.raise_for_status()
            with open(fout, "wb") as file:
                for chunk in http_resp.iter_content(chunk_size=8192):
                    # If you have chunk encoded response uncomment if
                    # and set chunk_size parameter to None.
                    # if chunk:
                    file.write(chunk)
        return status_resp

    def upload(self, filepath=None):
        """Import data into the database.

        usage example:

        ::

            create_payload(filepath="/tmp/temp-01.txt")

        Parameters
        ----------
        filepath : str, optional
            should contain the filemanme path + filename


        Returns
        -------
        resp : `requests.models.Response`
            Xband DB response
        """
        if filepath is None:
            raise ValueError("You didn't give any files to upload")
        # define output fields
        filename = filepath.split("/")[-1]

        # prepare request arguments
        with open(filepath, "rb") as f_in:
            form = encoder.MultipartEncoder(
                {"file": (filename, f_in), "lcFileName": (None, filename)}
            )

            loc_headers = {
                "source": "remote",
                "Prefer": "respond-async",
                "Content-Type": form.content_type,
            }
            resp = self.post(self.endpoints["tar"], headers=loc_headers, data=form)

        return resp

    def get_upload_status(self, **kwargs):
        """Get the status of the upload.

        When the packets and the meta data are registered the procStatus is equal to END_META.

        Parameters
        ----------
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Xband DB response
        """
        # define output fields
        valid_filters = ["lcfilename", "tarfilename", "orbit", "station"]

        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}

        # send request
        resp = self.get(self.endpoints["dat"] + "/status", params=kwargs)
        return resp

    def delete_datfile(self, filename=None):
        """Delete Datfile and packets from svom.messaging.he Database

        Parameters
        ----------
        filename : str, optional
            filename to delete in the database

        Returns
        -------
        resp : `requests.models.Response`
            Xband DB response
        """
        resp = self.delete(self.endpoints["frames"], params={"lcFileName": filename})
        return resp
