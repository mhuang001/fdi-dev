"""Init for module"""
"""
Base python module for Svom codes
"""
__import__("pkg_resources").declare_namespace(__name__)
