"""
VhfDbIo test file
"""
import logging
import os
import sys
from unittest import mock
from requests import Response
import pytest

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
from package.svom.messaging.vhfdbio import VhfDbIo

log = logging.getLogger("test_vhfio")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)


HTTPIO_REQUEST = "package.svom.messaging.httpio.requests.Session.request"


@pytest.fixture
def sync_200_response():
    """mimics 'requests' success response"""
    fake_response = Response()
    fake_response.status_code = 200
    fake_response.json = lambda: {"breakfast": "eggs"}
    return fake_response


@pytest.fixture(scope="function")
def vhf_client():
    """return sync VhfDbIos"""
    # with mock.patch('svom.messaging.tokens.KcTokens._request_tokens'):
    sync_client = VhfDbIo("fake://vhfmgr/", use_tokens=False)
    yield sync_client


def test_init():
    """Check that the use_tokens param is correctly passed to super()"""

    os.environ["KC_TYPE"] = "pipelines"
    client = VhfDbIo()
    assert client.kc_tokens is not None
    assert client.kc_tokens.tokens_with_expirations_dates is None


def test_search_data(
    vhf_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        response = vhf_client.search_data(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        response = vhf_client.search_data(
            since="2022-01-01T01:00:00+01:00",
            until="2022-02-02T01:00:00+01:00",
            apid=576,
        )
        response = vhf_client.search_data(
            since="2022-01-01T01:00:00+01:00",
            until="2022-02-02T01:00:00+01:00",
            apid=576,
            obsid=1,
            page=1,
            size=10,
        )
        # requests.get should have been called 2 times
        expected_calls = [
            mock.call(
                "GET",
                "fake://vhfmgr/api/vhf/data",
                params={
                    "since": "20220101T000000UTC",
                    "until": "20220202T000000UTC",
                    "apid": 576,
                    "timeformat": "iso",
                    "timefield": "insertionTime",
                    "page": 0,
                    "size": 1000,
                    "sort": "insertionTime:ASC",
                },
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
            ),
            mock.call(
                "GET",
                "fake://vhfmgr/api/vhf/data",
                params={
                    "since": "20220101T000000UTC",
                    "until": "20220202T000000UTC",
                    "apid": 576,
                    "timeformat": "iso",
                    "timefield": "insertionTime",
                    "obsid": 1,
                    "page": 1,
                    "size": 10,
                    "sort": "insertionTime:ASC",
                },
                headers={
                    "Content-Type": "application/json",
                    "Accept": "application/json",
                },
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_search_raw(
    vhf_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by insertiontime,flag"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        response = vhf_client.search_raw(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        response = vhf_client.search_raw(
            page=0,
            size=10,
            sort="insertionTime:ASC",
            since="10000000",
            until="20000000",
            timeformat="ms",
        )
        response = vhf_client.search_raw(
            page=0,
            size=10,
            sort="insertionTime:ASC",
            since="10000000",
            until="20000000",
            timeformat="ms",
            flag="OK",
        )
        # requests.get should have been called 2 times
        expected_calls = [
            mock.call(
                "GET",
                "fake://vhfmgr/api/vhf/raw",
                params={
                    "since": "10000000",
                    "until": "20000000",
                    "timeformat": "ms",
                    "page": 0,
                    "size": 10,
                    "sort": "insertionTime:ASC",
                },
            ),
            mock.call(
                "GET",
                "fake://vhfmgr/api/vhf/raw",
                params={
                    "since": "10000000",
                    "until": "20000000",
                    "flag": "OK",
                    "timeformat": "ms",
                    "page": 0,
                    "size": 10,
                    "sort": "insertionTime:ASC",
                },
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_bursts(vhf_client, sync_200_response):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        response = vhf_client.search_bursts(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        response = vhf_client.search_bursts(apidname="TmVhfEclairsAlert", burstid="sb%")
        # requests.get should have been called 1 time
        mocked.assert_called_once_with(
            "GET",
            "fake://vhfmgr/api/bursts",
            params={
                "burstid": "sb%",
                "apidname": "TmVhfEclairsAlert",
                "since": None,
                "until": None,
                "timefield": "insertionTime",
                "timeformat": "iso",
                "page": 0,
                "size": 100,
                "sort": "insertionTime:ASC",
            },
        )


def test_apid_info(
    vhf_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search_apids"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        with pytest.raises(TypeError):
            response = vhf_client.get_apid_info(bad_key="bad")
        mocked.assert_not_called()
        response = vhf_client.search_apid_info(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        vhf_client.get_apid_info(apid=576)
        vhf_client.search_apid_info(apid=576)
        vhf_client.search_apid_info(name="TmVhfEclairsAlert")
        # requests.get should have been called 3 times
        expected_calls = [
            mock.call("GET", "fake://vhfmgr/api/apids/576"),
            mock.call(
                "GET",
                "fake://vhfmgr/api/apids",
                params={"apid": 576, "page": 0, "size": 100, "sort": "name:ASC"},
            ),
            mock.call(
                "GET",
                "fake://vhfmgr/api/apids",
                params={
                    "name": "TmVhfEclairsAlert",
                    "page": 0,
                    "size": 100,
                    "sort": "name:ASC",
                },
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_stations_search(
    vhf_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search_apids"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        response = vhf_client.search_stations(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        vhf_client.search_stations(id=42)
        mocked.assert_called_once_with(
            "GET",
            "fake://vhfmgr/api/stations",
            params={"id": 42, "page": 0, "size": 100, "sort": "name:ASC"},
        )


def test_create_apid(
    vhf_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB create_apid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        response = vhf_client.create_apid(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        response = vhf_client.create_apid(name="AnswerPacket", apid=42)
        mocked.assert_called_once_with(
            "POST",
            "fake://vhfmgr/api/apids",
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            json={
                "name": "AnswerPacket",
                "apid": 42,
                "description": "A packet AnswerPacket",
                "className": "None",
                "instrument": "",
                "alias": "",
                "details": "",
                "category": "VHF",
                "expectedPackets": 1,
                "productName": "",
                "priority": -1,
            },
        )


def test_update_apid(
    vhf_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB update_apid"""
    with mock.patch.object(vhf_client, "get_apid_info") as get_mocked, mock.patch(
        HTTPIO_REQUEST, return_value=sync_200_response
    ) as put_mocked:
        # test invalid kwargs management
        response = vhf_client.update_apid(bad_key="bad")
        get_mocked.assert_not_called()
        put_mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        get_mocked.return_value = {
            "name": "AnswerPacket",
            "apid": 42,
            "description": "A packet AnswerPacket",
            "className": "None",
            "instrument": "HAL",
            "category": "VHF",
            "expectedPackets": 1,
            "priority": -1,
        }
        new_desc = (
            "Answer to the Ultimate Question of Life, the Universe, and Everything."
        )
        response = vhf_client.update_apid(
            apid=42, instrument="HAL", description=new_desc
        )
        get_mocked.assert_called_once_with(apid=42)
        put_mocked.assert_called_once_with(
            "PUT",
            "fake://vhfmgr/api/apids/42",
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            json={
                "name": "AnswerPacket",
                "apid": 42,
                "description": new_desc,
                "className": "None",
                "instrument": "HAL",
                "category": "VHF",
                "expectedPackets": 1,
                "priority": -1,
            },
        )


def test_create_station(
    vhf_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB create_station"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        response = vhf_client.create_station(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        response = vhf_client.create_station(name="NewStation", station_id=42)
        mocked.assert_called_once_with(
            "POST",
            "fake://vhfmgr/api/stations",
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            json={
                "name": "NewStation",
                "stationId": 42,
                "description": "A station NewStation",
                "country": "PAR",
                "location": "Paris",
                "id": "0x1",
                "altitude": 0.0,
                "latitude": 0.0,
                "longitude": 0.0,
                "minElevationAngle": 0.0,
                "macaddress": "0.0.0.42",
            },
        )


def test_update_station(
    vhf_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB create_station"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        response = vhf_client.create_station(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        response = vhf_client.create_station(
            name="NewStation", mode="update", station_id=42, country="FRA"
        )
        mocked.assert_called_once_with(
            "PUT",
            "fake://vhfmgr/api/stations" + ("/%d" % 42),
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            json={
                "name": "NewStation",
                "stationId": 42,
                "description": "A station NewStation",
                "country": "FRA",
                "location": "Paris",
                "id": "0x1",
                "altitude": 0.0,
                "latitude": 0.0,
                "longitude": 0.0,
                "minElevationAngle": 0.0,
                "macaddress": "0.0.0.42",
            },
        )


def test_update_scheduler(
    vhf_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB update_scheduler"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        with pytest.raises(TypeError):
            response = vhf_client.update_scheduler(bad_key="bad")
        mocked.assert_not_called()
        # test with valid kwargs
        vhf_client.update_scheduler(name="NewStation", status="ACTIVE")
        mocked.assert_called_once_with(
            "PUT",
            "fake://vhfmgr/api/schedulers/NewStation",
            headers={
                "Content-Type": "application/json",
                "Accept": "application/json",
            },
            params={"status": "ACTIVE"},
        )
