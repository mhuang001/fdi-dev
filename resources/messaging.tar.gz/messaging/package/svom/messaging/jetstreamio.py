"""
NATS client tool for Svom.

Inspired by:
https://github.com/nats-io/asyncio-nats/examples/coroutine_threadsafe.py

@authors: patrickmaeght, henrilouvin
"""
# Log
import logging

# System
import json
import threading
import asyncio
import signal
import time

# NATS
from nats.aio.client import Client as NATS
import nats.aio.errors


log = logging.getLogger("nats_client")


class JetStreamIo:
    """Asynchronous NATS client.

    Connect to the NATS client. Start a new asyncio event loop only if none
    is given and running.

    Parameters
    ----------
    host : str
        hostname or IP address of the remote broker
    port : str
        network port of the server host to connect to
    user : str, optional
        username for broker identification
    password : str, optional
        password for broker identification
    streaming_id : str, optional
        If provided at initialisation, a dedicated JetStream "Consumer" is created
        to make the subscription durable, so that a service with a given `streaming_id` i
        s ensured exactly once delivery of messages. In the event of a disconnection
        from svom.messaging.he server, the missed messages shall be automatically received
        upon reconnexion.
    loop : optional
        asyncio event loop
    max_reconnect_attempts : int, optional
        Maximum number of attemps to connect to the NATS client.
    """

    def __init__(self, host="localhost", port="4222", **kwargs):
        self.args = {
            "user": None,
            "password": None,
            "streaming_id": None,
            "loop": None,
            "max_reconnect_attempts": 5,
        }
        if set(kwargs.keys()).issubset(self.args.keys()):
            self.args.update(kwargs)
        else:
            log.error(
                "Error in NatsIo init: keyworded arguments should be a subset of %s. Got %s",
                set(self.args.keys()),
                set(kwargs.keys()),
            )
            raise AttributeError("Misuse of NatsIo init")
        # pylint: disable=unsupported-membership-test
        if self.args["streaming_id"] is not None:
            if (
                "." in self.args["streaming_id"]
                or "*" in self.args["streaming_id"]
                or ">" in self.args["streaming_id"]
            ):
                raise ValueError(
                    f"Invalid \"streaming_id\": {self.args['streaming_id']}"
                    ' (should not contain "*","." or ">")'
                )
            self.args["streaming_id"] = self.args["streaming_id"].lower()
        self.user_password = (self.args["user"], self.args["password"])
        self.pub_queue = []
        self.sub_queue = []
        # retrieve servers list
        self.servers = []
        hosts = host.split(",")
        for uri in hosts:
            if ":" not in uri:
                uri += f":{port}"
            if not uri.startswith("nats://"):
                uri = f"nats://{uri}"
            self.servers.append(uri)
        # declare underlying nats client
        self._nats = NATS()
        # retrieve event loop
        self.loop = self.args.get("loop")
        if self.loop is None:
            try:
                log.info("No loop argument provided, retrieving default asyncio loop")
                self.loop = asyncio.get_event_loop()
            except RuntimeError:
                log.info("Failed to retrieve asyncio event loop. Creating a new one...")
                self.loop = asyncio.new_event_loop()

        # loop management depends if loop is running or not
        self.thread = None
        self.is_connecting = True
        if not self.loop.is_running():
            # if loop is not already running, create separate thread
            # for connection and execute run_forever
            log.info("Async loop is not running, running it in new thread")
            self.thread = threading.Thread(target=self._run)
            # force server to shutdown gracefully on SIGINT. This could
            # be done for SIGHUP and/or SIGTERM but may not be clever
            if threading.current_thread() == threading.main_thread():
                signal.signal(signal.SIGINT, self.sigint_handler)
            # starting NATS client starts asyncio event loop
            self.thread.start()
        else:
            # if loop is already running, execute connection in current loop
            log.info("Async loop is already running, adding connect call as coroutine")
            asyncio.run_coroutine_threadsafe(self._connect(servers=self.servers), loop=self.loop)

    def _run(self):
        """Runs connections to NATS, then starts asynchronous loop"""
        # connect to server
        self.loop.run_until_complete(self._connect(servers=self.servers))
        # run async loop forever
        self.loop.run_forever()

    def is_connected(self):
        """Returns True if connected"""
        return self.get_server_status() == "connected"

    def _nats_status(self):
        """Checks and return base NATS server status"""
        # list of status numbers and meaning from svom.messaging.syncio-nats-client
        status_enum = {
            0: "disconnected",
            1: "connected",
            2: "closed",
            3: "reconnecting",
            4: "connecting",
            5: "draining_subs",
            6: "draining_pubs",
        }
        # return server status or "unknown" if not found
        return status_enum.get(self._nats._status, "unknown")  # pylint: disable=protected-access

    def get_server_status(self):
        """Checks and return NATS && STAN server status"""
        # retrieve NATS server status
        return self._nats_status()  # pylint: disable=protected-access

    async def _on_nats_error(self, exc):
        """NATS exception callback"""
        err_msg = str(exc)
        log.error("JetStreamIo callback caught a nats.aio error: %s", err_msg)
        if "Authorization Violation" in err_msg:
            # auth violation means there is no point in trying again
            self._nats.options["allow_reconnect"] = False
            log.error("Bad user/password")
        elif "ErrStaleConnection" in err_msg:
            # connection gone stale, attempt reconnecting
            log.error("Connection has gone stale")
        log.info("Retrying connection in 2s.")

    async def _on_nats_reconnect(self):
        """NATS reconnection callback"""
        log.info("Sucessfully reconnected to %s", self._nats.connected_url.netloc)

    async def _on_nats_disconnect(self):
        """NATS disconnection callback"""
        """NATS disconnection callback"""
        log.error("Connection to NATS server lost. %s", self.get_server_status())
        # "disconnect" means the connexion was up and running at some point
        # so we should never stop trying to reconnect
        self._nats.options["max_reconnect_attempts"] = -1

    async def _connect(self, servers):
        """Connect to NATS server

        Parameters
        ----------
        servers : str
            comscriptsation of the hostname or IP address of the remote broker and
            the network port of the server host to connect to.
        """
        # return directly if the client is connected or connecting
        if self._nats_status() in ["connected", "connecting"]:
            return
        # try connecting
        try:
            log.info(
                "Attempting connection to nats server list %s as %s",
                servers,
                self.user_password[0],
            )
            await self._nats.connect(
                servers=self.servers,
                user=self.user_password[0],
                password=self.user_password[1],
                loop=self.loop,
                error_cb=self._on_nats_error,
                disconnected_cb=self._on_nats_disconnect,
                reconnected_cb=self._on_nats_reconnect,
                allow_reconnect=True,
                max_reconnect_attempts=self.args["max_reconnect_attempts"],
            )
            self.is_connecting = False
            await self._nats.flush()
        except Exception as exc:
            log.error("Connection failed: %s", exc)
            if "Authorization Violation" in str(exc):
                self.loop.call_soon_threadsafe(self.stop)
                self.is_connecting = False
                return
            log.error("Maximum attempts reached. Giving up...")
            self.is_connecting = False
            self.loop.call_soon_threadsafe(self.stop)
            return
        else:
            log.info("Connected to %s.", self._nats._current_server.uri.geturl())

    def subscribe(self, subject, handler=None, **kwargs):
        """Launch subscription as async task

        Parameters
        ----------
        subject : str
            A string specifying the subject to subscribe to.
        handler : `async callback function`, optional
            Basic function printing message content to log when subsriscriptsg to a
            subject.
        """
        # subscribe to channel on streaming or standard server
        if handler is None:
            handler = self._default_handler
        # async subscribe to streaming server
        log.info("Subscriscriptsg to subject %s", subject)
        future = asyncio.run_coroutine_threadsafe(
            self._subscribe(subject, handler, **kwargs), loop=self.loop
        )
        self.sub_queue.append(future)

    async def _subscribe(self, subject, handler, **kwargs):
        """New subscription or handler change

        Parameters
        ----------
        subject : str
            A string specifying the subject to subscribe to (made of stream name
             + sub string, Ex: data.vhf)
        handler : `async callback function`
            Basic function printing message content to log when subsriscriptsg to a
            subject.
        """
        try:
            # check connection
            if self.get_server_status() != "connected":
                log.warning(
                    "Subscription to channel %s on hold: waiting for connection",
                    subject,
                )
            while self.get_server_status() != "connected":
                await asyncio.sleep(1)
            if self.args["streaming_id"] is None:
                # simple subscribe
                await self._nats.subscribe(subject, cb=handler)
            else:
                # automatically handle consumer durable_name and deliver_subject creation
                if "stream" not in kwargs:
                    kwargs["stream"] = subject.split(".")[0]
                if "filter_subject" not in kwargs:
                    kwargs["filter_subject"] = subject
                # create consumer and subscribe
                deliver_subject = await self._create_or_update_consumer(**kwargs)
                log.info("Consumer associated to deliver subject %s", deliver_subject)
                # if max_reconnect_attempt is -1 we are reconnecting so should not re-subscribe
                if self._nats.options["max_reconnect_attempts"] > 0:
                    await self._nats.subscribe(deliver_subject, cb=handler)
                    log.info("Handler %s subscribed to subject %s", handler.__name__, subject)
        except Exception as err:
            log.error("Subscription to subject %s failed: %s", subject, err)

    def create_or_update_stream(self, name=None, subjects=None, **kwargs):
        """Launch stream creation as async task.

        Parameters
        ----------
        subjects : str, optional
            A string specifying the subject to subscribe to.
        handler : `async callback function`, optional
            Basic function printing message content to log when subsriscriptsg to a
            subject.
        """
        future = asyncio.run_coroutine_threadsafe(
            self._create_or_update_stream(name=name, subjects=subjects, **kwargs),
            loop=self.loop,
        )
        return future.result()

    def create_or_update_consumer(
        self,
        stream=None,
        durable_name=None,
        deliver_subject=None,
        filter_subject="",
        **kwargs,
    ):
        """launch consumer creation as async task

        Parameters
        ----------
        stream : str
            stream name
        durable_name : str, optional
            If none, made of the subject name (given in the subscribe methode)
            and the streaming id given at the initialisation of the client
            JetStreamIo in self.arg["streaming_id"]. Replace the . by _ or -.
        deliver_subject : str, optional
            If none, made a new subject to subcribe to from svom.messaging.he filter subject
            or the stream name and the streaming id given at the initialisation
            of the client JetStreamIo : subject.self.arg["streaming_id"].
        filter_subject : str, optional
            subject given in the subscribe methode

        Returns
        -------
        future.result() : asyncio.Future
            Future for new consumer creation
        """
        future = asyncio.run_coroutine_threadsafe(
            self._create_or_update_consumer(
                stream=stream,
                durable_name=durable_name,
                deliver_subject=deliver_subject,
                filter_subject=filter_subject,
                **kwargs,
            ),
            loop=self.loop,
        )
        return future.result()

    async def _create_or_update_stream(self, name=None, subjects=None, **kwargs):
        """Creates or updates JetStream stream reading config from svom.messaging.wargs

        It makes use of special JS subjects:

            * $JS.API.STREAM.NAMES
            * $JS.API.STREAM.CREATE.<stream>
            * $JS.API.STREAM.UPDATE.<stream>

        Parameters
        ----------
        name : str, optional
            stream name
        subjects : str, optional
            list of subjects to be created or updated for the stream
        """
        # check arguments validity
        if name is None:
            raise ValueError(
                "name is a mandatory argument of JetStreamIo.create_or_update_stream()"
            )
        if subjects is None:
            subjects = ["*"]
        if "." in name or "*" in name or ">" in name:
            raise ValueError(
                f"Invalid stream name {name} in"
                " JetStreamIo.create_or_update_stream()."
                " (should not contain *,. or >)"
            )

        # define default config
        stream_config = {
            "name": name,
            "subjects": subjects,
            "retention": "limits",
            "max_consumers": -1,
            "max_msgs": -1,
            "max_bytes": -1,
            "max_age": 31536000000000000,
            "max_msg_size": -1,
            "storage": "file",
            "discard": "old",
            "num_replicas": 1,
            "duplicate_window": 120000000000,
        }

        # update config according to kwargs
        for key, val in kwargs.items():
            # check validity
            if key not in stream_config:
                raise ValueError(f"{key} is not a valid stream create parameter")
            stream_config[key] = val

        # retrieve stream list
        resp = await self._request("$JS.API.STREAM.NAMES", "")
        resp_data = json.loads(resp.data)
        streams = resp_data.get("streams")

        # create or update stream depending of its existence
        if streams is not None and name in streams:
            # update config of existing stream
            log.info("Stream %s already exists on server, requesting config update...", name)
            resp = await self._request(f"$JS.API.STREAM.UPDATE.{name}", json.dumps(stream_config))
        else:
            # create new stream
            log.info("Requesting new stream %s creation...", name)
            resp = await self._request(f"$JS.API.STREAM.CREATE.{name}", json.dumps(stream_config))
        return resp

    async def _create_or_update_consumer(
        self,
        stream=None,
        durable_name=None,
        deliver_subject=None,
        filter_subject="",
        **kwargs,
    ):
        """Creates or updates JetStream consumer reading config from svom.messaging.wargs.

        It makes use of special JS subjects:

            * $JS.API.CONSUMER.NAMES.<stream>
            * $JS.API.CONSUMER.DURABLE.CREATE.<stream>.<consumer>
            * $JS.API.CONSUMER.DELETE.<stream>.<consumer>

        Parameters
        ----------
        stream : str
            stream name
        durable_name : str, optional
            If none, made of the subject name (given in the subscribe methode)
            and the streaming id given at the initialisation of the client
            JetStreamIo in self.arg["streaming_id"]. Replace the . by _ or -.
        deliver_subject : str, optional
            If none, made a new subject to subcribe to from svom.messaging.he filter subject
            or the stream name and the streaming id given at the initialisation
            of the client JetStreamIo : subject.self.arg["streaming_id"].
        filter_subject : str, optional
            subject given in the subscribe methode.

        Returns
        -------
        deliver_subject : str
            If none is given, make a deliver subject from svom.messaging.he filter subject
            or the stream name and the streaming id.
        """
        # check arguments validity
        if stream is None:
            log.error(
                "'stream' is a mandatory parameter of JetStreamIo.create_or_update_consumer()"
            )

        # define default config
        streaming_id = self.args["streaming_id"]
        prefix = stream
        # if subject is specified show it in ID prefix
        if filter_subject != "":
            prefix = filter_subject
            prefix = prefix.replace("*", "star")
            prefix = prefix.replace(">", "gt")
        # if durable_name is not defined use default
        if durable_name is None:
            durable_name = f"{prefix.replace('.', '-')}_{streaming_id}"
        # if deliver_subject is not defined use default
        if deliver_subject is None:
            deliver_subject = f"{prefix}.{streaming_id}"
        consumer_config = {
            "durable_name": durable_name,
            "deliver_subject": deliver_subject,
            "deliver_policy": "last",
            "ack_policy": "none",
            "max_deliver": -1,
            "filter_subject": filter_subject,
            "replay_policy": "instant",
        }

        # update config according to kwargs
        for key, val in kwargs.items():
            # check validity
            if key not in consumer_config:
                raise ValueError(f"{key} is not a valid consumer create parameter")
            consumer_config[key] = val

        # create consumer
        log.info("Checking consumer existence for stream %s: %s", stream, consumer_config)
        resp = await self._request(f"$JS.API.CONSUMER.INFO.{stream}.{durable_name}", "")
        current_config = json.loads(resp.data).get("config")
        if current_config is None:
            log.info(
                "No consumer found. Requesting consumer creation for stream %s: %s",
                stream,
                consumer_config,
            )
            resp = await self._request(
                f"$JS.API.CONSUMER.DURABLE.CREATE.{stream}.{durable_name}",
                json.dumps({"stream_name": stream, "config": consumer_config}),
            )
            # subscribe right away if consumer is created successfully
            if "created" not in json.loads(resp.data):
                log.error("%s", json.loads(resp.data))
                raise RuntimeError("Consumer creation failed, aborting subscription.")
        else:
            log.info("Consumer already exists on server, extracting deliver_subject")
            deliver_subject = current_config["deliver_subject"]
        # return deliver_subject value for subscription
        return deliver_subject

    def publish(self, subject, data):
        """Launch publish as async task

        Parameters
        ----------
        subject : str
            subject to publish to
        data : str
            message to publish
        """
        # publish to channel on streaming or standard server
        if isinstance(data, str):
            data = data.encode()
        # async publish to streaming server
        if self.args["streaming_id"] is not None:
            # async request to JetStream server
            future = asyncio.run_coroutine_threadsafe(self._request(subject, data), loop=self.loop)
        else:
            # async publish to standard server
            future = asyncio.run_coroutine_threadsafe(self._publish(subject, data), loop=self.loop)
        self.pub_queue.append(future)

    def request(self, subject, data):
        """Launch request as sync task

        Parameters
        ----------
        subject : str
            subject to publish to
        data : str
            message to publish

        Returns
        -------
        future.result() : asyncio.Future
            Future for the message publication
        """
        if isinstance(data, str):
            data = data.encode()
        # async request to JetStream server
        future = asyncio.run_coroutine_threadsafe(self._request(subject, data), loop=self.loop)
        return future.result()

    async def _publish(self, subject, data):
        """Publish {data} to channel {subject}

        Parameters
        ----------
        subject : str
            subject to publish to
        data : str
            message to publish
        """
        try:
            # Check connection
            if self.get_server_status() != "connected":
                log.warning("Publication to channel %s on hold: waiting for connection", subject)
            while self.get_server_status() != "connected":
                await asyncio.sleep(1)
            # Actual publish
            log.info("Sending message to channel '%s'", subject)
            await self._nats.publish(subject, data)
        except Exception as err:
            log.exception(str(err))

    async def _request(self, subject, data):
        """Publish {data} to JetStream channel {subject}

        Parameters
        ----------
        subject : str
            subject to publish to
        data : str
            message to publish

        Returns
        -------
        resp : asyncio.Future
            Future for the nats message publication
        """
        resp = None
        try:
            # publish to channel on streaming or standard server
            if isinstance(data, str):
                data = data.encode()
            # Check connection
            if self.get_server_status() != "connected":
                log.warning(
                    "Publication to channel '%s' on hold: waiting for connection",
                    subject,
                )
            while self.get_server_status() != "connected":
                await asyncio.sleep(1)
            # Actual publish
            log.info("Sending message to JetStream channel '%s'", subject)
            resp = await self._nats.request(subject, data)
            log.info("Server response: %s", resp.data)
        except nats.aio.errors.ErrConnectionClosed:
            log.error("NATS server seems disconnected.")
            await self._connect(servers=self.servers)
        except nats.aio.errors.ErrTimeout:
            log.error(
                "Request to '%s' timed out. Subject may not be associated to a JetStream stream",
                subject,
            )
            raise
        except Exception as err:
            log.exception(str(err))
            log.error("Publication request to '%s' failed", subject)
        return resp

    async def _default_handler(self, msg):
        """Application handler data : str"""
        log.info("--- Received: %s on %s", msg.subject, msg.data.decode())

    def stop(self):
        """Nats client cleanup and close"""
        log.info("Starting NATS closing procedure")
        # sleep a3 bit to give time to everything async to settle down
        time.sleep(0.5)
        # delay stop call if connect in progress
        while self.is_connecting:
            time.sleep(1)
        # remove disconnection callbacks
        self._nats.options["allow_reconnect"] = False
        self._nats._disconnected_cb = None
        # wait for publish tasks to finish
        if self.get_server_status() == "connected":
            log.debug("Waiting for pending message publication")
            for future in self.pub_queue:
                if not future.done():
                    future.result()
            # Close only if Client were connected
            log.info("Closing NATS client")
            future_close = asyncio.run_coroutine_threadsafe(self._nats.close(), loop=self.loop)
            future_close.result()
        else:
            log.debug("Cancelling pending message publication")
            for future in self.pub_queue:
                if not future.done():
                    future.cancel()
        # stop NATS properly
        try:
            if self.thread is not None:
                # thread and loop were started at the client initiatization
                # loop has to be stopped here
                log.info("Stopping async event loop")
                self.loop.call_soon_threadsafe(self.loop.stop)
        except Exception as err:
            log.exception(err)

    # pylint: disable=unused-argument
    def sigint_handler(self, signum, frame):
        """Stops gracefully, restore default signal handling and raises KeyboardInterrupt"""
        self.is_connecting = False
        self.stop()
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        raise KeyboardInterrupt
