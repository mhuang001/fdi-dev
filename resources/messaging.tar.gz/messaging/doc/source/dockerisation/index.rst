.. _dockerisation:

Dockerization
*************


Docker image with pre-installed messaging module
================================================

A docker image with pre-installed messaging module `svom.messaging` can be build with

::

    docker build --rm --tag=registry.svom.fr:5543/python-messaging:latest .

with the following size:

::

    registry.svom.fr:5543/python-messaging:latest      150MB

It is built from the `python:3.8-slim docker images <https://hub.docker.com/_/python>`_ containing the regular python 3.8 installation.

One such image is available on the `Svom registry <https://drf-gitlab.cea.fr/svom/Tools/wikis/Svom-Docker-Registry>`_.
The purpose of this image is to be used as a base to build other docker images. The associated *Dockerfile* should
simply contain the line

::

    FROM registry.svom.fr:5543/python-messaging:latest

and be build *after* login to the registry:

::

    docker login svomtest.svom.fr:$REG_PORT


Docker size analysis
====================

From this project we also provide an image with pre-installed `python science packages <https://drf-gitlab.cea.fr/svom/messaging/-/blob/master/requirements-science.txt>`_.

::

    registry.svom.fr:5543/python-science:latest

With the pre-installed python packages, the image is:

::

    registry.svom.fr:5543/python-science:latest        826MB
