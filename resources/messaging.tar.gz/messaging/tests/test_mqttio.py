"""
MqttIo test file
"""
import logging
import os
import sys
import time
from unittest.mock import MagicMock
from unittest import mock
import pytest

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
from package.svom.messaging.mqttio import MqttIo

log = logging.getLogger("test_mqttio")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)


@pytest.fixture(
    scope="module",
    params=[
        {"host": "48.15.16.23", "port": "42"},
        {"host": "48.15.16.23", "port": 42},
        {"host": "http://48.15.16.23", "port": 42},
    ],
)
# The fixture function gets access to each parameter through the special request object:
def host_port_(request):
    """return host (and port) as dict"""
    return request.param


fail_nb = 0
max_fail = 1


def status_side_effect():
    """returns 'disconnected' {max_fail} times then 'connected'"""
    global fail_nb
    global max_fail
    if fail_nb < max_fail:
        fail_nb += 1
        return False
    return True


def test_bad_arg_init():
    with pytest.raises(AttributeError) as exception:
        MqttIo(tutu="lolo")


def test_mqtt_connect(host_port_, caplog):  # pylint: disable=redefined-outer-name
    """test connect on init with various ways of passing host and port"""
    global fail_nb
    global max_fail
    fail_nb = 0
    max_fail = 1
    mqtt_connect_patch = "asyncio_mqtt.client.Client.connect"
    mqtt_disconnect_patch = "asyncio_mqtt.client.Client.disconnect"
    mqtt_is_connected_patch = "paho.mqtt.client.Client.is_connected"
    with mock.patch(
        mqtt_connect_patch, side_effect=Exception("TEST")
    ) as mock_mqtt_connect, mock.patch(
        mqtt_disconnect_patch, return_value=None
    ) as mock_mqtt_disconnect, mock.patch(
        mqtt_is_connected_patch, side_effect=status_side_effect
    ) as mock_is_connected:
        caplog.set_level(logging.INFO)
        client = MqttIo(**host_port_)
        assert client.thread is not None
        assert client.thread.is_alive()
        time.sleep(0.5)
        # stop client right away to force all futures to finish
        client.is_connecting = False
        client.stop()
        # check thread was stopped and thread died
        time.sleep(0.5)
        assert not client.loop.is_running()
        assert not client.thread.is_alive()

        mock_mqtt_connect.assert_called_once()
        mock_mqtt_disconnect.assert_called_once()

        assert client._mqtt._hostname == "48.15.16.23"
        assert client._mqtt._port == 42
        assert client._mqtt._client._username is None
        assert client._mqtt._client._password is None
        assert client._mqtt._client._on_message == client.default_on_message
        assert client._mqtt._client._clean_session is True
        assert client._mqtt._client._client_id == b""

        assert "Retrying connection in 1s." in caplog.text


@pytest.mark.asyncio
# Inside this test, we need to wait the _connect coroutine since we mock run_coroutine_threadsafe since
# we are using an already running event loop. Since we wait some methods, we hace to declare the test
# async
async def test_loop_init(event_loop):  # pylint: disable=redefined-outer-name
    """test init with loop argument"""
    global fail_nb
    global max_fail
    fail_nb = 0
    max_fail = 1
    mqtt_connect_patch = "asyncio_mqtt.client.Client.connect"
    mqtt_is_connected_patch = "paho.mqtt.client.Client.is_connected"
    # MqttIo will be initialized using already running {event_loop}
    # the connection should be done through a run_coroutine_threadsafe call
    coro_patch = "asyncio.run_coroutine_threadsafe"
    with mock.patch(coro_patch) as coro_mock, mock.patch(
        mqtt_connect_patch, return_value=None
    ) as mock_mqtt_connect, mock.patch(
        mqtt_is_connected_patch, side_effect=status_side_effect
    ) as mock_is_connected:
        coro_mock.assert_not_called()
        mock_mqtt_connect.assert_not_called()
        # init client with already running loop
        client = MqttIo(host="48.15.16.23", port=42, loop=event_loop)
        # check run_coroutine_threadsafe was called
        coro_mock.assert_called_once()
        # Check the mock of run coroutine threadsafe was called with _connect
        assert "MqttIo._connect" in repr(coro_mock.mock_calls[0][1][0])
        # actually await _connect coroutine (since run_coroutine_threadsafe
        # was mocked). if we don't await connect, the following warning is
        # raised  "MqttIo._connect' was never awaited"
        await coro_mock.mock_calls[0][1][0]
        # check client has no thread if a running loop was given in the initialisation
        assert client.thread is None


def test_on_message(caplog):
    """test default on message call back for MqttIo"""

    def test_on_message(self, client, userdata, message):
        log.info(message.payload.decode("utf-8"))

    conn_patch = "package.svom.messaging.mqttio.MqttIo._connect"
    global fail_nb
    global max_fail
    fail_nb = 0
    max_fail = 0
    with mock.patch(conn_patch, return_value=None) as conn_mock:
        # Test default on message
        client = MqttIo(host="48.15.16.23", port=42)
        # Mimic the Message class of paho mqtt client called in the default
        # on_message
        message = MagicMock()
        message.topic = "test"
        message.payload = b"Hello you"
        caplog.set_level(logging.INFO)
        client.default_on_message(client="", userdata="", message=message)
        client.is_connecting = False
        client.stop()
        assert "Message received on channel 'test': Hello you" in caplog.text

        # test giving an outside call back
        client = MqttIo(host="48.15.16.23", port=42, on_message=test_on_message)
        assert client._mqtt._client._on_message == test_on_message
        client.is_connecting = False
        client.stop()


def test_on_connect(caplog):
    """test on connect call back for MqttIo when  the return code is 0 or
    different from package.svom.messaging."""

    conn_patch = "package.svom.messaging.mqttio.MqttIo._connect"
    global fail_nb
    global max_fail
    fail_nb = 0
    max_fail = 0

    # If rc return code = 0
    with mock.patch(conn_patch, return_value=None) as conn_mock:
        # Test default on message
        client = MqttIo(host="48.15.16.23", port=42)
        caplog.set_level(logging.INFO)
        client.on_connect(client, userdata="", flags="", rc=0, properties=None)
        client.is_connecting = False
        client.stop()
        assert "Connected to MQTT broker" in caplog.text

    # If rc return code != 0
    with mock.patch(conn_patch, return_value=None) as conn_mock:
        # Test default on message
        client = MqttIo(host="48.15.16.23", port=42)
        caplog.set_level(logging.INFO)
        client.on_connect(client, userdata="", flags="", rc=1, properties=None)
        client.is_connecting = False
        client.stop()
        assert "Connected failed with return code= 1" in caplog.text


def test_on_connect_already_connected(caplog):
    """test on connect call back for MqttIo when client already connected"""

    conn_patch = "package.svom.messaging.mqttio.MqttIo._connect"
    global fail_nb
    global max_fail
    fail_nb = 0
    max_fail = 0
    # If already connected
    patch_mqtt_client = "asyncio_mqtt.client.Client"
    with mock.patch(conn_patch, return_value=None) as conn_mock:
        client = MqttIo(host="48.15.16.23", port=42)
        caplog.set_level(logging.INFO)
        # to have the future self._mqtt._connected.done() to True in the method
        # on connect
        client._mqtt._connected.set_result(None)
        client.on_connect(client="", userdata="", flags="", rc=1, properties=None)
        client.is_connecting = False
        client.stop()
        assert "Already connected" in caplog.text


def test_on_disconnect_closing_client(caplog):
    """test on disconnect call back for MqttIo when the client is closing when
    the return code is 0 or different from package.svom.messaging."""

    conn_patch = "package.svom.messaging.mqttio.MqttIo._connect"
    global fail_nb
    global max_fail
    fail_nb = 0
    max_fail = 1
    # If rc return code = 0, is_closing =True, don't call _reconnect async method
    with mock.patch(conn_patch, return_value=None) as conn_mock:
        # Test default on message
        client = MqttIo(host="48.15.16.23", port=42)
        client.is_closing = True
        # to have the future self._mqtt._connected.done() to True in the method
        # on connect
        client._mqtt._connected.set_result(None)
        caplog.set_level(logging.INFO)
        client.on_disconnect(client="", userdata="", rc=0, properties=None)
        client.is_connecting = False
        client.stop()
        assert "Client disconnects" in caplog.text

    # If rc return code != 0, is_closing =True, don't call _reconnect async method
    with mock.patch(conn_patch, return_value=None) as conn_mock:
        # Test default on message
        client = MqttIo(host="48.15.16.23", port=42)
        client.is_closing = True
        # to have the future self._mqtt._connected.done() to True in the method
        # on connect
        client._mqtt._connected.set_result(None)
        caplog.set_level(logging.INFO)
        client.on_disconnect(client="", userdata="", rc=1, properties=None)
        client.is_connecting = False
        client.stop()
        assert "Unexpected disconnect with return code= 1" in caplog.text


def test_on_disconnect_calling_reconnect(caplog):
    """test on connect call back for MqttIo when client tries to reconnect"""

    conn_patch = "package.svom.messaging.mqttio.MqttIo._connect"
    global fail_nb
    global max_fail
    fail_nb = 0
    max_fail = 1
    mqtt_connect_patch = "asyncio_mqtt.client.Client.connect"
    mqtt_disconnect_patch = "asyncio_mqtt.client.Client.disconnect"
    mqtt_is_connected_patch = "paho.mqtt.client.Client.is_connected"
    with mock.patch(
        mqtt_connect_patch, side_effect=Exception("TEST")
    ) as mock_mqtt_connect, mock.patch(
        mqtt_disconnect_patch, return_value=None
    ) as mock_mqtt_disconnect, mock.patch(
        mqtt_is_connected_patch, side_effect=status_side_effect
    ) as mock_is_connected:
        caplog.set_level(logging.INFO)
        client = MqttIo(host="48.15.16.23", port=42)
        client.is_closing = False
        # to have the future self._mqtt._connected.done() to True in the method
        # on connect
        client._mqtt._connected.set_result(None)
        # Needed to mimic the effect of the asynchrone and the fact that we mock
        # all the connect and is_connected... Otherwise the async _connect method
        # with the side effect Exception is not finish before we enter the reconnect
        # and it creates a mess on the call count for the mock assert.
        time.sleep(2)
        # Here we reset the mock for the assert below when where we want to assert
        # only on the mock counts in the _reconnect method and not in the
        # constructor of the client where the mock are also called
        mock_is_connected.reset_mock()
        mock_mqtt_connect.reset_mock()
        fail_nb = 0
        max_fail = 1
        client.on_disconnect(client="", userdata="", rc=0, properties=None)

        time.sleep(1)
        client.is_connecting = False
        client.stop()

        time.sleep(1)
        # Two time in reconnect and 1 time on stop
        assert mock_is_connected.call_count == 3
        mock_mqtt_connect.assert_called_once()
        assert "Retrying connection in 1s." in caplog.text


def test_on_disconnect_return_early(caplog):
    """test on connect call back for MqttIo"""

    conn_patch = "package.svom.messaging.mqttio.MqttIo._connect"
    global fail_nb
    global max_fail
    fail_nb = 0
    max_fail = 0
    # Already disconnected
    with mock.patch(conn_patch, return_value=None) as conn_mock:
        # Test default on message
        client = MqttIo(host="48.15.16.23", port=42)
        client.is_closing = True
        # to have the future self._mqtt._disconnected.done() to True in the method
        # on disconnect
        client._mqtt._disconnected.set_result(None)
        caplog.set_level(logging.INFO)
        client.on_disconnect(client="", userdata="", rc="", properties=None)
        client.is_connecting = False
        client.stop()
        assert "disconnect is already acknowledged" in caplog.text

    # not connected yet
    with mock.patch(conn_patch, return_value=None) as conn_mock:
        # Test default on message
        client = MqttIo(host="48.15.16.23", port=42)
        client.is_closing = True
        caplog.set_level(logging.INFO)
        client.on_disconnect(client="", userdata="", rc="", properties=None)
        client.is_connecting = False
        client.stop()
        assert "disconnect due to not connected yet" in caplog.text


def test_pubsub(caplog):
    """test MqttIo publishing/subscription"""
    conn_patch = "package.svom.messaging.mqttio.MqttIo._connect"
    mqtt_disconnect_patch = "asyncio_mqtt.client.Client.disconnect"
    mqtt_is_connected_patch = "paho.mqtt.client.Client.is_connected"
    global fail_nb
    global max_fail
    fail_nb = 0
    max_fail = 0
    sub_patch = "asyncio_mqtt.client.Client.subscribe"
    pub_patch = "paho.mqtt.client.Client.publish"
    dummy_info = MagicMock()
    dummy_info.rc = 0
    with mock.patch(conn_patch, return_value=None) as conn_mock, mock.patch(
        mqtt_is_connected_patch, side_effect=status_side_effect
    ) as mock_is_connected, mock.patch(
        mqtt_disconnect_patch, return_value=None
    ) as mock_mqtt_disconnect, mock.patch(
        sub_patch, return_value=None
    ) as sub_mock, mock.patch(
        pub_patch, return_value=dummy_info
    ) as pub_mock:
        # init client
        client = MqttIo(host="48.15.16.23", port=42)
        # fake MQTT connection
        conn_mock.assert_called_once_with(servers=["48.15.16.23:42"])
        try:
            caplog.set_level(logging.INFO)
            client.subscribe("sub_test")
            client.publish("pub_test", "Hello you")
        finally:
            client.is_connecting = False
            client.stop()
        time.sleep(0.5)
        sub_mock.assert_called_once_with("sub_test", qos=1)
        mock_mqtt_disconnect.assert_called_once()

        pub_mock.assert_called_once_with(topic="pub_test", payload="Hello you", qos=1)
        assert "Subscription to topic 'sub_test' sucessed." in caplog.text
        assert "Sending message 'Hello you' to channel 'pub_test'" in caplog.text
