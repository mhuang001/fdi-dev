"""
SdbIo test file
"""
import logging
import os
import sys
from requests import Response
from unittest import mock
import pytest

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
from package.svom.messaging.sdbio import SdbIo

log = logging.getLogger("test_sdbio")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)

# test products for import
TEST_PRODS = [
    "QPO_ECL_sb22011754_1",
    "PO_ECL_sb21013044_1",
    "MXT-EVT-CNV_1996488992_1",
    "MXT-EVT-CAL_1996488992_1",
    "OBPHOTMM_MXT_n.a_1",
]

HTTPIO_REQUEST = "package.svom.messaging.httpio.requests.Session.request"


@pytest.fixture(scope="module")
def sdb_client():
    """return sync SdbIo"""
    # with mock.patch('svom.messaging.tokens.KcTokens._request_tokens'):
    sync_client = SdbIo(max_tries=3, use_tokens=False)
    return sync_client


@pytest.fixture(params=[200, 201])
def sync_2xx_response(request):
    """mimics 'requests' success response"""
    fake_response = Response()
    fake_response.status_code = request.param
    fake_response.json = lambda: {"breakfast": "eggs"}
    return fake_response


def test_init():
    """Check that the use_tokens param is correctly passed to super()"""

    os.environ["KC_TYPE"] = "pipelines"
    client = SdbIo()
    assert client.kc_tokens is not None
    assert client.kc_tokens.tokens_with_expirations_dates is None


def test_init_urls():
    """test url usage priorities"""
    # with mock.patch('svom.messaging.tokens.KcTokens._request_tokens'):
    # order should be env > arguments > default
    test_client = SdbIo(
        import_url="http://import/from:arg",
        export_url="http://export/from:arg",
        use_tokens=False,
    )
    assert test_client.import_endpoint == "http://import/from:arg/v0/add_product"
    assert (
        test_client.search_endpoint == "http://export/from:arg/server/search/products"
    )
    # order should be env > arguments > default
    os.environ["SDB_IMPORT_URL"] = "http://import/from:env"
    os.environ["SDB_EXPORT_URL"] = "http://export/from:env"
    test_client = SdbIo(
        import_url="http://import/from:arg",
        export_url="http://export/from:arg",
        use_tokens=False,
    )
    assert test_client.import_endpoint == "http://import/from:env/v0/add_product"
    assert (
        test_client.search_endpoint == "http://export/from:env/server/search/products"
    )
    # order should be env > arguments > default
    os.environ.pop("SDB_IMPORT_URL")
    os.environ.pop("SDB_EXPORT_URL")
    test_client = SdbIo(max_tries=3, use_tokens=False)
    assert (
        test_client.import_endpoint == "https://fsc.svom.org/sdb-import/v0/add_product"
    )
    assert (
        test_client.search_endpoint == "https://fsc.svom.org/sdb/server/search/products"
    )


def test_gt_lt_search(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        sdb_client.search(
            card="QPO_ECL",
            date=">2021",
            obs_id="<=100",
            burst_id=None,
            outputs=["sp_acronym", "added_at", "product_id"],
        )

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "3;6;1", "c": "3::eq::QPO_ECL;6::gt::2021;2::lte::100;12::nl"},
        )


def test_bw_search(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        sdb_client.search(
            card="QPO_ECL",
            date=[">=2021", "<2022"],
            obs_id=["<=100", ">1"],
            outputs=["sp_acronym", "added_at"],
        )

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "3;6", "c": "3::eq::QPO_ECL;6::bw::2021|2022;2::bw::1|100"},
        )


def test_neq_search(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        sdb_client.search(
            card="!QPO_ECL",
            date="!~2021",
            obs_id="!=100",
            burst_id="!=None",
            outputs=["sp_acronym", "added_at", "product_id"],
        )

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={
                "a": "3;6;1",
                "c": "3::neq::QPO_ECL;6::nlk::2021;2::neq::100;12::nnl",
            },
        )


def test_range_search(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        sdb_client.search(
            card="QPO_ECL",
            date=">2021",
            obs_id=[1, 2, 3],
            outputs=["sp_acronym", "added_at", "product_id"],
        )

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "3;6;1", "c": "3::eq::QPO_ECL;6::gt::2021;2::in::1|2|3"},
        )


def test_criteria_search(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        sdb_client.search(
            card="QPO_ECL",
            criteria="PrimaryHDU,ID|eq|45",
            outputs=["sp_acronym", "added_at", "product_id"],
        )

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "3;6;1", "c": "3::eq::QPO_ECL;5::js::PrimaryHDU,ID|eq|45"},
        )

    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        sdb_client.search(
            card="QPO_ECL",
            criteria="ID=None",
            outputs=["sp_acronym", "added_at", "product_id"],
        )

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "3;6;1", "c": "3::eq::QPO_ECL;5::js::PrimaryHDU,ID|nl|"},
        )

    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        # resp = sdb_client.search(criteria=['PrimaryHDU,TSTART|lt|42','PrimaryHDU,TSTOP|gt|666'],
        sdb_client.search(
            criteria=["PrimaryHDU,TSTART<42", "PrimaryHDU,TSTOP>666"],
            outputs=["sp_acronym", "added_at", "product_id"],
        )

        # requests.get should have been called with two js search
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={
                "a": "3;6;1",
                "c": "5::js::PrimaryHDU,TSTART|lt|42;5::js::PrimaryHDU,TSTOP|gt|666",
            },
        )

    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        sdb_client.search(
            card="QPO_ECL",
            criteria="PrimaryHDU,ID!=45",
            outputs=["sp_acronym", "added_at", "product_id"],
        )

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "3;6;1", "c": "3::eq::QPO_ECL;5::js::PrimaryHDU,ID|neq|45"},
        )

    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        sdb_client.search(
            card="QPO_ECL",
            criteria="ID|neq|45",
            outputs=["sp_acronym", "added_at", "product_id"],
        )

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "3;6;1", "c": "3::eq::QPO_ECL;5::js::PrimaryHDU,ID|neq|45"},
        )

    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        sdb_client.search(
            card="QPO_ECL",
            criteria="ID<=45",
            outputs=["sp_acronym", "added_at", "product_id"],
        )

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "3;6;1", "c": "3::eq::QPO_ECL;5::js::PrimaryHDU,ID|lte|45"},
        )


def test_url_search(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """Test url search"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        mocked.return_value.json = lambda: [
            {"acronym": "OLDEST", "added_at": "2019", "url": "fake://data/old"},
            {"acronym": "YOUNGEST", "added_at": "2021", "url": "fake://data/young"},
            {"acronym": "MIDDLE", "added_at": "2020", "url": "fake://data/mid"},
        ]
        resp = sdb_client.get_fits_urls()

        # requests.get should have been with outputs 4(added_at) and 6(url)
        mocked.assert_called_once_with(
            "GET", "https://fsc.svom.org/sdb/server/search/products", params={"a": "4"}
        )
        assert resp == ["fake://data/old", "fake://data/young", "fake://data/mid"]


def test_raw_search(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        resp = sdb_client.raw_search(obs_id="<=100", outputs=["product_id", "url"])

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/l1",
            params={"a": "1;4", "c": "2::lte::100"},
        )

    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        mocked.return_value.json = lambda: [
            {"ext_name": "OLDEST", "added_at": "2019", "url": "fake://data/old"},
            {"ext_name": "YOUNGEST", "added_at": "2021", "url": "fake://data/young"},
            {"ext_name": "MIDDLE", "added_at": "2020", "url": "fake://data/mid"},
        ]
        resp = sdb_client.get_raw_fits_urls()

        # requests.get should have been with outputs 4(added_at) and 6(url)
        mocked.assert_called_once_with(
            "GET", "https://fsc.svom.org/sdb/server/search/l1", params={"a": "4"}
        )
        assert resp == ["fake://data/old", "fake://data/young", "fake://data/mid"]


@pytest.mark.skip(reason="Avoid connection to SDB and token management in CI")
def test_obsid_search(sdb_client):  # pylint: disable=redefined-outer-name
    """test SDB search by obsid"""
    resp = sdb_client.search(obs_id=1)
    assert resp.status_code == 200
    product_list = resp.json()
    assert len(product_list) > 1
    for entry in product_list:
        assert entry["obs_id"] == 1
    resp = sdb_client.raw_search(obs_id=1)
    product_list = resp.json()
    assert len(product_list) > 0
    for entry in product_list:
        assert entry["obs_id"] == 1


@pytest.mark.skip(reason="Avoid connection to SDB and token management in CI")
def test_date_search(sdb_client):  # pylint: disable=redefined-outer-name
    """test SDB search by date"""
    # retrieve a specific product
    resp = sdb_client.search(
        product_id=42, outputs=["sp_acronym", "added_at", "product_id"]
    )
    some_prod = resp.json()
    assert len(some_prod) == 1
    # get previous products for same card
    resp = sdb_client.search(
        card=some_prod[0]["sp_acronym"],
        date=f"<{some_prod[0]['added_at']}",
        outputs=["sp_acronym", "added_at", "product_id"],
    )
    prev_prods = resp.json()
    assert prev_prods != []
    # get all next products for same card
    resp = sdb_client.search(
        card=some_prod[0]["sp_acronym"],
        date=f">{some_prod[0]['added_at']}",
        outputs=["sp_acronym", "added_at", "product_id"],
    )
    next_prods = resp.json()
    assert next_prods != []
    # get all products for same card
    resp = sdb_client.search(
        card=some_prod[0]["sp_acronym"],
        outputs=["sp_acronym", "added_at", "product_id"],
    )
    all_prods = resp.json()

    # check that first product + previous + next = all
    assert len(prev_prods) + len(next_prods) + 1 == len(all_prods)
    prev_ids = [prod["product_id"] for prod in prev_prods]
    next_ids = [prod["product_id"] for prod in next_prods]
    all_ids = [prod["product_id"] for prod in all_prods]
    assert set(prev_ids + [42] + next_ids) == set(all_ids)

    # test less than or equal and greater than or equal comparisons
    resp = sdb_client.search(
        card=some_prod[0]["sp_acronym"],
        date=f"<={some_prod[0]['added_at']}",
        outputs=["sp_acronym", "added_at", "product_id"],
    )
    prev_or_eq_prods = resp.json()
    assert len(prev_or_eq_prods) == len(prev_prods) + 1
    prev_or_eq_ids = [prod["product_id"] for prod in prev_or_eq_prods]
    assert set(prev_or_eq_ids) == set(prev_ids + [42])
    resp = sdb_client.search(
        card=some_prod[0]["sp_acronym"],
        date=f">={some_prod[0]['added_at']}",
        outputs=["sp_acronym", "added_at", "product_id"],
    )
    next_or_eq_prods = resp.json()
    assert len(next_or_eq_prods) == len(next_prods) + 1
    next_or_eq_ids = [prod["product_id"] for prod in next_or_eq_prods]
    assert set(next_or_eq_ids) == set(next_ids + [42])


@pytest.mark.skip(reason="Avoid connection to SDB and token management in CI")
def test_prodid_search(sdb_client):  # pylint: disable=redefined-outer-name
    """test unicity of SDB search by product_id"""
    resp = sdb_client.search(product_id=12, outputs="url")
    product_list = resp.json()
    assert len(product_list) == 1
    assert len(product_list[0]) == 1
    assert sdb_client.get_fits_urls(product_id=12)[0] == product_list[0]["url"]


def test_metadata_search(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test metadata search endpoint"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        sdb_client.metadata_search(acronym="TT_GRM")

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/sp_cards",
            params={"a": "1;2;3;4;5;6;7;8;9;10;11;12;13", "c": "1::eq::TT_GRM"},
        )

    # if sdb_client.ssl != {}:
    #     meta_resp = sdb_client.metadata_search(acronym="TT_GRM")
    #     assert meta_resp.status_code == 200
    #     meta_resp = meta_resp.json()
    #     assert len(meta_resp) == 1
    #     meta_resp = meta_resp[0]
    #     assert set(meta_resp.keys()) == {
    #         "acronym",
    #         "sp_id",
    #         "version",
    #         "program",
    #         "instrument",
    #         "type",
    #         "json_schema",
    #         "json_schema_uploaded",
    #         "search_kw",
    #     }
    #     assert meta_resp["acronym"] == "TT_GRM"
    #     assert meta_resp["sp_id"] == 4
    #     assert meta_resp["version"] == "0.12"
    #     assert meta_resp["program"] == "CP"
    #     assert meta_resp["instrument"] == "GRM"
    #     assert meta_resp["type"] == "TT"


def test_save_fits(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test disk saving of remote fits file"""
    open_mock = mock.mock_open()
    with mock.patch(
        HTTPIO_REQUEST, return_value=sync_2xx_response
    ) as mocked, mock.patch("urllib.request.urlopen", open_mock), mock.patch(
        "builtins.open", open_mock, create=False
    ):
        mocked.return_value.json = lambda: [
            {"acronym": "ECL-SKY-IMA", "url": "fake://data/url/fake/file.fits"}
        ]
        new_files = sdb_client.save_fits_files(product_id=12, filename="tmp.fits")

        # requests.get should have been called 1 time
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "4", "c": "1::eq::12"},
        )
        assert new_files == ["./tmp.fits"]
        # each of these should create only one file
        files1 = sdb_client.save_fits_files(product_id=12, filename="tmp.fits")
        files2 = sdb_client.save_fits_files(product_id=12, filename="./tmp.fits")
        files3 = sdb_client.save_fits_files(product_id=12, dirname="./")
        files4 = sdb_client.save_fits_files(product_id=12)
        files5 = sdb_client.save_raw_fits_files(product_id=1)
        assert files1 == ["./tmp.fits"]
        assert files2 == ["./tmp.fits"]
        assert files3 == ["./fake-file.fits"]
        assert files4 == ["./fake-file.fits"]
        assert files5 == ["./fake-file.fits"]
        calls = [
            mock.call(files1[0], "wb"),
            mock.call(files2[0], "wb"),
            mock.call(files3[0], "wb"),
            mock.call(files4[0], "wb"),
            mock.call(files5[0], "wb"),
        ]
        open_mock.assert_has_calls(calls, any_order=True)

    # if sdb_client.ssl != {}:
    #     open_mock = mock.mock_open()
    #     with mock.patch("builtins.open", open_mock, create=True):
    #         # each of these should create only one file
    #         files1 = sdb_client.save_fits_files(product_id=12, filename="tmp.fits")
    #         files2 = sdb_client.save_fits_files(product_id=12, filename="./tmp.fits")
    #         files3 = sdb_client.save_fits_files(product_id=12, dirname="./")
    #         files4 = sdb_client.save_fits_files(product_id=12)
    #         files5 = sdb_client.save_raw_fits_files(product_id=1)
    #         assert files1 == ["./tmp.fits"]
    #         assert files2 == ["./tmp.fits"]
    #         assert files3 == ["./ECL-SKY-IMA-12.fits"]
    #         assert files4 == ["./ECL-SKY-IMA-12.fits"]
    #         assert files5 == ["./202002-1.fits"]
    #         calls = [
    #             mock.call(files1[0], "wb"),
    #             mock.call(files2[0], "wb"),
    #             mock.call(files3[0], "wb"),
    #             mock.call(files4[0], "wb"),
    #             mock.call(files5[0], "wb"),
    #         ]
    #         open_mock.assert_has_calls(calls, any_order=True)
    #         open_mock.return_value.write.assert_called()
    #     with pytest.raises(ValueError):
    #         # obs_id=1 returns multiple files and a filename was provided
    #         sdb_client.save_fits_files(obs_id=1, filename="tmp.fits")


def test_save_latest_fits(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test disk saving of remote fits file"""
    open_mock = mock.mock_open()
    with mock.patch(
        HTTPIO_REQUEST, return_value=sync_2xx_response
    ) as mocked, mock.patch("urllib.request.urlopen", open_mock), mock.patch(
        "builtins.open", open_mock, create=False
    ):
        mocked.return_value.json = lambda: [
            {
                "acronym": "OLDEST",
                "added_at": "2019",
                "url": "fake://data/2019/old.fits",
            },
            {
                "acronym": "YOUNGEST",
                "added_at": "2021",
                "url": "fake://data/2021/young.fits",
            },
            {
                "acronym": "MIDDLE",
                "added_at": "2020",
                "url": "fake://data/2020/mid.fits",
            },
        ]
        # each of these should create only one file
        file1 = sdb_client.save_latest_fits_file(url="fake://*", filename="tmp.fits")

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "4;6", "c": "4::eq::fake://*"},
        )
        file2 = sdb_client.save_latest_fits_file(url="fake://*", dirname="./fits")
        file3 = sdb_client.save_latest_fits_file(url="fake://*")
        assert file1 == "./tmp.fits"
        assert file2 == "./fits/2021-young.fits"
        assert file3 == "./2021-young.fits"
        calls = [
            mock.call(file1, "wb"),
            mock.call(file2, "wb"),
            mock.call(file3, "wb"),
        ]
        open_mock.assert_has_calls(calls, any_order=True)


def test_save_latest_raw_fits(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test disk saving of remote fits file"""
    open_mock = mock.mock_open()
    with mock.patch(
        HTTPIO_REQUEST, return_value=sync_2xx_response
    ) as mocked, mock.patch("urllib.request.urlopen", open_mock), mock.patch(
        "builtins.open", open_mock, create=False
    ):
        mocked.return_value.json = lambda: [
            {
                "acronym": "OLDEST",
                "added_at": "2019",
                "url": "fake://data/2019/old.fits",
            },
            {
                "acronym": "YOUNGEST",
                "added_at": "2021",
                "url": "fake://data/2021/young.fits",
            },
            {
                "acronym": "MIDDLE",
                "added_at": "2020",
                "url": "fake://data/2020/mid.fits",
            },
        ]
        # each of these should create only one file
        file1 = sdb_client.save_latest_raw_fits_file(
            url="fake://*", filename="tmp.fits"
        )

        # requests.get should have been called 2 times
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/l1",
            params={"a": "4;6", "c": "4::eq::fake://*"},
        )
        file2 = sdb_client.save_latest_raw_fits_file(url="fake://*", dirname="./fits")
        file3 = sdb_client.save_latest_raw_fits_file(url="fake://*")
        assert file1 == "./tmp.fits"
        assert file2 == "./fits/2021-young.fits"
        assert file3 == "./2021-young.fits"
        calls = [
            mock.call(file1, "wb"),
            mock.call(file2, "wb"),
            mock.call(file3, "wb"),
        ]
        open_mock.assert_has_calls(calls, any_order=True)


@pytest.mark.skip(reason="Avoid connection to SDB and token management in CI")
def test_latest_search(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test latest url retrieval"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_2xx_response) as mocked:
        mocked.return_value.json = lambda: [
            {"acronym": "OLDEST", "added_at": "2019", "url": "fake://data/old"},
            {"acronym": "YOUNGEST", "added_at": "2021", "url": "fake://data/young"},
            {"acronym": "MIDDLE", "added_at": "2020", "url": "fake://data/mid"},
        ]
        resp = sdb_client.get_latest_fits_url()

        # requests.get should have been with outputs 4(added_at) and 6(url)
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "4;6"},
        )
        assert resp == "fake://data/young"

    # if sdb_client.ssl != {}:
    #     # get some specific product
    #     resp = sdb_client.search(
    #         product_id=666, outputs=["sp_acronym", "added_at", "url"]
    #     )
    #     some_prod = resp.json()
    #     assert len(some_prod) == 1
    #     # get all previous products
    #     resp = sdb_client.search(
    #         card=some_prod[0]["sp_acronym"],
    #         date=f"<={some_prod[0]['added_at']}",
    #         outputs=["product_id", "added_at"],
    #     )
    #     prev_prods = resp.json()
    #     if len(prev_prods) < 2:
    #         pytest.skip("Cannot carry latest url search test: only one product")
    #
    #     # assert that get_latest_fits_url returns proper url
    #     latest_url = sdb_client.get_latest_fits_url(
    #         card=some_prod[0]["sp_acronym"], date=f"<={some_prod[0]['added_at']}"
    #     )
    #     assert latest_url == some_prod[0]["url"]
    #     # assert that save_latest_fits_file saves proper file
    #     open_mock = mock.mock_open()
    #     with mock.patch("builtins.open", open_mock, create=True):
    #         # each of these should create only one file
    #         file1 = sdb_client.save_latest_fits_file(
    #             filename="tmp.fits",
    #             card=some_prod[0]["sp_acronym"],
    #             date=f"<={some_prod[0]['added_at']}",
    #         )
    #         file2 = sdb_client.save_latest_fits_file(
    #             dirname="tmp/",
    #             card=some_prod[0]["sp_acronym"],
    #             date=f"<={some_prod[0]['added_at']}",
    #         )
    #         assert file1 == "./tmp.fits"
    #         assert file2 == f"tmp/{some_prod[0]['sp_acronym']}-666.fits"
    #         calls = [
    #             mock.call(file1, "wb"),
    #             mock.call(file2, "wb"),
    #         ]
    #         open_mock.assert_has_calls(calls, any_order=True)
    #         open_mock.return_value.write.assert_called()


def test_get_fits_content(
    sdb_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test fits content retrieval"""
    # test that without astropy everything goes fine
    sdb_client.has_astropy = False
    with pytest.raises(SystemExit):
        sdb_client.get_fits_content(product_id=666)
    with pytest.raises(SystemExit):
        sdb_client.get_latest_fits_content(card="CARD", date="<=2021")

    from package.svom.messaging.sdbio import HAS_ASTROPY

    if not HAS_ASTROPY:
        pytest.skip("astropy not found. Skipping content retrieval methods")

    sdb_client.has_astropy = True
    open_mock = mock.mock_open()
    with mock.patch(
        HTTPIO_REQUEST, return_value=sync_2xx_response
    ) as mocked, mock.patch("urllib.request.urlopen", open_mock), mock.patch(
        "astropy.io.fits.open", return_value="FITS_CONTENT"
    ):
        mocked.return_value.json = lambda: [
            {"acronym": "SVO-THE-ONLY", "url": "fake://data/the/one"}
        ]
        resp = sdb_client.get_fits_content(card="CARD", date="<2021")

        # requests.get should have been with outputs 4(added_at) and 6(url)
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "4", "c": "3::eq::CARD;6::lt::2021"},
        )
        open_mock.assert_called_once_with("https://fsc.svom.org/sdb/data/the/one")
        assert resp == "FITS_CONTENT"


@pytest.mark.skip(reason="Avoid connection to SDB and token management in CI")
def test_get_latest_content(sdb_client, sync_2xx_response):
    """Test method get latest content"""
    # pylint: disable=redefined-outer-name
    from package.svom.messaging.sdbio import HAS_ASTROPY

    if not HAS_ASTROPY:
        pytest.skip("astropy not found. Skipping content retrieval methods")

    sdb_client.has_astropy = True
    open_mock = mock.mock_open()
    # latest_fits_content
    with mock.patch(
        HTTPIO_REQUEST, return_value=sync_2xx_response
    ) as mocked, mock.patch("urllib.request.urlopen", open_mock), mock.patch(
        "astropy.io.fits.open", return_value="FITS_CONTENT"
    ):
        mocked.return_value.json = lambda: [
            {"acronym": "OLDEST", "added_at": "2019", "url": "fake://data/old"},
            {"acronym": "YOUNGEST", "added_at": "2021", "url": "fake://data/young"},
            {"acronym": "MIDDLE", "added_at": "2020", "url": "fake://data/mid"},
        ]
        resp = sdb_client.get_latest_fits_content(card="CARD", date="<2021")

        # requests.get should have been with outputs 4(added_at) and 6(url)
        mocked.assert_called_once_with(
            "GET",
            "https://fsc.svom.org/sdb/server/search/products",
            params={"a": "4;6", "c": "3::eq::CARD;6::lt::2021"},
        )
        open_mock.assert_called_once_with("https://fsc.svom.org/sdb/data/young")
        assert resp == "FITS_CONTENT"

        with pytest.raises(ValueError):
            # search returns multiple file so this should fail
            sdb_client.get_fits_content(product_id=666)

    # if sdb_client.ssl != {}:
    #     # get some specific product
    #     resp = sdb_client.search(
    #         product_id=666, outputs=["sp_acronym", "added_at", "url"]
    #     )
    #     some_prod = resp.json()
    #     assert len(some_prod) == 1
    #     # get all previous products
    #     resp = sdb_client.search(
    #         card=some_prod[0]["sp_acronym"],
    #         date=f"<={some_prod[0]['added_at']}",
    #         outputs=["product_id", "added_at"],
    #     )
    #     prev_prods = resp.json()
    #     if len(prev_prods) < 2:
    #         pytest.skip("Cannot carry latest url search test: only one product")
    #     # assert that get_latest_fits_content returns proper file
    #     with pytest.raises(ValueError):
    #         # search returns multiple file so this should fail
    #         fits_content = sdb_client.get_fits_content(
    #             card=some_prod[0]["sp_acronym"], date=f"<={some_prod[0]['added_at']}"
    #         )
    #     fits_content = sdb_client.get_fits_content(product_id=666)
    #     latest_fits_content = sdb_client.get_latest_fits_content(
    #         card=some_prod[0]["sp_acronym"], date=f"<={some_prod[0]['added_at']}"
    #     )
    #     # full comparison doesn't work because objects are not the same in memory (duh)
    #     assert fits_content[0].header == latest_fits_content[0].header
    #     # test that without astropy everything goes fine
    #     sdb_client.has_astropy = False
    #     with pytest.raises(SystemExit):
    #         fits_content = sdb_client.get_fits_content(product_id=666)
    #     with pytest.raises(SystemExit):
    #         fits_content = sdb_client.get_latest_fits_content(
    #             card=some_prod[0]["sp_acronym"], date=f"<={some_prod[0]['added_at']}"
    #         )
