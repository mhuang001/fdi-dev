#!/usr/scripts/package3
"""
 Simple publisher example using the svom.messaging.natsio module
 Usage info: package3 pub_example.py --help

 Henri Louvin - henri.louvin@cea.fr
"""

# Log
import sys
import logging

log = logging.getLogger("pub_example")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
# NATS
from svom.messaging import natsio_from_args


def main():
    """
    Instantiate NATS client and subscribe to {args.channels}
    """
    # Retrieve nats_client and channels list from command line
    nats_client, args = natsio_from_args()
    # Publish message to all channels
    for channel in args.channels:
        nats_client.publish(channel, args.message)
    # Stop nats client neatly
    nats_client.stop()


if __name__ == "__main__":
    main()
