"""
MQTT client tool for Svom

It is based on the asynio mqtt package (https://github.com/sbtinstruments/asyncio-mqtt) using the
paho mqtt client library (https://github.com/eclipse/paho.mqtt.package)

Lea Jouvin - lea.jouvin@cea.fr
"""
# Log
import time
import threading
import signal
import logging
import asyncio

# System
from asyncio_mqtt import Client as MQTT
from asyncio_mqtt.error import MqttConnectError, MqttCodeError

from svom.messaging.httpio import power_delay

log = logging.getLogger("mqtt_client")

# Max connection attempt
MAX_CONNECT_ATTEMPTS = 5
# Max delay before attempting a reconnection (usefull for the reconnect method).
# We use a power law to increase the reconnection time between each attemp but
# we don't want that it exceeds a certain delay, fix to 10 min
MAX_DELAY_CONNECT = 10 * 60 * 60
# delay computation function


class MqttIo:
    """
    asynchronous MQTT client.

    Connect to the MQTT client. Start a new asyncio event loop only if none
    is given and running.

    Parameters
    ----------
    host : str
        hostname or IP address of the remote broker
    port : int
        network port of the server host to connect to
    user : str, optional
        username for broker identification
    password : str, optional
        password for broker identification
    client_id : str, optional
        client_id is the unique client id string used when connecting to the
        broker. If client_id is zero length or None, then the behaviour is
        defined by which protocol version is in use. If using MQTT v3.1.1, then
        a zero length client id will be sent to the broker and the broker will
        generate a random for the client. If using MQTT v3.1 then an id will be
        randomly generated. In both cases, clean_session must be True. If this
        is not the case a ValueError will be raised. See Paho mqtt client package doc.
    clean_session : str, optional
        clean_session is a boolean that determines the client type. If True,
        the broker will remove all information about this client when it
        disconnects. If False, the client is a persistent client and
        subscription information and queued messages will be retained when the
        client disconnects.
        Note that a client will never discard its own outgoing messages on
        disconnect. Calling connect() or reconnect() will cause the messages to
        be resent.  Use reinitialise() to reset a client to its original state.
        The clean_session argument only applies to MQTT versions v3.1.1 and v3.1.
        It is not accepted if the MQTT version is v5.0 - use the clean_start
        argument on connect() instead. See Paho mqtt client package doc.
    on_message : callback function
        Define the default message received when subsriscriptsg to a topic. Should
        have the following signature on_message_callback(client, userdata, message).
        Default use de self.on_message
    loop : optional
        asyncio event loop
    """

    def __init__(self, host="123.56.102.90", port=31876, **kwargs):
        self.args = {
            "user": None,
            "password": None,
            "client_id": None,
            "clean_session": None,
            "on_message": None,
            "loop": None,
        }
        if set(kwargs.keys()).issubset(self.args.keys()):
            self.args.update(kwargs)
        else:
            log.error(
                "Error in MqttIo init: keyworded arguments should be a subset of %s",
                set(self.args.keys()),
            )
            raise AttributeError("Misuse of MqttIo init")

        if isinstance(port, str):
            port = int(port)
        # Define the MQTT client
        self.user_password = (self.args["user"], self.args["password"])
        self.pub_queue = []
        self.subs = set([])
        host = host.lstrip("http://")

        self._mqtt = MQTT(
            hostname=host,
            port=port,
            username=self.user_password[0],
            password=self.user_password[1],
            client_id=self.args["client_id"],
            clean_session=self.args["clean_session"],
        )
        self._mqtt._client.on_connect = self.on_connect
        self._mqtt._client.on_disconnect = self.on_disconnect
        if self.args["on_message"] is None:
            self._mqtt._client.on_message = self.default_on_message
        else:
            self._mqtt._client.on_message = self.args["on_message"]
        self.servers = [f"{host}:{port}"]

        # Retrieve event loop
        self.loop = self.args.get("loop")
        if self.loop is None:
            try:
                log.info("No loop argument provided, retrieving default asyncio loop")
                self.loop = asyncio.get_event_loop()
            except RuntimeError:
                log.info("Failed to retrieve asyncio event loop. Creating a new one...")
                self.loop = asyncio.new_event_loop()

        # loop management depends if loop is running or not
        self.thread = None
        self.is_connecting = True
        self.is_closing = False
        if not self.loop.is_running():
            # if loop is not already running, create separate thread
            # for connection and execute run_forever
            log.info("Async loop is not running, running it in new thread")
            self.thread = threading.Thread(target=self._run)
            # force server to shutdown gracefully on SIGINT. This could
            # be done for SIGHUP and/or SIGTERM but may not be clever
            if threading.current_thread() == threading.main_thread():
                signal.signal(signal.SIGINT, self.sigint_handler)
            # starting MQTT client starts asyncio event loop
            self.thread.start()
        else:
            # if loop is already running, execute connection in current loop. We
            # should not call run_until_complete if the loop is already running.
            log.info("Async loop is already running, adding connect call as coroutine")
            asyncio.run_coroutine_threadsafe(self._connect(servers=self.servers), loop=self.loop)

    def _run(self):
        """Runs connections to MQTT, then starts asynchronous loop"""
        log.info("run until complete")
        self.loop.run_until_complete(self._connect(servers=self.servers))

        # run async loop forever
        log.info("run async loop forever")
        self.loop.run_forever()

    async def _connect(self, servers):
        """Connect to MQTT server

        Parameters
        ----------
        servers : str
            comscriptsation of the hostname or IP address of the remote broker and
            the network port of the server host to connect to.
        """
        connect_attempt = 0
        while not self._mqtt._client.is_connected():
            try:
                log.info(
                    "Attempting connection to mqtt server %s as '%s'",
                    servers[0],
                    self.user_password[0],
                )
                await self._mqtt.connect()
            except Exception as err:
                log.exception("Connection failed")
                if "Connection refused" in str(err):
                    log.exception("Bad user/password")
                    self.is_connecting = False
                    self.loop.call_soon_threadsafe(self.stop)
                    return
                if connect_attempt < MAX_CONNECT_ATTEMPTS:
                    connect_attempt += 1
                    delay = power_delay(connect_attempt, backoff_factor=1)
                    log.info("Retrying connection in %ss.", delay)
                    await asyncio.sleep(delay)
                else:
                    log.error("Maximum attempts reached. Giving up...")
                    log.error("Are you sure that the host or the port is valid ?")
                    self.is_connecting = False
                    self.loop.call_soon_threadsafe(self.stop)
                    return
            else:
                log.info("Connected.")
                self.is_connecting = False

    async def _reconnect(self, servers):
        """Reconnect to the MQTT server

        Parameters
        ----------
        servers : str
            comscriptsation of the hostname or IP address of the remote broker and
            the network port of the server host to connect to.
        """

        self.is_connecting = True
        connect_attempt = 0
        while not self._mqtt._client.is_connected():
            try:
                log.info(
                    "Attempting reconnection to mqtt server %s as '%s'",
                    servers[0],
                    self.user_password[0],
                )
                await self._mqtt.connect()

            except Exception as err:
                log.exception("Connection failed.")
                connect_attempt += 1
                delay = power_delay(connect_attempt, backoff_factor=1)
                delay = min(delay, MAX_DELAY_CONNECT)
                log.info("Retrying reconnection in %ss.", delay)
                log.info("NUmber of reconnect attempts %s", connect_attempt)
                await asyncio.sleep(delay)

            else:
                log.info("Client ReConnected.")
                self.is_connecting = False

    # pylint: disable=unused-argument
    def default_on_message(self, client, userdata, message):
        """Define the default message received callback implementation when subscribing to a topic.

        Expected signature of the method for paho mqtt client is:

        ::

            on_message_callback(client, userdata, message)

        Parameters
        ----------
        client : Client
            the client instance for this callback
        userdata : set
            the private user data as set in Client() or userdata_set()
        message :  `an instance of MQTTMessage`
            This is a class with members topic, payload, qos, retain.
        """
        topic = message.topic
        message_decode = message.payload.decode("utf-8")
        # Print to log
        log.info("Message received on channel '%s': %s", topic, message_decode)

    # pylint: disable=unused-argument
    def on_connect(self, client, userdata, flags, rc, properties=None):
        """The callback for when the client receives a CONNACK response MQTT server.

        Expected signature of the method for paho mqtt client is:

        ::

            on_connect_callback(client, userdata, flags, rc)

        Parameters
        ----------
        client : Client
            the client instance for this callback
        userdata : set
            the private user data as set in Client() or userdata_set()
        flags : str
            flags value
        rc : int
            return code used for checking that the connection was established
        """
        # Return early if already connected. Sometimes, paho-mqtt calls _on_connect
        # multiple times. Maybe because we receive multiple CONNACK messages
        # from svom.messaging.he server. In any case, we return early so that we don't set
        # self._connected twice (as it raises an asyncio.InvalidStateError).

        if self._mqtt._connected.done():
            log.info("Already connected")
            return

        if rc == 0:
            log.info("Connected to MQTT broker")
            self._mqtt._connected.set_result(rc)
        else:
            log.info("Connected failed with return code= %s", rc)
            self._mqtt._connected.set_exception(MqttConnectError(rc))

    # pylint: disable=unused-argument
    def on_disconnect(self, client, userdata, rc, properties=None):
        """The callback for when the client disconnects.

        Expected signature of the method for paho mqtt client is:

        ::
            on_disconnect_callback(client, userdata, flags, rc)

        Parameters
        ----------
        client : Client
            the client instance for this callback
        userdata : set
            the private user data as set in Client() or userdata_set()
        rc : int
            return code used for checking that the connection was established
        """
        # Return early if the disconnect is already acknowledged.
        # Sometimes (e.g., due to timeouts), paho-mqtt calls _on_disconnect
        # twice. We return early to avoid setting self._disconnected twice
        # (as it raises an asyncio.InvalidStateError).
        if self._mqtt._disconnected.done():
            logging.info("disconnect is already acknowledged")
            # return
        # Return early if we are not connected yet. This avoids calling
        # `_disconnected.set_exception` with an exception that will never
        # be retrieved (since `__aexit__` won't get called if `__aenter__`
        # fails). In turn, this avoids asyncio debug messages like the
        # following:
        #
        #   "[asyncio] Future exception was never retrieved"
        #
        # See also:
        # https://docs.package.org/3/library/asyncio-dev.html#detect-never-retrieved-exceptions
        elif not self._mqtt._connected.done() or self._mqtt._connected.exception() is not None:
            logging.info("disconnect due to not connected yet")
            return
        else:
            if rc == 0:
                log.info("Client disconnects")
                self._mqtt._disconnected.set_result(rc)
            else:
                log.info("Unexpected disconnect with return code= %s", rc)
                self._mqtt._disconnected.set_exception(MqttCodeError(rc, "Unexpected disconnect"))

        # If we disconnect because we are closing, we don't want to try to
        # reconnect.
        if not self.is_closing:
            self._mqtt._client._state = 0
            self._mqtt._connected = asyncio.Future()
            asyncio.run_coroutine_threadsafe(self._reconnect(servers=self.servers), loop=self.loop)

    def subscribe(self, topic, qos=1):
        """Launch subscription as async task.

        For persistent service, to get back the messages received during
        disconnection, the quality of service parameter (qos) should be at least
        one (the message is delivered at least once and is not deleted until it
        is received by a subscriber). See here for more details
        (https://www.eclipse.org/paho/files/mqttdoc/MQTTClient/html/qos.html).

        Parameters
        ----------
        topic : str
            A string specifying the subscription topic to subscribe to.
        qos : int, default 1
            The desired quality of service level for the subscription.
            Possible values are 0, 1 and 2.
        """
        log.info("Subscriscriptsg to topic '%s'", topic)
        # Add the task subscribe to the current loop
        asyncio.run_coroutine_threadsafe(self._subscribe(topic=topic, qos=qos), loop=self.loop)

    async def _subscribe(self, topic, qos):
        """New subscription tp {topic}

        Parameters
        ----------
        topic : str
            A string specifying the subscription topic to subscribe to.
        qos : int, default 1
            The desired quality of service level for the subscription.
            Possible values are 0, 1 and 2.
        """
        try:
            # check connection
            if not self._mqtt._client.is_connected() or self.is_connecting:
                log.warning(
                    "Subscription to channel '%s' on hold: waiting for connection",
                    topic,
                )
            while not self._mqtt._client.is_connected() or self.is_connecting:
                await asyncio.sleep(1)

            await self._mqtt.subscribe(topic, qos=qos)

        except Exception as err:
            log.error("Subscription to topic '%s' failed.", topic)
            log.info(str(err))
        else:
            log.info("Subscription to topic '%s' sucessed.", topic)
            self.subs.add(topic)

    def publish(self, topic, data, qos=1):
        """Launch publish as async task

        For persistent service, to get back the messages publish during
        disconnection of the client, the quality of service parameter (qos)
        should be at least one (The message is delivered at least once and is
        not deleted until it is received by a subscriber). See here for more
        details (https://www.eclipse.org/paho/files/mqttdoc/MQTTClient/html/qos.html).

        Parameters
        ----------
        topic : str
            A string specifying the subscription topic to subscribe to.
        data : str
            message to be publish
        qos : int, default 1
            The desired quality of service level for the subscription.
            Possible values are 0, 1 and 2.
        """
        future = asyncio.run_coroutine_threadsafe(
            self._publish(topic=topic, data=data, qos=qos), loop=self.loop
        )
        self.pub_queue.append(future)

    async def _publish(self, topic, data, qos=1):
        """Publish {data} to channel {topic}

        Parameters
        ----------
        topic : str
            A string specifying the subscription topic to subscribe to.
        data : str
            message to be publish
        qos : int, default 1
            The desired quality of service level for the subscription.
            Possible values are 0, 1 and 2.
        """
        connect_attempt = 0
        try:
            # # Check connection
            if not self._mqtt._client.is_connected() or self.is_connecting:
                log.warning("Subscription to topic '%s' on hold: waiting for connection", topic)
            while not self._mqtt._client.is_connected() or self.is_connecting:
                connect_attempt += 1
                delay = power_delay(connect_attempt, backoff_factor=1)
                delay = min(delay, MAX_DELAY_CONNECT)
                log.info("Retrying publishing message in %ss.", delay)
                await asyncio.sleep(delay)

            info = self._mqtt._client.publish(topic=topic, payload=data, qos=qos)
            # Early out on error
            if info.rc != 0:
                raise MqttCodeError(info.rc, "Could not publish message")
            log.info("Sending message '%s' to channel '%s'", data, topic)
        except Exception as err:
            log.exception(str(err))

    def stop(self):
        """MQTT client cleanup and close"""
        log.info("Starting MQTT closing procedure")
        # sleep a3 bit to give time to everything async to settle down
        time.sleep(0.5)
        self.is_closing = True
        # delay stop call if connect in progress
        while self.is_connecting:
            time.sleep(1)
        # wait for publish tasks to finish
        if self._mqtt._client.is_connected():
            log.debug("Waiting for pending message publication")
            for future in self.pub_queue:
                if not future.done():
                    # Allows to check that the future object of the publish method is
                    # really finished before disconnecting.
                    future.result()
            # Disconnect only if Client were connected
            future_disconnect = asyncio.run_coroutine_threadsafe(
                self._mqtt.disconnect(), loop=self.loop
            )
            future_disconnect.result()
        else:
            log.debug("Cancelling pending message publication")
            for future in self.pub_queue:
                if not future.done():
                    future.cancel()

        # stop MQTT properly
        try:
            log.info("Closing MQTT client")
            if self.thread is not None:
                # thread and loop were started at the client initiatization
                # loop has to be stopped here
                log.info("Stopping async event loop")
                self.loop.call_soon_threadsafe(self.loop.stop)
        except Exception as err:
            log.exception(err)

    # pylint: disable=unused-argument
    def sigint_handler(self, signum, frame):
        """Stops gracefully, restore default signal handling and raises KeyboardInterrupt"""
        self.is_connecting = False
        self.stop()
        signal.signal(signal.SIGINT, signal.SIG_DFL)
        raise KeyboardInterrupt
