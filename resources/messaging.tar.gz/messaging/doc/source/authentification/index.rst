.. _authentification:

Foreword on Authentication
**************************

Foreword on Authentication
==========================

The `svom.messaging` package is using the `Requests <https://pypi.org/project/requests/>`_
python package to request servers, or fetch access tokens.
This very package comes with one caveat about **Authentication**:

-> If no authentication method is given with the auth argument, Requests will attempt to get the authentication credentials for the URL’s hostname from the
user’s netrc file. The netrc file overrides raw HTTP authentication headers set with headers=.

-> If credentials for the hostname are found, the request is sent with HTTP Basic Auth.

So, if the `~/.netrc` file exists on your system, any requests to the FSC might end with a 401 status code.
The `Authorization` header with the FSC tokens will be replaced by something coming from the `~/.netrc` file.

Reference:
* [python-requests](https://requests.readthedocs.io/en/latest/user/authentication/)


KcTokens class for the authentification at FSC
==============================================

HttpIo and all the classes that inherit from it, can use :ref:`KcTokens <tokens>` class to allow users or apps to get an access token before
any request. Dedicated to FSC, it relies on environment variables that **must** be set before using `KcTokens` (see next). Please note that if tokens contain a refresh token, this latter will be used to
refresh the access token.

Inside FSC configuration
~~~~~~~~~~~~~~~~~~~~~~~~

Two Docker secrets are set inside FSC, with a confidential Keycloak client: _client_id_ and _client_secret_, that allows an app to request
Keycloak for access tokens.

The KC_TYPE (Ex: KC_TYPE = "pipelines") -> this defines the docker secret to use to request Keycloak authentication server

Outside FSC configuration
~~~~~~~~~~~~~~~~~~~~~~~~~

Locally, for testing, the docker secrets DO NOT exist. To access protected FSC endpoints through the proxy `fsc.svom.[org|eu]`, you must use your `fsc.svom.[org|eu]` user account (based on Keycloak), and set:

**Personal user**

* KC_USERNAME -> a user username (usually email)
* KC_PASSWORD -> a user password
* KC_CLIENT_ID = "FSC_PUBLIC" -> the keycloak client to use to authenticate as a user.

**Service**

If you are not running in a docker environment and you do not have the possibility to use the docker secret, you can
define the two following env. The client secret is given as the docker secret inside the FSC but here you set it in
the variable KC_CLIENT_SECRET.

* KC_CLIENT_ID = "FPOC" -> the keycloak client to use to authenticate the service. Example: FPOC
* KC_CLIENT_SECRET = "" -> the keycloak secret to use to authenticate the service.