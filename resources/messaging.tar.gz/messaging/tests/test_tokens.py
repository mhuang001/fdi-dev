"""
tks.Kctks.Tokens test file
"""
import logging
import os
import sys
import base64
import json
import time
from unittest import mock
import asyncio
from requests import Response
import attrs
from aioresponses import aioresponses
import pytest

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)

import package.svom.messaging.tokens as tks
from package.svom.messaging.tokens import power_delay
from package.svom.messaging.httpio import HttpIo

log = logging.getLogger("test_kctokens")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)


KC_TOKEN_WITH_REFRESH_MOCK = tks.Tokens.from_dict(
    {
        "access_token": "XXXX.YYYY.ZZ",
        "expires_in": 13,
        "refresh_expires_in": 1800,
        "refresh_token": "AAA.BBB.C",
        "token_type": "bearer",
        "not_before_policy": 1234,
        "session_state": "",
        "scope": "https://fsc.svom.api",
    }
)

REFRESH_KC_TOKEN_WITH_REFRESH_MOCK = tks.Tokens.from_dict(
    {
        "access_token": "RRRR.ZZZZ.TT",
        "expires_in": 20,
        "refresh_expires_in": 1800,
        "refresh_token": "UUU.III.V",
        "token_type": "bearer",
        "not_before_policy": 1234,
        "session_state": "",
        "scope": "https://fsc.svom.api",
    }
)

BRICKS_KC_TOKEN_WITH_REFRESH_MOCK = tks.Tokens.from_dict(
    {
        "access_token": "MY.ACCESS.TOKEN",
        "expires_in": 500,
        "refresh_expires_in": 1800,
        "refresh_token": "ZE.REFRESH.TK",
        "token_type": "bearer",
        "not_before_policy": 1234,
        "session_state": "",
        "scope": "https://fsc.svom.api",
    }
)


def test_power_delay():
    """Test power delay"""
    res = power_delay(2)
    assert res == 2


@pytest.fixture(scope="module")
def kc_token():
    """return sync HttpIo"""
    os.environ["KC_CLIENT_ID"] = "FSC_PUBLIC"
    os.environ["KC_USERNAME"] = "toto@cea.fr"
    os.environ["KC_PASSWORD"] = "ZeFuckingPassword"
    kc_token = tks.KcTokens()
    return kc_token


@pytest.fixture(params=[200])
def tk_request_response(request):
    """mimics 'requests' success response"""
    fake_response = Response()
    fake_response.status_code = request.param
    fake_response.json = lambda: attrs.asdict(KC_TOKEN_WITH_REFRESH_MOCK)
    return fake_response


@pytest.fixture(params=[200])
def tk_bricks_response(request):
    """mimics 'requests' success response"""
    fake_response = Response()
    fake_response.status_code = request.param
    fake_response.json = lambda: attrs.asdict(BRICKS_KC_TOKEN_WITH_REFRESH_MOCK)
    return fake_response


@pytest.fixture(params=[200])
def tk_refresh_response(request):
    """mimics 'requests' success response"""
    fake_response = Response()
    fake_response.status_code = request.param
    fake_response.json = lambda: attrs.asdict(REFRESH_KC_TOKEN_WITH_REFRESH_MOCK)
    return fake_response


@pytest.fixture(params=[400])
def sync_4xx_response(request):
    """mimics 'requests' error response"""
    fake_response = Response()
    fake_response.status_code = request.param
    fake_response.json = lambda: {}
    return fake_response


def test_init_kctokens():
    """Test init tks.KcTokens instance"""
    os.environ = {}
    with pytest.raises(ValueError):
        kc = tks.KcTokens()

    os.environ["KC_TYPE"] = "pipeline"
    kc = tks.KcTokens()
    assert attrs.asdict(kc.config) == {
        "client_id": None,
        "client_secret": None,
        "username": None,
        "password": None,
    }

    os.environ.pop("KC_TYPE")
    os.environ["KC_CLIENT_ID"] = "FSC_PUBLIC"

    with pytest.raises(ValueError):
        kc = tks.KcTokens()

    os.environ["KC_USERNAME"] = "toto@cea.fr"
    os.environ["KC_PASSWORD"] = "ZeFuckingPassword"
    kc = tks.KcTokens()

    assert attrs.asdict(kc.config) == {
        "client_id": "FSC_PUBLIC",
        "client_secret": None,
        "username": "toto@cea.fr",
        "password": "ZeFuckingPassword",
    }


def test_classes_kctokens_for_resource_owner_credentials(kc_token):
    """Test Config and Payloads classes"""

    assert attrs.asdict(tks.Payload.from_config(kc_token.config)) == {
        "client_id": "FSC_PUBLIC",
        "username": "toto@cea.fr",
        "password": "ZeFuckingPassword",
        "scope": "https://fsc.svom.api",
        "grant_type": "password",
    }


def test_classes_kctokens_for_client_credentials():
    """Test Config and Payloads classes"""

    os.environ = {}
    os.environ["KC_TYPE"] = "pipelines"
    os.environ["PIPELINES_KC_CLIENT_ID"] = "FSC_PIPELINES"
    os.environ["PIPELINES_KC_CLIENT_SECRET"] = "MySecR3t!"
    tok = tks.KcTokens()

    assert attrs.asdict(tks.Payload.from_config(tok.config)) == {
        "client_id": "FSC_PIPELINES",
        "client_secret": "MySecR3t!",
        "scope": "https://fsc.svom.api",
        "grant_type": "client_credentials",
    }


def test_propagate_threshold(tk_bricks_response):
    """Test that the expires_at_threshold is correctly propagate in classes and subclasses"""
    os.environ["KC_CLIENT_ID"] = "FSC_PUBLIC"
    os.environ["KC_USERNAME"] = "toto@cea.fr"
    os.environ["KC_PASSWORD"] = "ZeFuckingPassword"
    expires_at_threshold = 264
    kc_token = tks.KcTokens(expires_at_threshold=expires_at_threshold)
    assert kc_token.expires_at_threshold == expires_at_threshold
    with mock.patch(
        "package.svom.messaging.tokens.requests.post", return_value=tk_bricks_response
    ) as mocked:
        header = kc_token.get_authorization_header()
        assert (
            kc_token.tokens_with_expirations_dates.tokens
            == BRICKS_KC_TOKEN_WITH_REFRESH_MOCK
        )

        assert (
            abs(
                kc_token.tokens_with_expirations_dates.expirations.expires_at
                - (time.time() + 500 - expires_at_threshold)
            )
            < 0.1
        )
        assert (
            abs(
                kc_token.tokens_with_expirations_dates.expirations.refresh_expires_at
                - (time.time() + 1800 - expires_at_threshold)
            )
            < 0.1
        )


def test_sync_request(
    tk_request_response, tk_refresh_response
):  # pylint: disable=redefined-outer-name
    """Check that token is fetch, then refreshed after expiration"""
    os.environ["KC_CLIENT_ID"] = "FSC_PUBLIC"
    os.environ["KC_USERNAME"] = "toto@cea.fr"
    os.environ["KC_PASSWORD"] = "ZeFuckingPassword"
    kc_token = tks.KcTokens()
    with mock.patch(
        "package.svom.messaging.tokens.requests.post", return_value=tk_request_response
    ) as mocked:
        header = kc_token.get_authorization_header()
        assert (
            kc_token.tokens_with_expirations_dates.tokens == KC_TOKEN_WITH_REFRESH_MOCK
        )
        assert (
            abs(
                kc_token.tokens_with_expirations_dates.expirations.expires_at
                - (time.time() + 13 - 10)
            )
            < 0.1
        )

        assert header == {"Authorization": "bearer XXXX.YYYY.ZZ"}

    time.sleep(3)
    with mock.patch(
        "package.svom.messaging.tokens.requests.post", return_value=tk_refresh_response
    ) as mocked:
        header = kc_token.get_authorization_header()
        assert (
            kc_token.tokens_with_expirations_dates.tokens
            == REFRESH_KC_TOKEN_WITH_REFRESH_MOCK
        )
        assert (
            abs(
                kc_token.tokens_with_expirations_dates.expirations.expires_at
                - (time.time() + 20 - 10)
            )
            < 0.1
        )

        assert header == {"Authorization": "bearer RRRR.ZZZZ.TT"}


def test_sync_fail_request(sync_4xx_response):  # pylint: disable=redefined-outer-name
    """test synchronous client post()"""
    os.environ["KC_CLIENT_ID"] = "FSC_PUBLIC"
    os.environ["KC_USERNAME"] = "toto@cea.fr"
    os.environ["KC_PASSWORD"] = "ZeFuckingPassword"
    kc_token = tks.KcTokens()
    with mock.patch(
        "package.svom.messaging.tokens.requests.post", return_value=sync_4xx_response
    ) as mocked:
        kc_token._request_tokens()
        assert kc_token.tokens_with_expirations_dates.tokens == tks.Tokens.from_dict({})
        assert kc_token.tokens_with_expirations_dates.expirations.expires_at


def test_async_request():
    """test asynchronous client get()"""
    os.environ["KC_CLIENT_ID"] = "FSC_PUBLIC"
    os.environ["KC_USERNAME"] = "toto@cea.fr"
    os.environ["KC_PASSWORD"] = "ZeFuckingPassword"
    loop = asyncio.get_event_loop()
    async_kc_token = tks.KcTokens(max_tries=2, expires_at_threshold=10, loop=loop)
    with aioresponses() as mock_aio_resp:
        mock_aio_resp.post(
            tks.AUTH_URL, payload=attrs.asdict(KC_TOKEN_WITH_REFRESH_MOCK)
        )
        resp = loop.run_until_complete(async_kc_token.async_get_authorization_header())
        assert (
            async_kc_token.tokens_with_expirations_dates.tokens
            == KC_TOKEN_WITH_REFRESH_MOCK
        )

        assert resp == {"Authorization": "bearer XXXX.YYYY.ZZ"}

    time.sleep(3)
    with aioresponses() as mock_aio_resp:
        mock_aio_resp.post(
            tks.AUTH_URL, payload=attrs.asdict(REFRESH_KC_TOKEN_WITH_REFRESH_MOCK)
        )
        resp = loop.run_until_complete(async_kc_token.async_get_authorization_header())
        assert (
            async_kc_token.tokens_with_expirations_dates.tokens
            == REFRESH_KC_TOKEN_WITH_REFRESH_MOCK
        )

        assert resp == {"Authorization": "bearer RRRR.ZZZZ.TT"}


def test_async_fail_request():
    """test asynchronous client get()"""
    os.environ["KC_CLIENT_ID"] = "FSC_PUBLIC"
    os.environ["KC_USERNAME"] = "toto@cea.fr"
    os.environ["KC_PASSWORD"] = "ZeFuckingPassword"
    loop = asyncio.get_event_loop()
    async_kc_token = tks.KcTokens(max_tries=2, expires_at_threshold=10, loop=loop)
    with aioresponses() as m:
        m.post(tks.AUTH_URL, payload={}, status=400)
        resp = loop.run_until_complete(async_kc_token.async_get_authorization_header())
        assert (
            async_kc_token.tokens_with_expirations_dates.tokens
            == tks.Tokens.from_dict({})
        )
        assert resp == {"Authorization": " "}


def test_bricks_token(tk_bricks_response):
    """Instanciate a HttpIo with a token supposedly red from svom.messaging.he bricks
    scheduler runtime_param.json file. Checks that no request to Keycloak are made if token ok,
    and request are made if token expired"""
    os.environ["KC_CLIENT_ID"] = "FSC_PUBLIC"
    os.environ["KC_USERNAME"] = "toto@cea.fr"
    os.environ["KC_PASSWORD"] = "ZeFuckingPassword"
    kc_token = tks.KcTokens()
    with mock.patch(
        "package.svom.messaging.tokens.requests.post", return_value=tk_bricks_response
    ) as mocked:
        kc_token.get_authorization_header()

    with mock.patch(
        "package.svom.messaging.httpio.KcTokens", return_value=kc_token
    ) as mocked:
        # as exported
        my_exported_tokens = attrs.asdict(kc_token.tokens_with_expirations_dates)

        # create new TokensWithExpirationsDates
        imported_tokens = tks.TokensWithExpirationsDates.from_dict(my_exported_tokens)

        # Import exported tokens with expirations date
        http_io = HttpIo(use_tokens=True, tokens=imported_tokens)

        with mock.patch(
            "package.svom.messaging.tokens.requests.post", return_value=None
        ) as mocked:
            header = http_io.kc_tokens.get_authorization_header()
            assert (
                http_io.kc_tokens.tokens_with_expirations_dates.tokens
                == BRICKS_KC_TOKEN_WITH_REFRESH_MOCK
            )
            assert (
                abs(
                    http_io.kc_tokens.tokens_with_expirations_dates.expirations.expires_at
                    - (time.time() + 500 - 10)
                )
                < 0.1
            )

            assert header == {"Authorization": "bearer MY.ACCESS.TOKEN"}


def test_token_from_env(tk_bricks_response):
    """Add token to env, checks correctly loaded in KcTokens"""
    os.environ["KC_CLIENT_ID"] = "FSC_PUBLIC"
    os.environ["KC_USERNAME"] = "toto@cea.fr"
    os.environ["KC_PASSWORD"] = "ZeFuckingPassword"
    kc_token = tks.KcTokens()
    with mock.patch(
        "package.svom.messaging.tokens.requests.post", return_value=tk_bricks_response
    ) as mocked:
        kc_token.get_authorization_header()

    # as exported
    # modify session_state to identify token after test
    kc_token.tokens_with_expirations_dates.tokens.session_state = "From Global Env"
    glob_tokens = attrs.asdict(kc_token.tokens_with_expirations_dates)

    os.environ.pop(tks.ENV_GLOBAL_TOKENS, None)
    os.environ.pop(tks.ENV_GLOBAL_TOKENS_BASE64, None)

    os.environ[tks.ENV_GLOBAL_TOKENS] = json.dumps(glob_tokens)
    new_kc_token = tks.KcTokens()
    assert (
        new_kc_token.tokens_with_expirations_dates.tokens.session_state
        == "From Global Env"
    )

    os.environ.pop(tks.ENV_GLOBAL_TOKENS, None)
    os.environ.pop(tks.ENV_GLOBAL_TOKENS_BASE64, None)
    # modify session_state to identify token after test
    kc_token.tokens_with_expirations_dates.tokens.session_state = (
        "From Global Env Base64"
    )
    glob_b64_tokens = attrs.asdict(kc_token.tokens_with_expirations_dates)

    os.environ[tks.ENV_GLOBAL_TOKENS_BASE64] = str(
        base64.b64encode(bytes(json.dumps(glob_b64_tokens), "utf-8"))
    )
    new_kc_token = tks.KcTokens()
    assert (
        new_kc_token.tokens_with_expirations_dates.tokens.session_state
        == "From Global Env Base64"
    )

    os.environ.pop(tks.ENV_GLOBAL_TOKENS, None)
    os.environ.pop(tks.ENV_GLOBAL_TOKENS_BASE64, None)
