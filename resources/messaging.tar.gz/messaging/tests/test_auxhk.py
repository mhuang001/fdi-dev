"""
AuxHkIo test file
"""
import logging
import os
import sys
import pytest
from unittest import mock
from requests import Response

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
from package.svom.messaging.auxhkio import AuxHkIo

log = logging.getLogger("test_auxhkio")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)

HTTPIO_REQUEST = "package.svom.messaging.httpio.requests.Session.request"


@pytest.fixture(scope="function")
def sync_200_response():
    """mimics 'requests' success response"""
    fake_response = Response()
    fake_response.status_code = 200
    fake_response.json = lambda: {"breakfast": "eggs"}
    return fake_response


@pytest.fixture(scope="function")
def auxhk_client():
    """return sync AuxHkIos"""
    # with mock.patch('svom.messaging.tokens.KcTokens._request_tokens'):
    sync_client = AuxHkIo("fake://auxhkmgr/", use_tokens=False)
    yield sync_client


def test_init():
    """Check that the use_tokens param is correctly passed to super()"""

    os.environ["KC_TYPE"] = "pipelines"
    client = AuxHkIo()
    assert client.kc_tokens is not None
    assert client.kc_tokens.tokens_with_expirations_dates is None


def test_search_oem(
    auxhk_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        response = auxhk_client.search_oem(bad_key="bad")
        mocked.assert_not_called()
        response = auxhk_client.search_oem(timefield="badtime", since=2)
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        response = auxhk_client.search_oem(
            timefield="oemtime",
            since="2017-01-01T03:15:10+02:00",
            until="2017-01-01T04:15:10+02:00",
        )
        response = auxhk_client.search_oem(oemid=2)
        # requests.get should have been called 2 times

        expected_calls = [
            mock.call(
                "GET",
                "fake://auxhkmgr/api/fpoc/oem",
                params={
                    "since": "20170101T011510UTC",
                    "until": "20170101T021510UTC",
                    "timeformat": "iso",
                    "timefield": "oemtime",
                    "page": 0,
                    "size": 100,
                    "sort": "oemTime:ASC",
                },
            ),
            mock.call(
                "GET",
                "fake://auxhkmgr/api/fpoc/oem",
                params={
                    "oemid": 2,
                    "page": 0,
                    "size": 100,
                    "sort": "oemTime:ASC",
                },
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_search_oef(
    auxhk_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        response = auxhk_client.search_oef(bad_key="bad")
        mocked.assert_not_called()
        response = auxhk_client.search_oef(timefield="badtime", since=2)
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        response = auxhk_client.search_oef(
            timefield="oeftime",
            since="2017-01-01T03:15:10+02:00",
            until="2017-01-01T04:15:10+02:00",
            eventcode="SAA, MXT",
        )
        response = auxhk_client.search_oef(oefid=2)
        # requests.get should have been called 2 times

        expected_calls = [
            mock.call(
                "GET",
                "fake://auxhkmgr/api/fpoc/oef",
                params={
                    "eventcode": "SAA,MXT",
                    "since": "20170101T011510UTC",
                    "until": "20170101T021510UTC",
                    "timeformat": "iso",
                    "timefield": "oeftime",
                    "page": 0,
                    "size": 100,
                    "sort": "oefTime:ASC",
                },
            ),
            mock.call(
                "GET",
                "fake://auxhkmgr/api/fpoc/oef",
                params={
                    "oefid": 2,
                    "page": 0,
                    "size": 100,
                    "sort": "oefTime:ASC",
                },
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_search_workplan(
    auxhk_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        response = auxhk_client.search_workplan(bad_key="bad")
        mocked.assert_not_called()
        response = auxhk_client.search_workplan(timefield="badtime", since=2)
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        response = auxhk_client.search_workplan(
            timefield="workplandate",
            since="2017-01-01T03:15:10+02:00",
            until="2017-01-01T04:15:10+02:00",
        )
        response = auxhk_client.search_workplan(hashid="2")
        # requests.get should have been called 2 times
        expected_calls = [
            mock.call(
                "GET",
                "fake://auxhkmgr/api/fpoc/workplan",
                params={
                    "since": "20170101T011510UTC",
                    "until": "20170101T021510UTC",
                    "timeformat": "iso",
                    "timefield": "workplandate",
                    "page": 0,
                    "size": 100,
                    "sort": "productionDate:ASC",
                },
            ),
            mock.call(
                "GET",
                "fake://auxhkmgr/api/fpoc/workplan",
                params={
                    "hashid": "2",
                    "page": 0,
                    "size": 100,
                    "sort": "productionDate:ASC",
                },
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_search_obs_id(
    auxhk_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test VHF-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        response = auxhk_client.search_obsid(bad_key="bad")
        mocked.assert_not_called()
        response = auxhk_client.search_obsid(timefield="badtime", since=2)
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        response = auxhk_client.search_obsid(
            timefield="obsiddate",
            since="2017-01-01T03:15:10+02:00",
            until="2017-01-01T04:15:10+02:00",
        )
        response = auxhk_client.search_obsid(obsid=2)
        # requests.get should have been called 2 times

        expected_calls = [
            mock.call(
                "GET",
                "fake://auxhkmgr/api/fpoc/obsids",
                params={
                    "since": "20170101T011510UTC",
                    "until": "20170101T021510UTC",
                    "timeformat": "iso",
                    "timefield": "obsiddate",
                    "page": 0,
                    "size": 100,
                    "sort": "productionDate:ASC",
                },
            ),
            mock.call(
                "GET",
                "fake://auxhkmgr/api/fpoc/obsids",
                params={
                    "obsid": 2,
                    "page": 0,
                    "size": 100,
                    "sort": "productionDate:ASC",
                },
            ),
        ]

        assert mocked.mock_calls == expected_calls


def test_create_set(
    auxhk_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test AUXHK-DB create_set"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test with valid kwargs
        auxhk_client.create_set(
            resources=["TestOefFile"], resourcetype="oef", startdate="2000"
        )
        mocked.assert_called_once_with(
            "POST",
            "fake://auxhkmgr/api/fpoc/oef",
            headers={"Content-Type": "application/json", "Accept": "application/json"},
            json={
                "insertionmode": "update",
                "startdate": "2000",
                "size": 1,
                "format": "OefSetDto",
                "datatype": "OefDto",
                "resources": ["TestOefFile"],
            },
        )
