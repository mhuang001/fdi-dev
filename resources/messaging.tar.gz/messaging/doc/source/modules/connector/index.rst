.. _connector:

*************
NatsConnector
*************

Reference/API
=============

.. automodapi:: package.svom.messaging.connector
    :no-inheritance-diagram:
    :include-all-objects:
    :allowed-package-names: