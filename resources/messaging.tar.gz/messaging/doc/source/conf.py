# Configuration file for the Sphinx documentation builder.
#
# This file only contains a selection of the most common options. For a full
# list see the documentation:
# https://www.sphinx-doc.org/en/master/usage/configuration.html

# -- Path setup --------------------------------------------------------------

# If extensions (or modules to document with autodoc) are in another directory,
# add these directories to sys.path here. If the directory is relative to the
# documentation root, use os.path.abspath to make it absolute, like shown here.
#
import os
import sys

# Load all of the global Astropy configuration
from sphinx_astropy.conf import *

sys.path.insert(0, os.path.abspath("../.."))


# -- Project information -----------------------------------------------------

project = "messaging"
copyright = "2022, Lea Jouvin"
author = "Lea Jouvin"
html_show_copyright = False
# The full version, including alpha/beta/rc tags
release = "0.1"


# -- General configuration ---------------------------------------------------

# Define automatic links to the documentation of objects in other projects.
intersphinx_mapping = {}
intersphinx_mapping["python"] = ("https://docs.python.org/3", None)
intersphinx_mapping["numpy"] = ("https://numpy.org/doc/stable/", None)
intersphinx_mapping["astropy"] = ("https://docs.astropy.org/en/latest/", None)
intersphinx_mapping["requests"] = ("https://requests.readthedocs.io/en/latest/", None)

# Add any Sphinx extension module names here, as strings. They can be
# extensions coming with Sphinx (named 'sphinx.ext.*') or your custom
# ones.
extensions = [
    "sphinx_click.ext",
    "sphinx_rtd_theme",
    "sphinx.ext.viewcode",  # add possibility to view source code
    "sphinx.ext.intersphinx",  # can generate automatic links to the documentation of objects in other projects.
    "sphinx.ext.extlinks",  # Markup to shorten external links
    "sphinx.ext.doctest",  # Test snippets in the documentation
    "sphinx.ext.autosummary",  # Generate autodoc summaries
    "numpydoc",
    "sphinx_automodapi.automodapi",  # Sphinx directives that help faciliate the automatic generation of API documentation pages. Need to install: pip install sphinx-automodapi
    "sphinx_automodapi.smart_resolver",
]

# Usage of automodapi implies
#numpydoc_show_class_members = False

#autosummary_generate = True

numpydoc_xref_param_type = True
numpydoc_xref_ignore = {"optional", "type_without_description", "BadException"}

# Add any paths that contain templates here, relative to this directory.
templates_path = ["_templates"]

# List of patterns, relative to source directory, that match files and
# directories to ignore when looking for source files.
# This pattern also affects html_static_path and html_extra_path.
exclude_patterns = []


# -- Options for HTML output -------------------------------------------------

# The theme to use for HTML and HTML Help pages.  See the documentation for
# a list of builtin themes.
# To use sphinx_rtd_theme, need to install it: pip install -U sphinx-rtd-theme
html_theme = "sphinx_fsc_theme"

# Standard options
html_theme_options = {
    "analytics_id": "",
    "logo_only": False,
    "display_version": True,
    "prev_next_buttons_location": "bottom",
    # Toc options
    "collapse_navigation": True,
    "sticky_navigation": True,
    "navigation_depth": 4,
}


# Add any paths that contain custom static files (such as style sheets) here,
# relative to this directory. They are copied after the builtin static files,
# so a file named "default.css" will overwrite the builtin "default.css".
html_static_path = ["_static"]

#inheritance_graph_attrs = dict(rankdir="LR", size='""', fontsize=14, ratio="compress")



# -------------------------------------------------------------------------------------
# The 2 following methods allows to exclude imported members for automodapi.
# See: https://github.com/astropy/sphinx-automodapi/issues/119


def patch_automodapi(app):
    """Monkey-patch the automodapi extension to exclude imported members"""
    from sphinx_automodapi import automodsumm
    from sphinx_automodapi.utils import find_mod_objs

    automodsumm.find_mod_objs = lambda *args: find_mod_objs(args[0], onlylocals=True)


def setup(app):
    app.connect("builder-inited", patch_automodapi)
