"""
Keycloak Token tool.

Request Keycloak server for user/app tokens, to set "Authorization" headers.

@author: maxime.bocquier@cea.fr

Inside FSC: "client credential flow": a pipeline has access through docker secret to
dedicated keycloak "confidential" :

* client_id
* client_secret

To get an access token we must POST to keycloak with a payload like:

::

    payload = {
        "client_id": "ZeConfidentialClientId",
        "client_secret": "ZeConfidentialClientSecret",
        "grant_type": "client_credentials",
        "scope": "https://fsc.svom.api"
    }

Outside FSC: "Direct Access Grant": the user is authenticated and its credentials are used in app/
pipeline. Dedicated keycloak 'public' clients. Tokens:

::

    payload = {
        "client_id": "ZePublicClientId",
        "username": "username",
        "password": "whatever"
        "grant_type": "password",
        "scope": "https://fsc.svom.api"
    }

Then, to use the access token:

::

    header = {"Authorization": "Bearer XXX.YYY.ZZZ"}

ENV/secret:

    * KC_TYPE = "pipeline" -> defines docker secret to use (only inside FSC)
        # pipeline_kc_client_id
        # pipeline_kc_client_secret

    (outside FSC -> locally, docker secret not set, not available)
    * KC_USERNAME -> username
    * KC_PASSWORD -> password
    * KC_CLIENT_ID -> public kc client_id

"""
import os
import time
import json
import logging
import asyncio
import base64
import requests
import aiohttp

import attrs

from get_docker_secret import get_docker_secret

log = logging.getLogger("tokens")

AUTH_TENANT = "admin.svom.eu/keycloak/realms/svom-fsc"
AUTH_TOKEN_ENDPOINT = "/protocol/openid-connect/token"
AUTH_URL = f"https://{AUTH_TENANT}{AUTH_TOKEN_ENDPOINT}"
AUTH_HEADER = {"Content-Type": "application/x-www-form-urlencoded"}

ENV_GLOBAL_TOKENS = "BRICKS_KC_TOKENS"
ENV_GLOBAL_TOKENS_BASE64 = "BRICKS_KC_TOKENS64"


# delay computation function, copy from svom.messaging.ttpio to avoid circular import.
def power_delay(try_num, backoff_factor=1):
    """Calculate delay in seconds as a power law

    Parameters
    ----------
    try_num : int
        Connection attempt number
    backoff_factor : int, optional
        Default 1.
    Returns
    -------
    delay : int
        delay before reconnection in seconds.
    """
    delay = backoff_factor * (2 ** (try_num - 1))
    return delay


@attrs.define
class Tokens:
    """Tokens are objects returned by a Keycloak request for access tokens."""

    access_token: str
    expires_in: int
    refresh_expires_in: int
    refresh_token: str
    token_type: str
    not_before_policy: int
    session_state: str
    scope: str

    @classmethod
    def from_dict(cls, my_dict) -> "Tokens":
        """Instanciate from svom.messaging.ictionnary.

        Parameters
        ----------
        my_dict : dict
            Dictionnary for initializing the class Tokens. Should contains the
            following key : access_token, expires_in, refresh_expires_in, refresh_token
            token_type, not-before-policy, session_state and scope.
        """
        return cls(
            my_dict.get("access_token", ""),
            my_dict.get("expires_in", 0),
            my_dict.get("refresh_expires_in", 0),
            my_dict.get("refresh_token", ""),
            my_dict.get("token_type", ""),
            my_dict.get("not-before-policy", 0),
            my_dict.get("session_state", ""),
            my_dict.get("scope", ""),
        )


@attrs.define
class TokensExpirations:
    """Class to register the tokens expirations when requesting or refreshing one."""

    expires_at: int
    refresh_expires_at: int
    expires_at_threshold: int

    @classmethod
    def from_tokens(cls, tokens, expires_at_threshold=10, timestamp=None) -> None:
        """Instanciate from svom.messaging.okens after request

        Parameters
        ----------
        tokens : dict
            access token for Keycloack authorization.
        expires_at_threshold : int, optional
            Security threshold to update the token before its expiration, in seconds.
        timestamp : int, optional
            Time at which the token is received.
        """
        timestamp = time.time() if timestamp is None else timestamp
        return cls(
            timestamp + tokens.expires_in - expires_at_threshold,
            timestamp + tokens.refresh_expires_in - expires_at_threshold,
            expires_at_threshold,
        )

    @classmethod
    def from_dict(cls, my_dict):
        """Instanciate from svom.messaging.ictionnary.

        Parameters
        ----------
        my_dict : dict
            Dictionnary for initializing the class Tokens. Should contains the
            following key : expires_at, refresh_expires_at, expires_at_threshold.
        """
        return cls(
            my_dict.get("expires_at", 0),
            my_dict.get("refresh_expires_at", 0),
            my_dict.get("expires_at_threshold", 10),
        )

    def access_is_expired(self) -> bool:
        """Return True if access token is expired"""
        return time.time() > self.expires_at

    def refresh_is_expired(self) -> bool:
        """Return True if refresh token is expired"""
        return time.time() > self.refresh_expires_at


@attrs.define
class TokensWithExpirationsDates:
    """To gather tokens and their expirations date if provided by external clients.

    The timestamp for expirations dates must be set when fetching the
    tokens, not after."""

    tokens: Tokens
    expirations: TokensExpirations

    @classmethod
    def from_dict(cls, my_dict):
        """Instanciate from svom.messaging.ict

        Parameters
        ----------
        my_dict : dict
            Dictionnary for initializing the class Tokens. Should contains the
            following key : tokens, expirations.
        """
        return cls(
            Tokens.from_dict(my_dict.get("tokens", {})),
            TokensExpirations.from_dict(my_dict.get("expirations", {})),
        )

    @classmethod
    def from_dict_resp(cls, my_dict, expires_at_threshold=10, timestamp=None):
        """Instanciate from svom.messaging.equest json response (dict)

        Parameters
        ----------
        my_dict : dict
            Dictionnary for initializing the class Tokens. Should contains the
            following key : tokens, expirations.
        expires_at_threshold : int, optional
            Security threshold to update the token before its expiration, in seconds.
        timestamp : int, optional
            Time at which the token is received.
        """
        tokens = Tokens.from_dict(my_dict)
        return cls(
            tokens,
            TokensExpirations.from_tokens(tokens, expires_at_threshold, timestamp),
        )

    def access_is_expired(self):
        """To check that inner access token is expired"""
        return self.expirations.access_is_expired()

    def refresh_is_expired(self):
        """To check that inner refresh token is expired"""
        return self.expirations.refresh_is_expired()


@attrs.define
class RetryParams:
    """RetryParams class to gather fields to manage request session"""

    max_tries: int
    backoff_factor: int


@attrs.define
class ClientCredentialsPayload:
    """in terms of OAuth2.

    The Client Credentials grant type is used by clients to obtain an access token
    outside of the context of a user.

    This is typically used by clients to access resources about
    themselves rather than to access a user's resources.
    """

    client_id: str
    client_secret: str
    scope: str = "https://fsc.svom.api"
    grant_type: str = "client_credentials"

    @classmethod
    def from_config(cls, config) -> "ClientCredentialsPayload":
        """Instanciate from svom.messaging.onfig"""
        return cls(config.client_id, config.client_secret)


@attrs.define
class ResourceOwnerPasswordCredentialsPayload:
    """in terms of OAuth2.

    The resource owner password credentials grant workflow allows for the exchanging
    of the user name and password of a user for an access token.

    When using the resource owner password credentials grant, the user provides the credentials
    (user name and password) directly to the application.
    The application then uses the credentials to obtain an access token from svom.messaging.he service.
    """

    client_id: str
    username: str
    password: str
    scope: str = "https://fsc.svom.api"
    grant_type: str = "password"

    @classmethod
    def from_config(cls, config) -> "ResourceOwnerPasswordCredentialsPayload":
        """Instanciate from svom.messaging.onfig"""
        return cls(config.client_id, config.username, config.password)


@attrs.define
class RefreshPayload:
    """A RefreshPayload instance is used when refreshing a token to Keycloak."""

    client_id: str
    refresh_token: str
    grant_type: str = "refresh_token"

    @classmethod
    def from_config_tokens(cls, config, tokens) -> "RefreshPayload":
        """Instanciate from svom.messaging.onfig and tokens (to get the refresh token)"""
        return cls(config.client_id, tokens.refresh_token)


@attrs.define
class Payload:
    """Abstract ?"""

    @classmethod
    def from_config(cls, config):
        """Instanciate from svom.messaging.onfig"""
        if config.username:
            return ResourceOwnerPasswordCredentialsPayload.from_config(config)

        return ClientCredentialsPayload.from_config(config)


@attrs.define
class Config:
    """This class stores all params used in keycloak token requests payloads."""

    client_id: str
    client_secret: str
    username: str
    password: str

    @classmethod
    def from_env(cls) -> "Config":
        """Depending on env var, create a payload to be POSTed to keycloak server, to get tokens.

        ENV:

            * KC_TYPE: "pipeline", "ic"
                -> retrieve docker secrets associated with client_id/client_secret
            * KC_CLIENT_ID
                -> outside fsc, public keycloak client id, dedicated to authenticate users
            * KC_USERNAME
                -> mandatory with KC_CLIENT_ID
            * KC_PASSWORD
                -> mandatory with KC_CLIENT_ID

        At least KC_TYPE or KC_CLIENT_ID must be set! If both, KC_CLIENT_ID is highest priority.

        Inside FSC, in a docker compose, only KC_TYPE should be set.

        To use client_id/client_secret outside of container, just set the corresponding
        environment:

        ::

            export KC_TYPE="whatever"
            export WHATEVER_KC_CLIENT_ID="my_client_id"
            export WHATEVER_KC_CLIENT_SECRET="zeS3crE!"

        """
        env_kc_type = os.environ.get("KC_TYPE")
        log.info("    -- kc_type: %s", env_kc_type)

        env_kc_client_id = os.environ.get("KC_CLIENT_ID")
        log.info("    -- kc_client_id: %s", env_kc_client_id)

        if not env_kc_type and not env_kc_client_id:
            log.error("You must at least set one of env: KC_TYPE, KC_CLIENT_ID.")
            raise ValueError

        env_kc_client_secret = None
        env_kc_username = None
        env_kc_password = None

        if env_kc_client_id:
            env_kc_username = os.environ.get("KC_USERNAME")
            log.info("    -- kc_username: %s", env_kc_username)

            env_kc_password = os.environ.get("KC_PASSWORD")
            log.info("    -- kc_password: set")

            if not env_kc_password:
                log.error("Missing password for username %s", env_kc_username)
                raise ValueError
        else:
            kc_client_id_dockname = f"{env_kc_type.lower()}_kc_client_id"
            kc_client_secret_dockname = f"{env_kc_type.lower()}_kc_client_secret"

            env_kc_client_id = get_docker_secret(kc_client_id_dockname)
            if not env_kc_client_id:
                log.warning(
                    "    -- Secret: '%s' appears to be empty. "
                    "Remember to add the secret to your docker-compose file",
                    kc_client_id_dockname,
                )

            env_kc_client_secret = get_docker_secret(kc_client_secret_dockname)
            if not env_kc_client_secret:
                log.warning(
                    "    -- Secret: '%s' appears to be empty. "
                    "Remember to add the secret to your docker-compose file",
                    kc_client_secret_dockname,
                )

        return cls(env_kc_client_id, env_kc_client_secret, env_kc_username, env_kc_password)


class KcTokens:
    """A class to request users/app tokens from svom.messaging.eycloak auth server. An access token expires
    after a validity time. Meanwhile, no new requests are made to Keycloak.

    * if env var are not properly set, __init__ will raise ValueError.
    *| if tokens requests fail -> format_header returns {}, else {"Authorization":
     | "Bearer XXX.YYY.ZZZ"}
    * if tokens are passed in init, these tokens will be used instead of requesting keycloak, except
    * if the tokens is not valid anymore.
    """

    def __init__(
        self,
        max_tries=2,
        backoff_factor=1,
        expires_at_threshold=10,
        loop=None,
        tokens=None,
    ):
        """The init method"""
        # we want config ok even if tokens are not None, to be able to fetch tokens if expired
        self.config = Config.from_env()
        self.retry_params = RetryParams(max_tries, backoff_factor)
        self.expires_at_threshold = expires_at_threshold

        if tokens is None:
            self.tokens_with_expirations_dates = None
        else:
            import pdb

            pdb.set_trace()
            assert isinstance(tokens, TokensWithExpirationsDates)
            self.tokens_with_expirations_dates = tokens

        global_tokens = os.environ.get(ENV_GLOBAL_TOKENS)

        if global_tokens:
            self.tokens_with_expirations_dates = TokensWithExpirationsDates.from_dict(
                json.loads(global_tokens)
            )

        global_tokens_b64 = os.environ.get(ENV_GLOBAL_TOKENS_BASE64)
        if global_tokens_b64:
            self.tokens_with_expirations_dates = TokensWithExpirationsDates.from_dict(
                # Removes '"' from svom.messaging.b'...'" string (boo!)
                json.loads(base64.b64decode(global_tokens_b64[1:-1]).decode()),
            )

        self.loop = loop

    def access_is_expired(self):
        """Calls tokens_expirations access is expired -> True if so"""
        return self.tokens_with_expirations_dates.access_is_expired()

    def refresh_is_expired(self):
        """Calls tokens_expirations refresh is expired -> True if so"""
        return self.tokens_with_expirations_dates.refresh_is_expired()

    def _request_tokens(
        self,
    ):
        """POST request to keycloak server to get back the tokens."""
        log.info(" -- Auth: get access token")

        # Request to get an access token
        tried = 0
        response = None
        while tried < self.retry_params.max_tries:
            tried += 1
            response = requests.post(
                AUTH_URL,
                data=attrs.asdict(Payload.from_config(self.config)),
                headers=AUTH_HEADER,
            )

            if response.status_code == 200:
                break

            if tried >= self.retry_params.max_tries:
                log.warning(" -- Auth: -- status: %s", response.status_code)
                log.error(
                    " -- Auth: -- max tries exceeded (%s) with: %s",
                    self.retry_params.max_tries,
                    response.text,
                )
                log.error(" -- Auth: -- failing to get tokens, aborting!")
                break

            delay = power_delay(tried, self.retry_params.backoff_factor)
            log.warning(
                " -- Auth: -- failed: %s. Trying again in %ss",
                response.status_code,
                delay,
            )
            time.sleep(delay)
        try:
            self.tokens_with_expirations_dates = TokensWithExpirationsDates.from_dict_resp(
                response.json(), self.expires_at_threshold
            )

        except Exception as err:
            log.error(" -- Auth: error to get json response: %s", err)

    async def _async_request_tokens(
        self,
    ):
        """Async POST request to keycloak server for tokens."""
        log.info(" -- Auth: get access token (async)")
        tried = 0
        response = None
        json_resp = None

        async with aiohttp.ClientSession(headers=AUTH_HEADER, loop=self.loop) as session:
            while tried < self.retry_params.max_tries:
                tried += 1
                try:
                    response = await session.post(
                        AUTH_URL, data=attrs.asdict(Payload.from_config(self.config))
                    )

                    try:
                        json_resp = await response.json()
                    except Exception:
                        log.exception("Exception caught json_resp")

                    if response.status == 200:
                        break

                    if tried >= self.retry_params.max_tries:
                        log.warning(" -- Auth (async): -- status: %s", response.status)
                        log.error(
                            " -- Auth (async): -- max tries exceeded (%s) with: %s",
                            self.retry_params.max_tries,
                            await response.text(),
                        )
                        log.error(" -- Auth (async): -- failing to get tokens, aborting!")
                        break

                    delay = power_delay(tried, self.retry_params.backoff_factor)
                    log.warning(
                        " -- Auth (async): -- failed: %s. Trying again in %ss",
                        response.status,
                        delay,
                    )

                    await asyncio.sleep(delay)

                except Exception as exc:
                    log.error("Exception caught: %s", exc)

        if json_resp is not None:
            self.tokens_with_expirations_dates = TokensWithExpirationsDates.from_dict_resp(
                json_resp, self.expires_at_threshold
            )

    def _refresh_tokens(
        self,
    ):
        """Refresh the access token using the refresh token.

        Refresh token is only exchanged with authorization server.
        https://stackoverflow.com/questions/38986005/what-is-the-purpose-of-a-refresh-token
        """
        log.info(" -- Auth: refresh access token")

        # Request to refresh an access token
        tried = 0
        response = None
        while tried < self.retry_params.max_tries:
            tried += 1
            response = requests.post(
                AUTH_URL,
                data=attrs.asdict(
                    RefreshPayload.from_config_tokens(
                        self.config, self.tokens_with_expirations_dates.tokens
                    )
                ),
                headers=AUTH_HEADER,
            )

            if response.status_code == 200:
                break

            if tried >= self.retry_params.max_tries:
                log.warning(" -- Auth: -- [refresh] status: %s", response.status_code)
                log.error(
                    " -- Auth: -- [refresh] max tries exceeded (%s) with: %s",
                    self.retry_params.max_tries,
                    response.text,
                )
                log.error(" -- Auth: -- [refresh] failing to get tokens, aborting!")
                break

            delay = power_delay(tried, self.retry_params.backoff_factor)
            log.warning(
                " -- Auth: -- [refresh] failed: %s. Trying again in %ss",
                response.status_code,
                delay,
            )
            time.sleep(delay)

        try:
            self.tokens_with_expirations_dates = TokensWithExpirationsDates.from_dict_resp(
                response.json(), self.expires_at_threshold
            )

        except Exception as err:
            log.error(" -- Auth: [refresh] error to get json response: %s", err)

    async def _async_refresh_tokens(
        self,
    ):
        """Async POST request to keycloak server for tokens."""
        log.info(" -- Auth: [refresh] get access token (async)")
        tried = 0
        response = None
        json_resp = None

        async with aiohttp.ClientSession(headers=AUTH_HEADER, loop=self.loop) as session:
            while tried < self.retry_params.max_tries:
                tried += 1
                try:
                    response = await session.post(
                        AUTH_URL,
                        data=attrs.asdict(
                            RefreshPayload.from_config_tokens(
                                self.config, self.tokens_with_expirations_dates.tokens
                            )
                        ),
                    )

                    try:
                        json_resp = await response.json()
                    except Exception:
                        log.exception("Exception caught json_resp")

                    if response.status == 200:
                        break

                    if tried >= self.retry_params.max_tries:
                        log.warning(
                            " -- Auth (async): -- [refresh] status: %s",
                            response.status,
                        )
                        log.error(
                            " -- Auth (async): -- [refresh] max tries exceeded (%s) with: %s",
                            self.retry_params.max_tries,
                            await response.text(),
                        )
                        log.error(" -- Auth (async): -- [refresh] failing to get tokens, aborting!")
                        break

                    delay = power_delay(tried, self.retry_params.backoff_factor)
                    log.warning(
                        " -- Auth (async): -- [refresh] failed: %s. Trying again in %ss",
                        response.status,
                        delay,
                    )

                    await asyncio.sleep(delay)

                except Exception as exc:
                    log.error("Exception caught: %s", exc)

        if json_resp is not None:
            self.tokens_with_expirations_dates = TokensWithExpirationsDates.from_dict_resp(
                json_resp, self.expires_at_threshold
            )

    def request_or_refresh(self):
        """request or refresh tokens depending on expiration"""

        if self.tokens_with_expirations_dates is not None:
            if self.access_is_expired():
                if not self.refresh_is_expired():
                    # Never true when no refresh token -> refresh_expires_in = 0 in zis caze.
                    self._refresh_tokens()
                else:
                    self._request_tokens()
        else:
            self._request_tokens()

    async def async_request_or_refresh(self):
        """request or refresh tokens depending on expiration"""
        if self.tokens_with_expirations_dates is not None:
            if self.access_is_expired():
                if not self.refresh_is_expired():
                    # Never true when no refresh token -> refresh_expires_in = 0 in zis caze.
                    await self._async_refresh_tokens()
                else:
                    await self._async_request_tokens()
        else:
            await self._async_request_tokens()

    def format_header(
        self,
    ):
        """If tokens, format the Authorization header."""
        header = {}
        if self.tokens_with_expirations_dates:
            header = {
                "Authorization": f"{self.tokens_with_expirations_dates.tokens.token_type} "
                f"{self.tokens_with_expirations_dates.tokens.access_token}"
            }
        else:
            log.warning("-- Auth: no Authorization header set.")

        return header

    def get_authorization_header(
        self,
    ):
        """Request for token if expired, and return the Authorization header."""

        self.request_or_refresh()
        return self.format_header()

    async def async_get_authorization_header(
        self,
    ):
        """Async Request for token if expired, and return the Authorization header."""

        await self.async_request_or_refresh()
        return self.format_header()
