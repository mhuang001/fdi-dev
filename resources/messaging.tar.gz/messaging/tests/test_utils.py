"""
Utils test file
"""
import logging
import os
import sys
import types
from unittest import mock
import pytest

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
import package.svom.messaging.utils as utils

log = logging.getLogger("test_utils")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)


@pytest.fixture(scope="module")
def nats_args():
    """return fake argument parse response"""
    args = {
        "verbose": False,
        "quiet": False,
        "host": "48.15.16.23",
        "port": "42",
        "user": "not_svom",
        "password": "safety_first",
        "streaming": False,
        "cluster": "not_svom-cluster",
        "channels": ["a_channel"],
        "message": "the cake is a lie",
    }
    return args


@pytest.fixture(scope="function")
def mqtt_args():
    """return fake argument parse response"""
    args = {
        "verbose": False,
        "quiet": False,
        "host": "48.15.16.24",
        "port": "44",
        "user": "not_svom",
        "password": "safety_first",
        "clean_session": True,
        "client_id": "test",
        "channels": ["a_channel"],
        "message": "the cake is a lie",
    }
    return args


@pytest.fixture(scope="function")
def stan_args():
    """return fake argument parse response"""
    args = {
        "verbose": False,
        "quiet": False,
        "host": "48.15.16.23",
        "port": "42",
        "user": "not_svom",
        "password": "safety_first",
        "streaming": True,
        "cluster": "not_svom-cluster",
        "channels": ["a_channel"],
        "message": "the cake is a lie",
    }
    return args


@pytest.fixture(scope="function")
def verb_args():
    """return fake argument parse response"""
    args = {"verbose": False, "quiet": False}
    verb_args = types.SimpleNamespace(**args)
    verb_args.verbose = False
    verb_args.quiet = False
    return verb_args


# def test_get_env():  # pylint: disable=redefined-outer-name
#     """test environ default retrieval"""
#     os.environ["EGGS"] = "SPAM"
#     if "BACON" in os.environ:
#         os.environ.pop("BACON")
#     assert utils._get_environ("EGGS", "SAUSAGE") == "SPAM"
#     assert utils._get_environ("BACON", "SAUSAGE") == "SAUSAGE"


def test_nats_env_password(verb_args):  # pylint: disable=redefined-outer-name
    """Test nats env password"""
    os.environ.update(
        {
            "NATS_HOST": "48.15.16.23:42",
            "NATS_USER": "toto",
            "NATS_PASSWORD": "safety_first",
        }
    )
    args_patch = "package.svom.messaging.utils.argparse.ArgumentParser.parse_args"
    secret_patch = "package.svom.messaging.utils.get_docker_secret"
    with mock.patch(args_patch, return_value=verb_args) as args_mock:
        with mock.patch(secret_patch, return_value="Shush!") as secret_mock:
            args = utils.natsargs_from_env()
            assert args.password == "safety_first"
            os.environ["NATS_PWD_SECRET"] = "secret_from_env"
            args = utils.natsargs_from_env()
            assert args.password == "Shush!"
            del os.environ["NATS_PWD_SECRET"]


def test_jetstreamio_from_args(nats_args):  # pylint: disable=redefined-outer-name
    """test jetstreamio init from package.svom.messaging.ommand line arguments"""
    args_patch = "argparse.ArgumentParser.parse_args"
    cmd_args = types.SimpleNamespace(**nats_args)
    with mock.patch(args_patch, return_value=cmd_args) as args_mock:
        with mock.patch(
            "package.svom.messaging.utils.JetStreamIo.__init__", return_value=None
        ) as init_mock:
            utils.jetstreamio_from_args()
            expected_kwargs = {
                "host": nats_args["host"],
                "port": nats_args["port"],
                "user": nats_args["user"],
                "password": nats_args["password"],
            }
            init_mock.assert_called_once()
            assert expected_kwargs.items() <= [*init_mock.mock_calls[0]][2].items()


def test_jetstreamio_from_env(verb_args):  # pylint: disable=redefined-outer-name
    """test jetstreamio init from svom.messaging.nvironment variables"""
    os.environ.update(
        {
            "NATS_HOST": "48.15.16.23:42",
            "NATS_USER": "toto",
            "NATS_PASSWORD": "safety_first",
        }
    )
    args_patch = "argparse.ArgumentParser.parse_args"
    with mock.patch(args_patch, return_value=verb_args) as args_mock:
        with mock.patch(
            "package.svom.messaging.utils.JetStreamIo.__init__", return_value=None
        ) as init_mock:
            utils.jetstreamio_from_env()
            init_mock.assert_called_once()
            expected_kwargs = {
                "host": "48.15.16.23",
                "port": "42",
                "user": "toto",
                "password": "safety_first",
            }
            assert expected_kwargs.items() <= [*init_mock.mock_calls[0]][2].items()


def test_jetstreamio_from_env_with_opts(
    verb_args,
):  # pylint: disable=redefined-outer-name
    """test jetstreamio init from svom.messaging.nvironment variables"""
    os.environ.update(
        {
            "NATS_HOST": "48.15.16.23:42",
            "NATS_USER": "toto",
            "NATS_PASSWORD": "safety_first",
        }
    )
    args_patch = "argparse.ArgumentParser.parse_args"
    with mock.patch(args_patch, return_value=verb_args) as args_mock:
        with mock.patch(
            "package.svom.messaging.utils.JetStreamIo.__init__", return_value=None
        ) as init_mock:
            utils.jetstreamio_from_env(
                streaming_id="THIS_IS_ID", max_reconnect_attempts=42
            )
            init_mock.assert_called_once()
            expected_kwargs = {
                "host": "48.15.16.23",
                "port": "42",
                "user": "toto",
                "password": "safety_first",
                "streaming_id": "THIS_IS_ID",
                "max_reconnect_attempts": 42,
            }
            assert expected_kwargs.items() <= [*init_mock.mock_calls[0]][2].items()


def test_mqtt_from_args(mqtt_args):  # pylint: disable=redefined-outer-name
    """test jetstreamio init from svom.messaging.ommand line arguments"""
    args_patch = "argparse.ArgumentParser.parse_args"
    cmd_args = types.SimpleNamespace(**mqtt_args)
    with mock.patch(args_patch, return_value=cmd_args) as args_mock:
        with mock.patch(
            "package.svom.messaging.utils.MqttIo.__init__", return_value=None
        ) as init_mock:
            mqtt_client, args = utils.mqttio_from_args()
            expected_kwargs = {
                "host": mqtt_args["host"],
                "port": mqtt_args["port"],
                "user": mqtt_args["user"],
                "password": mqtt_args["password"],
                "client_id": mqtt_args["client_id"],
                "clean_session": mqtt_args["clean_session"],
            }
            init_mock.assert_called_once()
            assert expected_kwargs.items() <= [*init_mock.mock_calls[0]][2].items()
            assert args.clean_session is True
            assert args.client_id == "test"


def test_mqtt_env_password(verb_args):  # pylint: disable=redefined-outer-name
    """Test mqq env password"""
    os.environ.update(
        {
            "MQTT_HOST": "48.15.16.23:42",
            "MQTT_USER": "toto",
            "MQTT_PASSWORD": "safety_first",
        }
    )
    args_patch = "argparse.ArgumentParser.parse_args"
    secret_patch = "package.svom.messaging.utils.get_docker_secret"
    with mock.patch(args_patch, return_value=verb_args) as args_mock:
        with mock.patch(secret_patch, return_value="Shush!") as secret_mock:
            args = utils.mqttargs_from_env()
            assert args.password == "safety_first"
            os.environ["MQTT_PWD_SECRET"] = "secret_from_env"
            args = utils.mqttargs_from_env()
            assert args.password == "Shush!"
            del os.environ["MQTT_PWD_SECRET"]


#
def test_mqtt_from_env(verb_args):  # pylint: disable=redefined-outer-name
    """test jetstreamio init from svom.messaging.nvironment variables"""
    os.environ.update(
        {
            "MQTT_HOST": "48.15.16.23:42",
            "MQTT_USER": "toto",
            "MQTT_PASSWORD": "safety_first",
        }
    )
    args_patch = "argparse.ArgumentParser.parse_args"
    with mock.patch(args_patch, return_value=verb_args) as args_mock:
        with mock.patch(
            "package.svom.messaging.utils.MqttIo.__init__", return_value=None
        ) as init_mock:
            utils.mqttio_from_env()
            init_mock.assert_called_once()
            expected_kwargs = {
                "host": "48.15.16.23",
                "port": "42",
                "user": "toto",
                "password": "safety_first",
                "client_id": None,
                "clean_session": None,
            }
            assert expected_kwargs.items() <= [*init_mock.mock_calls[0]][2].items()
