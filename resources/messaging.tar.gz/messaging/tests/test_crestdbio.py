"""test class CrestDbIo"""
import json
import logging

import types
import os
import sys
from unittest import mock
import pytest
from requests import Response

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
from package.svom.messaging.crestdbio import CrestDbIo

log = logging.getLogger("test_crestdbio")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)

HTTPIO_REQUEST = "package.svom.messaging.httpio.requests.Session.request"


@pytest.fixture
def sync_200_response():
    """mimics 'requests' success response"""
    fake_response = Response()
    fake_response.status_code = 200
    fake_response.json = lambda: {"breakfast": "eggs"}
    return fake_response


@pytest.fixture(scope="module")
def crest_client():
    """return sync VhfDbIos"""
    # with mock.patch('svom.messaging.tokens.KcTokens._request_tokens'):
    sync_client = CrestDbIo("fake://crest/", use_tokens=False)
    yield sync_client


def test_init():
    """Check that the use_tokens param is correctly passed to super()"""

    os.environ["KC_TYPE"] = "pipelines"
    client = CrestDbIo()
    assert client.kc_tokens is not None
    assert client.kc_tokens.tokens_with_expirations_dates is None


def test_tags_search(
    crest_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test CrestDB tags search"""
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Crest-PayloadFormat": "BLOB",
    }
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        crest_client.search_tags(name="SVOM", payloadspec="JSON")
        expected_calls = [
            mock.call(
                "GET",
                "fake://crest/api/tags",
                params={
                    "name": "SVOM",
                    "payloadspec": "JSON",
                    "page": 0,
                    "size": 100,
                    "sort": "name:ASC",
                },
                headers=headers,
            )
        ]
        assert mocked.mock_calls == expected_calls


def test_iovs_search(
    crest_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test CrestDB iovs search"""
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Crest-PayloadFormat": "BLOB",
    }
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        crest_client.search_iovs(
            tagname="SVOM", since="1574429040079", until="1584429040079"
        )
        expected_calls = [
            mock.call(
                "GET",
                "fake://crest/api/iovs",
                params={
                    "tagname": "SVOM",
                    "since": "1574429040079",
                    "until": "1584429040079",
                    "page": 0,
                    "size": 100,
                    "method": "IOVS",
                    "sort": "id.since:ASC",
                },
                headers=headers,
            )
        ]
        assert mocked.mock_calls == expected_calls


def test_create_tags(
    crest_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test CrestDB tag creation"""
    # prepare expected request attributes
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Crest-PayloadFormat": "BLOB",
    }
    json_data = {
        "name": "SVOM",
        "payloadSpec": "JSON",
        "timeType": "time",
        "description": "This is pytest",
        "synchronization": "none",
        "lastValidatedTime": 0,
        "endOfValidity": 0,
        "insertionTime": None,
        "modificationTime": None,
    }
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        crest_client.create_tags(name="SVOM", description="This is pytest")
        expected_calls = [
            mock.call("POST", "fake://crest/api/tags", json=json_data, headers=headers)
        ]
        assert mocked.mock_calls == expected_calls


def test_create_iovs(
    crest_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test CrestDB iov creation"""
    # prepare expected request attributes
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Crest-PayloadFormat": "BLOB",
    }
    json_data = {
        "tagName": "SVOM",
        "since": 1000,
        "payloadHash": "somehash",
        "insertionTime": None,
    }
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        crest_client.create_iovs(name="SVOM", since=1000, phash="somehash")
        expected_calls = [
            mock.call("PUT", "fake://crest/api/iovs", json=json_data, headers=headers)
        ]
        assert mocked.mock_calls == expected_calls


def test_create_iov_set(
    crest_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test CrestDB iov set creation"""
    # prepare expected request attributes
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Crest-PayloadFormat": "BLOB",
    }
    iovset = {
        "size": 1,
        "format": "IovSetDto",
        "resources": [{"since": 1000, "payloadHash": "somehash"}],
    }
    json_data = {
        "size": 1,
        "format": "IovSetDto",
        "resources": [{"since": 1000, "payloadHash": "somehash", "tagName": "SVOM"}],
    }
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        crest_client.create_iov_set(name="SVOM", iovset=iovset)
        expected_calls = [
            mock.call("POST", "fake://crest/api/iovs", json=json_data, headers=headers)
        ]
        assert mocked.mock_calls == expected_calls


def test_create_globaltags(
    crest_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test CrestDB globaltag creation"""
    # prepare expected request attributes
    headers = {
        "Content-Type": "application/json",
        "Accept": "application/json",
        "X-Crest-PayloadFormat": "BLOB",
    }
    json_data = {
        "name": "GT-SVOM",
        "release": "none",
        "type": "T",
        "description": "This is pytest",
        "scenario": "none",
        "validity": 0,
        "workflow": "all",
        "snapshotTime": None,
        "insertionTime": None,
    }
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        crest_client.create_globaltags(name="GT-SVOM", description="This is pytest")
        expected_calls = [
            mock.call(
                "POST", "fake://crest/api/globaltags", json=json_data, headers=headers
            )
        ]
        assert mocked.mock_calls == expected_calls


def test_create_payload(
    crest_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test CrestDB payload creation"""
    # prepare expected request attributes
    tag_name = "SVOM"
    payload_set = {
        "size": 1,
        "format": "StoreSetDto",
        "resources": [
            {
                "hash": "none",
                "data": "some scripts content",
                "since": 10,
                "streamerInfo": '{"info": "some info"}',
            }
        ],
    }
    payload_format = "JSON"
    loc_headers = {"X-Crest-PayloadFormat": payload_format}
    mp_data = [
        ("tag", (None, tag_name)),
        ("storeset", (None, json.dumps(payload_set))),
        ("objectType", (None, "JSON")),
        ("compressionType", (None, "none")),
    ]
    # get to work
    open_mock = mock.mock_open()
    with mock.patch("builtins.open", open_mock):
        if payload_format == "FILE":
            mp_data.append(("files", ("fake_file", open_mock.return_value)))
        with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
            crest_client.create_payload(
                tag_name="SVOM", payloadset=payload_set, payload_format="JSON"
            )
            expected_calls = [
                mock.call(
                    "POST",
                    "fake://crest/api/payloads",
                    files=mp_data,
                    headers=loc_headers,
                )
            ]
            assert mocked.mock_calls == expected_calls


def test_get_payload(
    crest_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test CrestDB payload retrieval"""
    # prepare expected request attributes
    headers = {
        "Content-Type": "application/json",
        "X-Crest-PayloadFormat": "BLOB",
        "Accept": "application/json",
    }
    criteria = {"format": "FILE"}
    # get to work
    open_mock = mock.mock_open()
    with mock.patch("builtins.open", open_mock, create=True):
        with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
            mocked.return_value.raw = types.SimpleNamespace()
            mocked.return_value.raw.stream = lambda x, decode_content: "thisisdata"
            crest_client.get_payload(phash="42", fout="out.blob", fmt="FILE")
            expected_calls = [
                mock.call(
                    "GET",
                    "fake://crest/api/payloads/42",
                    params=criteria,
                    headers=headers,
                )
            ]
            assert mocked.mock_calls == expected_calls
            open_mock.assert_called_with("out.blob", "wb")
            open_mock.return_value.write.assert_called()
