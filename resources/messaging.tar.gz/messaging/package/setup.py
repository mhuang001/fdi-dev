""" 
Setup module for the messaging package.

Configuration is in setup.cfg.
"""
from setuptools import setup

setup()
