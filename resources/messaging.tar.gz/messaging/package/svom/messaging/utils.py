"""
Utility functions to simplfy/uniformize NatsIO setup

Henri Louvin - henri.louvin@cea.fr
"""
# System
import os
import argparse
import getpass

# Logs
import logging

# UUID
import uuid

# docker secrets
from get_docker_secret import get_docker_secret

# NATS
from svom.messaging.jetstreamio import JetStreamIo
from svom.messaging.mqttio import MqttIo

log = logging.getLogger("nats_tools")


def _get_environ(env_var, default_val):
    """
    Retrieves environment variable with fallback to {default_val} and logging.

    Parameters
    ----------
    env_var : str
        Name of the environment variable to retrieve
    default_val : str
        Default value if env_var is not defined.

    Returns
    -------
    value : str
        value extract from svom.messaging.he environment variable and if none the default val.
    """
    value = os.environ.get(env_var)
    if value is None:
        value = default_val
        log.warning(
            "Empty environment variable %s, falling back to default: %s.",
            env_var,
            default_val,
        )
    return value


def _get_default_parser(**kwargs):
    """Default parse argument.

    Parameters
    ----------
    kwargs : dict
        additional parser argument.

    Returns
    -------
    parser : `~argparse.ArgumentParser`
        Default argument parser.
    """
    parser = argparse.ArgumentParser(**kwargs)
    arggroup = parser.add_mutually_exclusive_group()
    arggroup.add_argument("-q", "--quiet", action="store_true", help="Decrease verbosity")
    arggroup.add_argument("-v", "--verbose", action="store_true", help="Increase verbosity")
    return parser


def natsargs_from_env(streaming=False, streaming_id=None, loop=None, **kwargs):
    """Get NATS parameters from svom.messaging.nvironment variables.

    Parameters
    ----------
    streaming : bool
        Define if JetStreamIo adds streaming_id to subject for durable subscription.
    streaming_id : str, optional
        If provided at initialisation, a dedicated JetStream "Consumer" is created
        to make the subscription durable, so that a service with a given `streaming_id` i
        s ensured exactly once delivery of messages. In the event of a disconnection
        from svom.messaging.he server, the missed messages shall be automatically received
        upon reconnexion.
    loop : optional
        asyncio event loop

    Returns
    -------
    args : `~argparse.Namespace`
       containe the parameters for the Client initialisation
    """
    # Set command line options
    argparser = _get_default_parser(description="Svom NATS Monitor.")
    args, unknown = argparser.parse_known_args()
    for unknown_arg in unknown:
        log.warning("Unknown argument %s passed to JetStreamIo", unknown_arg)

    # Set log level
    loglevel = logging.INFO
    if args.verbose:
        loglevel = logging.DEBUG
    elif args.quiet:
        loglevel = logging.WARNING
    logging.getLogger().setLevel(loglevel)
    # remove verbosity from svom.messaging.wargs
    vars(args).pop("verbose")
    vars(args).pop("quiet")

    # Retrieve NATS info from svom.messaging.nvironment variables
    args.host = _get_environ("NATS_HOST", "localhost")

    args.port = _get_environ("NATS_PORT", "4222")
    args.user = _get_environ("NATS_USER", "svom")
    args.password = None
    nats_secret = os.environ.get("NATS_PWD_SECRET")
    if nats_secret is None:
        log.warning("Empty environment variable NATS_PWD_SECRET")
    else:
        try:
            args.password = get_docker_secret(nats_secret, secrets_dir="/run/secrets")
            args.password.strip()
        except Exception as err:
            log.exception("Could not read password from args: %s", nats_secret)
    if args.password is None:
        args.password = os.environ.get("NATS_PASSWORD")
    # Add streaming and streaming ID
    args.streaming = streaming
    args.streaming_id = streaming_id
    # Add loop
    args.loop = loop
    # Add other keyword arguments
    for key, arg in kwargs.items():
        vars(args)[key] = arg
    return args


def natsargs_from_args(streaming_id=None, loop=None, **kwargs):
    """Get NATS parameters from svom.messaging.ommand line

    Parameters
    ----------
    streaming_id : str, optional
        If provided at initialisation, a dedicated JetStream "Consumer" is created
        to make the subscription durable, so that a service with a given `streaming_id` i
        s ensured exactly once delivery of messages. In the event of a disconnection
        from svom.messaging.he server, the missed messages shall be automatically received
        upon reconnexion.
    loop : optional
        asyncio event loop

    Returns
    -------
    args : `~argparse.Namespace`
       containe the parameters for the Client initialisation
    """
    # Parse arguments
    parser = _get_default_parser(description="NATS arguments parser")
    parser.add_argument(
        "--host", default="localhost", help='NATS server host (default "localhost")'
    )
    parser.add_argument("--port", default="4222", help='NATS server port (default "4222")')
    parser.add_argument(
        "--user", default="svom", help="Server authentification user (default None)"
    )
    parser.add_argument(
        "--password",
        default=None,
        help="Server authentification password (default None)",
    )
    parser.add_argument("--streaming", action="store_true", help="Use NATS Streaming")
    parser.add_argument(
        "--channels", default=["test"], nargs="+", help='Channel list (default "test"'
    )
    parser.add_argument(
        "--message",
        "--msg",
        default="i am groot",
        help='Message to publish (default "i am groot")',
    )
    args = parser.parse_args()

    # Set log level
    loglevel = logging.INFO
    if args.verbose:
        loglevel = logging.DEBUG
    elif args.quiet:
        loglevel = logging.WARNING
    logging.getLogger().setLevel(loglevel)

    # remove verbosity from svom.messaging.wargs
    vars(args).pop("verbose")
    vars(args).pop("quiet")

    # Add streaming id
    args.streaming_id = streaming_id
    if streaming_id is not None:
        args.streaming = True

    # Add loop
    args.loop = loop

    # Add other keyword arguments
    for key, arg in kwargs.items():
        vars(args)[key] = arg
    return args


def mqttargs_from_env(client_id=None, clean_session=None, on_message=None, loop=None):
    """Get MqttIO parameters from svom.messaging.nvironment variables

    Parameters
    ----------
    client_id : str, optional
        client_id is the unique client id string used when connecting to the
        broker. If client_id is zero length or None, then the behaviour is
        defined by which protocol version is in use. If using MQTT v3.1.1, then
        a zero length client id will be sent to the broker and the broker will
        generate a random for the client. If using MQTT v3.1 then an id will be
        randomly generated. In both cases, clean_session must be True. If this
        is not the case a ValueError will be raised. See Paho mqtt client package doc.
    clean_session : str, optional
        clean_session is a boolean that determines the client type. If True,
        the broker will remove all information about this client when it
        disconnects. If False, the client is a persistent client and
        subscription information and queued messages will be retained when the
        client disconnects.
        Note that a client will never discard its own outgoing messages on
        disconnect. Calling connect() or reconnect() will cause the messages to
        be resent.  Use reinitialise() to reset a client to its original state.
        The clean_session argument only applies to MQTT versions v3.1.1 and v3.1.
        It is not accepted if the MQTT version is v5.0 - use the clean_start
        argument on connect() instead. See Paho mqtt client package doc.
    on_message : callback function, optional
        Define the default message received  when subsriscriptsg to a topic. Should
        have the following signature on_message_callback(client, userdata, message).
    loop : optional
        asyncio event loop

    Returns
    -------
    args : `~argparse.Namespace`
       containe the parameters for the Client initialisation
    """
    # Set command line options
    argparser = _get_default_parser(description="Svom Mqtt Monitor.")
    args, unknown = argparser.parse_known_args()
    for unknown_arg in unknown:
        log.warning("Unknown argument %s passed to NatsIo", unknown_arg)

    # Set log level
    loglevel = logging.INFO
    if args.verbose:
        loglevel = logging.DEBUG
    elif args.quiet:
        loglevel = logging.WARNING
    logging.getLogger().setLevel(loglevel)

    # Retrieve Mqtt info from svom.messaging.nvironment variables
    args.host = _get_environ("MQTT_HOST", "localhost")
    args.port = _get_environ("MQTT_PORT", "4222")
    args.user = _get_environ("MQTT_USER", "svom")
    args.password = None
    mqtt_secret = os.environ.get("MQTT_PWD_SECRET")
    if mqtt_secret is None:
        log.warning("Empty environment variable MQTT_PWD_SECRET")
    else:
        try:
            args.password = get_docker_secret(mqtt_secret, secrets_dir="/run/secrets")
            args.password.strip()
        except Exception as err:
            log.exception("Could not read password from args: %s", mqtt_secret)
    if args.password is None:
        args.password = os.environ.get("MQTT_PASSWORD")

    args.client_id = client_id
    args.clean_session = clean_session

    # Add on_message call back
    args.on_message = on_message
    # Add loop
    args.loop = loop
    return args


def mqttargs_from_args(client_id=None, clean_session=None, on_message=None, loop=None):
    """Get MQTTIO parameters from svom.messaging.ommand line

    Parameters
    ----------
    client_id : str, optional
        client_id is the unique client id string used when connecting to the
        broker. If client_id is zero length or None, then the behaviour is
        defined by which protocol version is in use. If using MQTT v3.1.1, then
        a zero length client id will be sent to the broker and the broker will
        generate a random for the client. If using MQTT v3.1 then an id will be
        randomly generated. In both cases, clean_session must be True. If this
        is not the case a ValueError will be raised. See Paho mqtt client package doc.
    clean_session : str, optional
        clean_session is a boolean that determines the client type. If True,
        the broker will remove all information about this client when it
        disconnects. If False, the client is a persistent client and
        subscription information and queued messages will be retained when the
        client disconnects.
        Note that a client will never discard its own outgoing messages on
        disconnect. Calling connect() or reconnect() will cause the messages to
        be resent.  Use reinitialise() to reset a client to its original state.
        The clean_session argument only applies to MQTT versions v3.1.1 and v3.1.
        It is not accepted if the MQTT version is v5.0 - use the clean_start
        argument on connect() instead. See Paho mqtt client package doc.
    on_message : callback function, optional
        Define the default message received  when subsriscriptsg to a topic. Should
        have the following signature on_message_callback(client, userdata, message).
    loop : optional
        asyncio event loop

    Returns
    -------
    args : `~argparse.Namespace`
       containe the parameters for the Client initialisation
    """
    # Parse arguments
    parser = _get_default_parser(description="MQTTIO arguments parser")
    parser.add_argument(
        "--host", default="localhost", help='MQTT server host (default "localhost")'
    )
    parser.add_argument("--port", default="4222", help='MQTT server port (default "4222")')
    parser.add_argument(
        "--user", default="svom", help="Server authentification user (default None)"
    )
    parser.add_argument(
        "--password",
        default=None,
        help="Server authentification password (default None)",
    )
    parser.add_argument(
        "--client_id",
        default=None,
        help="client id string used when connecting to the broker",
    )
    parser.add_argument(
        "--clean_session",
        default=None,
        help="clean_session is a boolean that determines the client type",
    )
    parser.add_argument(
        "--channels", default=["test"], nargs="+", help='Channel list (default "test"'
    )
    parser.add_argument(
        "--message",
        "--msg",
        default="i am groot",
        help='Message to publish (default "i am groot")',
    )
    args = parser.parse_args()
    # Set log level
    loglevel = logging.INFO
    if args.verbose:
        loglevel = logging.DEBUG
    elif args.quiet:
        loglevel = logging.WARNING
    logging.getLogger().setLevel(loglevel)

    if args.client_id is None:
        args.client_id = client_id
    if args.clean_session is None:
        args.clean_session = clean_session

    # Add on_message call back
    args.on_message = on_message
    # Add loop
    args.loop = loop

    return args


def _jetstreamio_from_args(args):
    """Checks host:port and instantiate JetStreamIo

    Parameters
    ----------
    args : `~argparse.Namespace`
       Namespace containing the parameters for the Client initialisation

    Returns
    -------
    nats_client : `~src.JetStreamIo`
        JetStreamIo client
    """
    # Check if port was passed in host
    if "," not in args.host:
        if args.host.startswith("http"):
            args.host = args.host.split("://")[1]
        if ":" in args.host:
            args.host, args.port = args.host.split(":")

    # Prompt for password if not found yet
    if args.password is None:
        prompt = f"Password for {args.user} on nats://{args.host}:{args.port}? "
        args.password = getpass.getpass(prompt=prompt)

    init_args = vars(args).copy()
    if "channels" in init_args.keys():
        init_args.pop("channels")
    if "message" in init_args.keys():
        init_args.pop("message")
    # Connect to NATS server
    if args.streaming is False:
        # Remove NATS streaming specific keywords
        init_args.pop("streaming")
        # init client
        nats_client = JetStreamIo(**init_args)
    else:
        if args.streaming_id is None:
            args.streaming_id = f"test-{uuid.uuid4()}"
        # Remove NATS streaming specific keywords
        init_args.pop("streaming")
        # init client
        nats_client = JetStreamIo(**init_args)

    return nats_client


def jetstreamio_from_env(streaming=False, streaming_id=None, loop=None, **kwargs):
    """Setup NATS client from svom.messaging.nvironment variables

    Parameters
    ----------
    streaming : bool
        Define if JetStreamIo adds streaming_id to subject for durable subscription.
    streaming_id : str, optional
        If provided at initialisation, a dedicated JetStream "Consumer" is created
        to make the subscription durable, so that a service with a given `streaming_id` i
        s ensured exactly once delivery of messages. In the event of a disconnection
        from svom.messaging.he server, the missed messages shall be automatically received
        upon reconnexion.
    loop : optional
        asyncio event loop

    Returns
    -------
    nats_client : `~src.JetSteamIo`
        NATS client
    """
    # Get args
    args = natsargs_from_env(streaming=streaming, streaming_id=streaming_id, loop=loop, **kwargs)
    nats_client = _jetstreamio_from_args(args)
    # Setup client
    return nats_client


def jetstreamio_from_args(streaming_id=None, loop=None, **kwargs):
    """Setup NATS client from svom.messaging.ommand line arguments.

    Parameters
    ----------
    streaming_id : str, optional
        If provided at initialisation, a dedicated JetStream "Consumer" is created
        to make the subscription durable, so that a service with a given `streaming_id` i
        s ensured exactly once delivery of messages. In the event of a disconnection
        from svom.messaging.he server, the missed messages shall be automatically received
        upon reconnexion.
    loop : optional
        asyncio event loop

    Returns
    -------
    nats_client : `~src.JetSteamIo`
        NATS client
    args : `~argparse.Namespace`
       Namespace containing the parameters for the Client initialisation
    """
    # Get args
    args = natsargs_from_args(streaming_id=streaming_id, loop=loop, **kwargs)
    nats_client = _jetstreamio_from_args(args)
    # Setup client
    return nats_client, args


def _mqttio_from_args(args):
    """
     Checks host:port and instantiate MqttIo client from svom.messaging.rgs

    Parameters
    ----------
    args : `~argparse.Namespace`
       Namespace containing the parameters for the Client initialisation

    Returns
    -------
    mqtt_client : `~src.MqttIo`
        MqttIo client
    """
    # Check if port was passed in host
    if args.host.startswith("http"):
        args.host = args.host.split("://")[1]
    if ":" in args.host:
        args.host, args.port = args.host.split(":")

    # Prompt for password if not found yet
    if args.password is None:
        prompt = f"Password for {args.user} on {args.host}:{args.port}? "
        args.password = getpass.getpass(prompt=prompt)

    mqtt_client = MqttIo(
        host=args.host,
        port=args.port,
        user=args.user,
        password=args.password,
        clean_session=args.clean_session,
        client_id=args.client_id,
        on_message=args.on_message,
        loop=args.loop,
    )

    return mqtt_client


def mqttio_from_env(client_id=None, clean_session=None, on_message=None, loop=None):
    """Setup MQTT client from svom.messaging.ommand line arguments

    Parameters
    ----------
    client_id : str, optional
        client_id is the unique client id string used when connecting to the
        broker. If client_id is zero length or None, then the behaviour is
        defined by which protocol version is in use. If using MQTT v3.1.1, then
        a zero length client id will be sent to the broker and the broker will
        generate a random for the client. If using MQTT v3.1 then an id will be
        randomly generated. In both cases, clean_session must be True. If this
        is not the case a ValueError will be raised. See Paho mqtt client package doc.
    clean_session : str, optional
        clean_session is a boolean that determines the client type. If True,
        the broker will remove all information about this client when it
        disconnects. If False, the client is a persistent client and
        subscription information and queued messages will be retained when the
        client disconnects.
        Note that a client will never discard its own outgoing messages on
        disconnect. Calling connect() or reconnect() will cause the messages to
        be resent.  Use reinitialise() to reset a client to its original state.
        The clean_session argument only applies to MQTT versions v3.1.1 and v3.1.
        It is not accepted if the MQTT version is v5.0 - use the clean_start
        argument on connect() instead. See Paho mqtt client package doc.
    on_message : callback function, optional
        Define the default message received  when subsriscriptsg to a topic. Should
        have the following signature on_message_callback(client, userdata, message).
    loop : optional
        asyncio event loop

    Returns
    -------
    mqttio_client : `~src.MqttIo`
        MqttIo client
    """
    # Get args
    args = mqttargs_from_env(
        client_id=client_id,
        clean_session=clean_session,
        on_message=on_message,
        loop=loop,
    )
    mqttio_client = _mqttio_from_args(args)
    # Setup client
    return mqttio_client


def mqttio_from_args(client_id=None, clean_session=None, on_message=None, loop=None):
    """Setup MQTT client from svom.messaging.ommand line arguments

    Parameters
    ----------
    client_id : str, optional
        client_id is the unique client id string used when connecting to the
        broker. If client_id is zero length or None, then the behaviour is
        defined by which protocol version is in use. If using MQTT v3.1.1, then
        a zero length client id will be sent to the broker and the broker will
        generate a random for the client. If using MQTT v3.1 then an id will be
        randomly generated. In both cases, clean_session must be True. If this
        is not the case a ValueError will be raised. See Paho mqtt client package doc.
    clean_session : str, optional
        clean_session is a boolean that determines the client type. If True,
        the broker will remove all information about this client when it
        disconnects. If False, the client is a persistent client and
        subscription information and queued messages will be retained when the
        client disconnects.
        Note that a client will never discard its own outgoing messages on
        disconnect. Calling connect() or reconnect() will cause the messages to
        be resent.  Use reinitialise() to reset a client to its original state.
        The clean_session argument only applies to MQTT versions v3.1.1 and v3.1.
        It is not accepted if the MQTT version is v5.0 - use the clean_start
        argument on connect() instead. See Paho mqtt client package doc.
    on_message : callback function, optional
        Define the default message received  when subsriscriptsg to a topic. Should
        have the following signature on_message_callback(client, userdata, message).
    loop : optional
        asyncio event loop

    Returns
    -------
    mqttio_client : `~src.MqttIo`
        MqttIo client
    args : `~argparse.Namespace`
       Namespace containing the parameters for the Client initialisation
    """
    # Get args
    args = mqttargs_from_args(
        client_id=client_id,
        clean_session=clean_session,
        on_message=on_message,
        loop=loop,
    )
    mqttio_client = _mqttio_from_args(args)

    # Setup client
    return mqttio_client, args


def get_vhfdb_url(server_url):
    """Return VHF-DB url overriden by env variables:

        * WITHIN FSCNET: "http://vhfmgr_service:8080"
        * OUT OF FSCNET: "https://fsc.svom.org/vhfdb"

    Parameters
    ----------
    server_url : str
        default url if the environment variable VHFDB_SERVER_URL is not defined.

    Returns
    -------
    server_url : str
        URL extract from svom.messaging.he environement variable if it exists. If not take the
        default given in the server_url argument.
    """
    server_url = _get_environ("VHFDB_SERVER_URL", server_url)
    return server_url


def get_xbanddb_urls(server_url_l0c, server_url_packets):
    """Return XBAND-DB url overriden by env variables:

        * WITHIN FSCNET: "http://xbsvc_lc:8080", "http://xbsvc_packets:8080"
        * OUT OF FSCNET: "https://fsc.svom.org/xbsvc_lc", "https://fsc.svom.org/xbsvc_packets/"

    Parameters
    ----------
    server_url_l0c : str
        default url if the environment variable XBANDDB_L0C_URL is not defined.
    server_url_packets : str
        default url if the environment variable XBANDDB_PACKETS_URL is not defined.

    Returns
    -------
    server_url_l0c, server_url_packets : str
        URL extract from svom.messaging.he environement variable if it exists. If not take the
        default given in the server_url argument.
    """
    server_url_l0c = _get_environ("XBANDDB_L0C_URL", server_url_l0c)
    server_url_packets = _get_environ("XBANDDB_PACKETS_URL", server_url_packets)
    return server_url_l0c, server_url_packets


def get_auxhk_url(server_url):
    """Return Aux HK url overriden by env variables:

        * WITHIN FSCNET: "http://auxhkmgr_service:8080"
        * OUT OF FSCNET: "https://fsc.svom.org/auxhkmgr"

    Parameters
    ----------
    server_url : str
        default url if the environment variable AUXHKDB_SERVER_URL is not defined.

    Returns
    -------
    server_url : str
        URL extract from svom.messaging.he environement variable if it exists. If not take the
        default given in the server_url argument.
    """
    server_url = _get_environ("AUXHKDB_SERVER_URL", server_url)
    return server_url


def get_crestdb_url(server_url):
    """Return Crest-DB url overriden by env variables:

        * WITHIN FSCNET: "http://crest_service:8080"
        * OUT OF FSCNET: "https://fsc.svom.org/crestdb"

    Parameters
    ----------
    server_url : str
        default url if the environment variable CRESTDB_SERVER_URL is not defined.

    Returns
    -------
    server_url : str
        URL extract from svom.messaging.he environement variable if it exists. If not take the
        default given in the server_url argument.
    """
    server_url = _get_environ("CRESTDB_SERVER_URL", server_url)
    return server_url


def get_sdb_urls(import_url, export_url):
    """Return SDB urls overriden by env variables:

        * WITHIN FSCNET: "http://sdb_api-import", "http://sdb_proxy"
        * OUT OF FSCNET: "https://proxy.svom.org/sdb-import" "https://proxy.svom.org/sdb"

    Parameters
    ----------
    import_url : str
        default url if the environment variable SDB_IMPORT_URL is not defined.
    export_url : str
        default url if the environment variable SDB_EXPORT_URL is not defined.

    Returns
    -------
    import_url, export_url : str
        URL extract from svom.messaging.he environement variable if it exists. If not take the
        default given in the server_url argument.
    """
    import_url = _get_environ("SDB_IMPORT_URL", import_url)
    export_url = _get_environ("SDB_EXPORT_URL", export_url)
    return import_url, export_url


def get_caldb_url(server_url):
    """Return Crest-DB url overriden by env variables:

        * WITHIN FSCNET: "http://caldb_caldb:5000"
        * OUT OF FSCNET: "https://fsc.svom.eu/caldb/"

    Parameters
    ----------
    server_url : str
        default url if the environment variable CALDB_SERVER_URL is not defined.

    Returns
    -------
    server_url : str
        URL extract from svom.messaging.he environement variable if it exists. If not take the
        default given in the server_url argument.
    """
    server_url = _get_environ("CALDB_SERVER_URL", server_url)
    return server_url


# delay computation function
def power_delay(try_num, backoff_factor=1):
    """Calculate delay in seconds as a power law

    Parameters
    ----------
    try_num : int
        Number of connection attemps
    backoff_factor : int, optional
        Default 1.
    Returns
    -------
    delay : int
        delay before reconnection in seconds.
    """
    delay = backoff_factor * (2 ** (try_num - 1))
    return delay
