#!/bin/bash
##############################################################################
# This script intends to find the modified files within the gitlab CI
# and check whether some files in your documentation folder were modified

# List only names of modified files in the current merge request using git diff

# Author: David Corre, corre@iap.fr
##############################################################################

git fetch origin

# push: trigerred by a push
# merge_request_event: trigerred by a MR
# git diff only on the folder containing the sphinx documentation
if [ $CI_PIPELINE_SOURCE == "push" ]
then
    echo "CI_PIPELINE_SOURCE = push"
    git diff --name-only $CI_COMMIT_BEFORE_SHA $CI_COMMIT_SHA $SPHINX_FOLDER > git_diff.txt
elif [ $CI_PIPELINE_SOURCE == "merge_request_event" ]
then
    echo "CI_PIPELINE_SOURCE = merge_request_event"
    git diff --name-only origin/$CI_MERGE_REQUEST_TARGET_BRANCH_NAME origin/$CI_MERGE_REQUEST_SOURCE_BRANCH_NAME $SPHINX_FOLDER > git_diff.txt
fi

echo " "
echo "Results of git diff: "
cat git_diff.txt
echo " "

