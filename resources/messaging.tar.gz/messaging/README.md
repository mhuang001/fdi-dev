## Svom Messaging

The messaging project manages the tools and configuration for messages transfer with Nats client and Mqtt client. 
The [python module](python) also include multitude of classes with specific methods to simplify the interaction with the different 
databases of the FSC.

To get a complete overview of the project please refer to the [general documentation](https://fsc.svom.org/documentation/messaging/). 
You will find all the details for the [project installation](https://fsc.svom.org/documentation/messaging/installation/index.html).

