"""
Utility functions to simplfy/uniformize NatsIO setup

Lea Jouvin - lea.jouvin@cea.fr
"""
# Logs
import logging

log = logging.getLogger("request_utils")


def kwargs_are_valid(kwargs={}, valid_keys=[]):
    """Check if all keys in {kwargs} dict are in {valid_keys} list"""
    # check request validity
    for key in kwargs:
        if key.lower() not in valid_keys:
            log.error("%s is not in the valid arguments list: %s", key, valid_keys)
            return False
    return True
