fdi package
===========

.. automodule:: fdi
   :members:
   :undoc-members:
   :show-inheritance:

Subpackages
-----------

.. toctree::
   :maxdepth: 4

   fdi.dataset
   fdi.pal
   fdi.pns
   fdi.utils
