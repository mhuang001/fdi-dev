"""
HTTP client tool to exchange with access Svom SDB

Retries requests with power law delays and a max tries limit

@author: henri.louvin@cea.fr
"""

# System
import os
import sys
import urllib
import shutil

# Log
import logging

# Local imports
from svom.messaging.httpio import HttpIo
from svom.messaging.utils import get_sdb_urls

log = logging.getLogger("sdb_client")

# Check availability of astropy
HAS_ASTROPY = True
try:
    from astropy.io import fits
except ImportError:
    HAS_ASTROPY = False


class SdbIo(HttpIo):  # pylint: disable=R0902
    """
    (A)synchronous HTTP client with the Scientifique DataBase (SDB).

    Parameters
    ----------
    import_url :  str, optional
        root server url share by all the endpoints for sdb import.
    export_url :  str, optional
        root server url share by all the endpoints for sdb export.
    max_tries : int, optional
        Number of connection attemps
    asynchronous : bool, optional
        True if asynchronous communication
    loop : optional, optional
        asyncio event loop to use if asynchronous is True. If none, start one.
    use_tokens : bool, optional
        True if Authorization token has to be used
    tokens : dict, optional
        if not None, these tokens will be used instead of requesting keycloak,
        except if the tokens is not valid anymore
    """

    def __init__(
        self,
        import_url="https://fsc.svom.org/sdb-import",
        # pylint: disable=R0913
        export_url="https://fsc.svom.org/sdb",
        max_tries=5,
        asynchronous=False,
        loop=None,
        use_tokens=True,
        tokens=None,
    ):
        import_url, export_url = get_sdb_urls(import_url, export_url)
        super().__init__(
            server_url="",
            max_tries=max_tries,
            asynchronous=asynchronous,
            loop=loop,
            use_tokens=use_tokens,
            tokens=tokens,
        )
        self.search_endpoint = f"{export_url.rstrip('/')}/server/search/products"
        self.raw_search_endpoint = f"{export_url.rstrip('/')}/server/search/l1"
        self.metadata_endpoint = f"{export_url.rstrip('/')}/server/search/sp_cards"
        self.import_endpoint = f"{import_url.rstrip('/')}/v0/add_product"
        self.update_endpoint = f"{import_url.rstrip('/')}/v0/update_product"
        self.has_astropy = HAS_ASTROPY

    def _import_file(self, filename, endpoint):
        """
        Generic file import request.

        Parameters
        ----------
        filename : str
            filename to import
        endpoint : str
            string made of the server_url + endpoint
        """
        # re-implement trying loop to make sure file is re-opened at each attempt
        max_tries_backup = self.max_tries
        self.max_tries = 1
        tried = 0
        while tried < max_tries_backup:
            tried += 1
            # try to import product
            with open(filename, "rb") as fits_file:
                files = {"product": (filename, fits_file)}
                response = self.post(endpoint, files=files)
            # break loop in case of successful import
            if int(response.status_code / 100) in [2, 4]:
                break
        # restore self.max_tries value
        self.max_tries = max_tries_backup
        return response

    def _build_fits_url(self, remote_url):
        """Change base URL to match {self.search_endpoint}

        Parameters
        ----------
        remote_url : str
            fits url
        """
        base_url = self.search_endpoint.split("/server/")[0]
        data_endpoint = remote_url.split("/data/")[1]
        return f"{base_url}/data/{data_endpoint}"

    def _dump_remote_fits_file(self, remote_url, dirname, filename):
        """Open remote fits file at {fits_url} and writes it to {dirname}/{filename}

        Parameters
        ----------
        remote_url : str
            fits url
        dirname : str
            name of the directory where to dowload the fits file
        filename : str
            name of the fits file
        """
        # build downloadable fits URL
        fits_url = self._build_fits_url(remote_url)
        # prepare output
        if filename is None:
            filepath = "-".join(fits_url.split("/")[-2:])
        else:
            filepath = filename
        if "/" not in filepath:
            filepath = os.path.join(dirname, filepath)
        # get fits and dump it to disk
        log.info("Dumping remote file %s as %s", fits_url, filepath)
        with urllib.request.urlopen(fits_url) as f_in:
            with open(filepath, "wb") as f_out:
                shutil.copyfileobj(f_in, f_out)
        return filepath

    def import_product(self, filename):
        """Uploads the fits file at *self.import_endpoint/filename* to the SDB

        import file {filename} as SR3/SR4 product.
        CARD and OBS_ID keywords mandatory in the file

        Parameters
        ----------
        filename : str
            filename to import
        """
        return self._import_file(filename, self.import_endpoint)

    def update_product(self, product_id, filename):
        """Replaces the SDB product with ID `product_id` by the fits file `path/to/file`.

        update SR3/SR4 product {product_id} by {filename}.
        CARD and OBS_ID keywords mandatory in the file

        Parameters
        ----------
        filename : str
            filename to update
        product_id : int
            SDB product id to update
        """
        return self._import_file(filename, f"{self.update_endpoint}/{product_id}")

    def metadata_search(self, **kwargs):
        """Request and export SP metadata from svom.messaging.he database in json format

        usage example: search(acronym="QPO_ECl", obs_id=1)

        *Available KW search in kwargs are: acronym, pdb_id, schema_version,
        program, instrument, type, json_schema, search_kw, level, ba, can_add_burstid
        can_add_obsid, added_at.*

        Each key in the kwargs can be a single value, a value list separated by
        comma, and accepts > and < sign. Those will be converted to be understood
        by the SDB API.

        Example:

        ::

            date=">2021",
            obs_id="1, 2, 3"

        Returns
        -------
        resp : `requests.models.Response`
            SDB response
        """
        # define output fields
        available_outputs = {
            "acronym": 1,
            "pdb_id": 2,
            "schema_version": 3,
            "program": 4,
            "instrument": 5,
            "type": 6,
            "json_schema": 7,
            "search_kw": 8,
            "level": 9,
            "ba": 10,
            "can_add_burstid": 11,
            "can_add_obsid": 12,
            "added_at": 13,
        }

        # build requests params
        params = self._get_search_params(available_outputs, **kwargs)

        # send request
        resp = self.get(self.metadata_endpoint, params=params)

        # return server response as JSON
        return resp

    def search(self, **kwargs):
        """Returns a SDB response in JSON format according to the kwargs.

        request and export SR3/SR4 data from svom.messaging.he database in json format
        usage example: search(acronym="QPO_ECl", obs_id=1)

        *Available KW search in kwargs are: product_id, obs_id, obsid, card,
        acronym, sp_acronym, product, name, url, criteria, date, added_at,
        product_version, program, instrument, type, filename, upload_filename,
        burstid, burst_id, pipeline_version, schema_version, src_id, update_nb.*

        Each key in the kwargs can be a single value, a value list separated by
        comma, and accepts > and < sign. Those will be converted to be understood
        by the SDB API.

        Example:

        ::

            date=">2021",
            obs_id="1, 2, 3"

        Returns
        -------
        resp : `requests.models.Response`
            SDB response
        """
        # define output fields
        available_outputs = {
            "product_id": 1,
            "obs_id": 2,
            "obsid": 2,
            "card": 3,
            "acronym": 3,
            "sp_acronym": 3,
            "product": 3,
            "name": 3,
            "url": 4,
            "criteria": 5,
            "date": 6,
            "added_at": 6,
            "product_version": 7,
            "program": 8,
            "instrument": 9,
            "type": 10,
            "filename": 11,
            "upload_filename": 11,
            "burstid": 12,
            "burst_id": 12,
            "pipeline_version": 13,
            "schema_version": 14,
            "src_id": 15,
            "update_nb": 16,
        }

        # build requests params
        params = self._get_search_params(available_outputs, **kwargs)

        # send request
        resp = self.get(self.search_endpoint, params=params)

        # return server response
        return resp

    def raw_search(self, **kwargs):
        """Request and export L0/L1 data from svom.messaging.he database in json format.

        usage example: search(acronym="QPO_ECl", obs_id=1).

        *Available KW search in kwargs are: product_id, obs_id, obsid, card,
        acronym, sp_acronym, product, name, url, criteria, date, added_at,
        product_version, program, instrument, type, upload_filename,
        burstid, burst_id, pipeline_version, schema_version, src_id, update_nb.*

        Each key in the kwargs can be a single value, a value list separated by
        comma, and accepts > and < sign. Those will be converted to be understood
        by the SDB API.

        Example:

        ::

            date=">2021",
            obs_id="1, 2, 3"

        Returns
        -------
        resp : `requests.models.Response`
            SDB response
        """
        # define output fields
        available_outputs = {
            "product_id": 1,
            "obs_id": 2,
            "obsid": 2,
            "card": 3,
            "acronym": 3,
            "sp_acronym": 3,
            "product": 3,
            "name": 3,
            "url": 4,
            "criteria": 5,
            "date": 6,
            "added_at": 6,
            "product_version": 7,
            "program": 8,
            "instrument": 9,
            "type": 10,
            "upload_filename": 11,
            "burstid": 12,
            "burst_id": 12,
            "pipeline_version": 13,
            "schema_version": 14,
            "update_nb": 15,
        }

        # build requests params
        params = self._get_search_params(available_outputs, **kwargs)

        # send request
        resp = self.get(self.raw_search_endpoint, params=params)

        # return server response
        return resp

    def _get_search_params(self, available_outputs, **kwargs):
        """Builds SDB-compatible request params from kwargs in accordance to the available_outputs

        Each key in the kwargs has to be present in the *available_outputs* dictionary, and the
        associated value can be a single value, a list, or a string containing mathematical
        operators such as ">", "<", "=", "!=", "~", "|", or a comscriptsation thereof.
        Those values will be converted to be compatible by the SDB API.

        Parameters
        ----------
        available_outputs : dict
            dictionary containing all the available outputs associated to a SDB search endpoint.
            The keys should be numerical ids and the values the associated arguments as strings.

        Returns
        -------
        params : dict
            search param dict converted for SDB API compatibility
        """
        # prepare return value
        params = {}

        # build output parameters
        # default to all available outputs
        outputs = [*available_outputs.keys()]
        if "outputs" in kwargs:
            outputs = kwargs.pop("outputs")
        # check request validity
        if not isinstance(outputs, list):
            outputs = [outputs]
        if not set(outputs).issubset(available_outputs.keys()):
            log.error("Requested outputs should be in %s", available_outputs.keys())
        # add output list to the params dict
        # "list(dict.fromkeys(...))" removes duplicated entries whilst preserving order
        params["a"] = ";".join(
            list(dict.fromkeys([f"{available_outputs[key]}" for key in outputs]))
        )

        # build search criteria
        crit_tuples = []
        for key, crit_arg in kwargs.items():
            oper, val = "eq", str(crit_arg)
            # special "criteria" argument handling (JSON operator)
            if key == "criteria":
                if isinstance(crit_arg, list):
                    for subcrit_arg in crit_arg:
                        subcriterion = self._json_criterion_from_str(str(subcrit_arg))
                        crit_tuples.append((available_outputs[key], subcriterion))
                    continue
                criterion = self._json_criterion_from_str(str(crit_arg))
            else:
                criterion = self._criterion_from_arg(crit_arg)
            # add criterion to {crit_tuples} list
            crit_tuples.append((available_outputs[key], criterion))
        # add search crit_tuples to the params dict
        # "list(dict.fromkeys(...))" removes duplicated entries whilst preserving order
        if crit_tuples:
            params["c"] = ";".join(f"{key}::{oper_val}" for key, oper_val in crit_tuples)

        return params

    def _criterion_from_list(self, crit_list):
        """Deduces operator and value to be used in SDB requests params from the provided crit_list.

        Examples:

        ::

            _criterion_from_list([">=2021", "<2022"]) = "bw::2021|2022"
            _criterion_from_list([1, 2]) = "in::1|2"

        Parameters
        ----------
        crit_list : list
            list of values to be used with an "in" operator in a SDB request. If the list contains
            only two strings starting with comparison symbols "<" and ">", they will be interpreted
            as a range and associated to the "between" operator instead

        Returns
        -------
        crit_string : str
            SDB-API-compatible string with "in" or "bw" operator.
            value to be associated to the *oper* operator in the SDB request.
            Input *crit_list* stripped from svom.messaging.athematical operators and joined with "|"
        """
        # check if we"re dealing with a range search
        if len(crit_list) == 2 and crit_list[0][0] in [">", "<"]:
            # range search: use "bw" operator:
            # c=id_attribute::bw::value_min|value_max
            if crit_list[0].startswith(">") and crit_list[1].startswith("<"):
                min_val = crit_list[0][1:]
                max_val = crit_list[1][1:]
            elif crit_list[1].startswith(">") and crit_list[0].startswith("<"):
                min_val = crit_list[1][1:]
                max_val = crit_list[0][1:]
            oper, val = "bw", f"{min_val.strip('=')}|{max_val.strip('=')}"
        else:
            # list search: use 'in' operator:
            # c=id_attribute::in::value_x|value_y|value_z
            oper, val = "in", "|".join([str(option) for option in crit_list])
        return f"{oper}::{val}"

    def _criterion_from_arg(self, crit_arg):
        """Deduces operator and value to be used in SDB requests params from the provided crit_arg.

        Examples:

        ::

            _criterion_from_arg(">=2021") = "gte::2021")
            _criterion_from_arg("!=42") = "neq::42"

        Parameters
        ----------
        crit_str : str
            human readable string that can be a single value or contain mathematical
            operators ">", "<", "=", "!=", "~", "|", or a comscriptsation thereof.

        Returns
        -------
        oper : str
            SDB-API-compatible operator (examples: "eq", "gt", "gte")
        val : str
            value to be associated to the *oper* operator in the SDB request.
            Basically just input *crit_str* stripped from svom.messaging.athematical operators
        """

        # lists are handled in a dedicated method
        if isinstance(crit_arg, list):
            return self._criterion_from_list(crit_arg)
        # make sure we are dealing with a string
        crit_str = str(crit_arg)
        # default would be "eq::{crit_str}"
        oper, val = "eq", crit_str
        if "|" in crit_str:
            # c=id_attribute::in::value_x|value_y|value_z
            oper, val = "in", "|".join(crit_str.split("|"))
        elif crit_str.startswith(">="):
            oper, val = "gte", crit_str[2:]
        elif crit_str.startswith("<="):
            oper, val = "lte", crit_str[2:]
        elif crit_str.startswith("!=") or crit_str.startswith("<>"):
            oper, val = "neq", crit_str[2:]
        elif crit_str.startswith("!~"):
            oper, val = "nlk", crit_str[2:]
        elif crit_str.startswith("!"):
            oper, val = "neq", crit_str[1:]
        elif crit_str.startswith("~"):
            oper, val = "lk", crit_str[1:]
        elif crit_str.startswith(">"):
            oper, val = "gt", crit_str[1:]
        elif crit_str.startswith("<"):
            oper, val = "lt", crit_str[1:]
        # prepare criterion as operator::value string
        crit_string = f"{oper}::{val}"
        # make sure proper syntax is used for null or not null criteria
        if val in ["None", "none", "null"]:
            crit_string = "nl"
            # if the operator is not equal then the test should be "not null"
            if oper != "eq":
                crit_string = "nnl"
        return crit_string

    def _json_criterion_from_str(self, crit_str):
        """builds SDB JSON request from svom.messaging. criterion string.

        For search using the "js" SDB operator to access searchable keywords that are not part of
        the standard SDB available outputs.

        Example:

        ::

            _json_criterion_from_str("PASS_ID=42") = ("js", "PrimaryHDU,PASS_ID|eq|42")


        Parameters
        ----------
        crit_str : str
                   string representation of the JSON search criterium in SDB format
                   *extension,keyword|operator|value*.
                   *extension* will be replaced by *PrimaryHDU* if not provided, and the
                   *keyword|operator|value* can be expressed with
                   mathematical symbols instead of SDB operators, such as "=", ">", etc.

        Returns
        -------
        val : str
            request string converted for SDB API
        """
        if "," in crit_str:
            extension, json_crit = crit_str.split(",")
        else:
            extension = "PrimaryHDU"
            json_crit = crit_str
            log.info("Expected format for criteria argument is extension,keyword|operator|value")
            log.warning("Missing extension in criteria search. Using default 'PrimaryHDU'")
        # convert mathematical symbols to SDB-compatible operator string
        if "|" not in json_crit:
            json_crit = json_crit.replace(">=", "|gte|")
            json_crit = json_crit.replace("<=", "|lte|")
            json_crit = json_crit.replace("<>", "|neq|")
            json_crit = json_crit.replace("!=", "|neq|")
            json_crit = json_crit.replace("=", "|eq|")
            json_crit = json_crit.replace(">", "|gt|")
            json_crit = json_crit.replace("<", "|lt|")
        # make sure None-ish values use the proper operator string:
        #   - val|eq|None should become val|nl|
        #   - val|neq|None should become val|nnl|
        if json_crit[-7:] in ["eq|None", "eq|none", "eq|null"]:
            json_crit = f"{json_crit[:-7]}nl|"
        # rebuild val with extension
        val = f"{extension},{json_crit}"
        # return oper, val with operator always 'js'
        return f"js::{val}"

    def get_fits_urls(self, **kwargs):
        """Get the list of fits urls (SR3/SR4) for a given search in `kwargs`.

        Returns
        -------
        fits_urls : list
            SR3/SR4 fits url list
        """
        json_resp = self.search(**kwargs, outputs=["url"]).json()
        fits_urls = [entry["url"] for entry in json_resp]
        return fits_urls

    def get_raw_fits_urls(self, **kwargs):
        """Get the fits file urls (L0/L1) for a given search in `kwargs`.

        Returns
        -------
        fits_urls : list
            L0/L1 fits url list
        """
        json_resp = self.raw_search(**kwargs, outputs=["url"]).json()
        fits_urls = [entry["url"] for entry in json_resp]
        return fits_urls

    def get_latest_fits_url(self, **kwargs):
        """Get the url of the latest SR3/SR4 data available for a given search in `kwargs`.

        Returns
        -------
        latest["url"] : str
            latest SR3/SR4 url available
        """
        # retrieve urls and dates for search
        resp = self.search(**kwargs, outputs=["url", "added_at"])
        json_resp = resp.json()
        # if search has no result return empty string
        if json_resp == []:
            log.warning("No result for given search: %s (%s)", kwargs, resp.status_code)
            return None
        # find latest entry for search
        latest = json_resp[-1]
        for entry in reversed(json_resp[:-1]):
            if entry["added_at"] > latest["added_at"]:
                latest = entry
        log.debug("Latest file found for search: %s (%s)", latest["url"], latest["added_at"])
        # return latest url
        return latest["url"]

    def get_latest_raw_fits_url(self, **kwargs):
        """Get the url of the latest L0/L1 data available for a given search in `kwargs`.

        Returns
        -------
        latest["url"] : str
            latest L0/L1 url available
        """
        # retrieve urls and dates for search
        resp = self.raw_search(**kwargs, outputs=["url", "added_at"])
        json_resp = resp.json()
        # if search has no result return empty string
        if json_resp == []:
            log.warning("No result for given search: %s (%s)", kwargs, resp.status_code)
            return None
        # find latest entry for search
        latest = json_resp[-1]
        for entry in reversed(json_resp[:-1]):
            if entry["added_at"] > latest["added_at"]:
                latest = entry
        log.debug("Latest file found for search: %s (%s)", latest["url"], latest["added_at"])
        # return latest url
        return latest["url"]

    def save_raw_fits_files(self, dirname=".", filename=None, **kwargs):
        """Saves all L0/L1 fits products for a given search from kwargs in directory `dirname`.

        If the args search leads to one entry and filename is provided, it dumps
        fits file as {dirname}/{filename} for a given search.

        If the keyword args search leads to multiple entries filename should not
        be provided.

        Parameters
        ----------
        dirname : str
            name of the directory where to dump the fits file
        filename : str, optional
            filename where to dump the fits file if the search return only one
            entry

        Returns
        -------
        dumped_files : list
            list of file paths
        """
        dumped_files = []
        fits_urls = self.get_raw_fits_urls(**kwargs)
        if len(fits_urls) > 1 and filename is not None:
            exc = (
                f"save_raw_fits_files() called with filename={filename} while"
                f"the database search returned multiple products: {fits_urls}"
            )
            raise ValueError(exc)

        log.info("Dumping remote file(s) %s", fits_urls)
        for remote_url in fits_urls:
            filepath = self._dump_remote_fits_file(remote_url, dirname, filename)
            dumped_files.append(filepath)
        return dumped_files

    def save_latest_raw_fits_file(self, dirname=".", filename=None, **kwargs):
        """Dumps the latest L0/L1  fits file available for a given search in `kwargs`.

        Parameters
        ----------
        dirname : str, optional
            name of the directory where to dump the fits file
        filename : str, optional
            filename where to dump the fits file. If None, take the name in the
            SDB

        Returns
        -------
        dumped_file : str
            file path
        """
        dumped_file = None
        # retrieve latest fits url
        remote_url = self.get_latest_raw_fits_url(**kwargs)
        if remote_url is not None:
            dumped_file = self._dump_remote_fits_file(remote_url, dirname, filename)
        return dumped_file

    def save_fits_files(self, dirname=".", filename=None, **kwargs):
        """Saves all SR3/SR4 fits products for a given search from kwargs in directory `dirname`.

        If the args search leads to one entry and filename is provided, it dumps
        fits file as {dirname}/{filename} for a given search.

        If the keyword args search leads to multiple entries filename should not
        be provided.

        Parameters
        ----------
        dirname : str, optional
            name of the directory where to dump the fits file
        filename : str, optional
            filename where to dump the fits file if the search return only one
            entry

        Returns
        -------
        dumped_files : list
            list of file paths
        """
        dumped_files = []
        fits_urls = self.get_fits_urls(**kwargs)
        if len(fits_urls) > 1 and filename is not None:
            exc = (
                f"save_fits_files() called with filename={filename} while"
                f"the database search returned multiple products: {fits_urls}"
            )
            raise ValueError(exc)
        log.debug("Dumping remote file(s) %s", fits_urls)
        for remote_url in fits_urls:
            filepath = self._dump_remote_fits_file(remote_url, dirname, filename)
            dumped_files.append(filepath)
        return dumped_files

    def save_latest_fits_file(self, dirname=".", filename=None, **kwargs):
        """Dumps the latest SR3/SR4  fits file available for a given search in `kwargs`.

        Parameters
        ----------
        dirname : str, optional
            name of the directory where to dump the fits file
        filename : str, optional
            filename where to dump the fits file. If None, take the name in the
            SDB

        Returns
        -------
        dumped_file : str
            file path
        """
        dumped_file = None
        # retrieve latest fits url
        remote_url = self.get_latest_fits_url(**kwargs)
        if remote_url is not None:
            dumped_file = self._dump_remote_fits_file(remote_url, dirname, filename)
        return dumped_file

    def get_fits_content(self, **kwargs):
        """Returns content of the SR3/SR4 product fits file for a given search in `kwargs`.

        If the search return one product. If several, raises an error.

        WARNING: requires astropy

        Returns
        -------
        fits_content : `astropy.io.fits.HDUList`
            content of the fits file
        """
        if not self.has_astropy:
            log.error(
                "svom.messaging's get_latest_fits_content() method requires astropy "
                "which couldn't be found. If you want to use this method please "
                "install it like so: pip3 install astropy"
            )
            sys.exit(1)
        # assert the search returns only one file
        fits_urls = self.get_fits_urls(**kwargs)
        if len(fits_urls) != 1:
            exc = (
                f"get_fits_content() failed: "
                f"the database search did not return a single product: {fits_urls}"
            )
            raise ValueError(exc)
        # build downloadable fits URL
        fits_url = self._build_fits_url(fits_urls[0])
        # get fits and open it without writing it to disk
        fits_content = ""
        log.info("Retrieveing %s content", fits_url)
        with urllib.request.urlopen(fits_url) as f_in:
            fits_content = fits.open(f_in)
        # return fits content
        return fits_content

    def get_latest_fits_content(self, **kwargs):
        """Returns the latest SR3/SR4 data available for a given search in `kwargs`.

        WARNING: requires astropy

        Returns
        -------
        fits_content : `astropy.io.fits.HDUList`
            content of the fits file
        """
        if not self.has_astropy:
            log.error(
                "svom.messaging's get_latest_fits_content() method requires astropy "
                "which couldn't be found. If you want to use this method please "
                "install it like so: pip3 install astropy"
            )
            sys.exit(1)
        # retrieve latest fits url
        remote_url = self.get_latest_fits_url(**kwargs)
        if remote_url is None:
            return None
        # build downloadable fits URL
        fits_url = self._build_fits_url(remote_url)
        # get fits and open it without writing it to disk
        fits_content = ""
        log.info("Retrieveing %s content", fits_url)
        with urllib.request.urlopen(fits_url) as f_in:
            fits_content = fits.open(f_in)
        # return fits content
        return fits_content

    def list_conflicting_products(self, filename):
        """Lists products in SDB that conflicts with `filename` based on the SDB unicity rule.

        The search for conflicts is made using:
        * CARD, PROGRAM and PRDM_VER extracted from svom.messaging.filename` header
        * unicity rule retrieved from svom.messaging.he metadata corresponding to CARD and PROGRAM

        Returns
        -------
        resp : `requests.models.Response`
            SDB response with the list of conflicting product
        """
        resp = None
        with fits.open(filename) as fits_file:
            # retrieve mandatory fields values from svom.messaging.eader
            _header = fits_file[0].header.copy()  # pylint: disable=no-member
            # prepare search criteria with mandatory keywords
            _criteria = {
                "acronym": _header.get("CARD"),
                "program": _header.get("PROGRAM"),
                "schema_version": _header.get("PRDM_VER"),
            }
            _outputs = ["product_id", "added_at", "product_version"]
            if None in _criteria.values():
                err_msg = (
                    f"One or more of the mandatory _criteria is missing "
                    f"in product {fits_file}. Found: {_criteria}"
                )
                log.error(err_msg)
                raise ValueError(err_msg)
            # retrieve product metadata
            metadata = self.metadata_search(acronym=_criteria["acronym"]).json()
            if len(metadata) != 1:
                err_msg = (
                    f"Could not find unique metadata for product with acronym "
                    f"{_criteria['acronym']}. Found {len(metadata)}"
                )
                log.error(err_msg)
                raise ValueError(err_msg)
            # retrieve unicity rules from svom.messaging.etadata
            unicity_rule = metadata[0]["json_schema"].get("unicity_rule", {})
            unique_keys = unicity_rule.get(_criteria["program"])
            if unique_keys is None:
                err_msg = (
                    f"No unicity_rule found in {_criteria['acronym']} metadata "
                    f"for {_criteria['program']} program ."
                    f"Found {{'unicity_rule': {unicity_rule}}}"
                )
                log.error(err_msg)
                raise ValueError(err_msg)
            # loop over unique keys and add them to search criteria
            _hdu_criteria = []
            for key in unique_keys:
                # all keys except obs_id and burst_id should be searched in the primary HDU
                if key in ["OBS_ID", "BURST_ID"]:
                    _criteria[key.lower()] = _header.get(key)
                else:
                    _hdu_criteria.append(f"PrimaryHDU,{key}|eq|{_header.get(key)}")
            # add HDU criteria to search params if any
            if _hdu_criteria:
                _criteria["criteria"] = _hdu_criteria
            # actual request endpoint depends on level and data stream
            level = metadata[0]["json_schema"]["dp_level"]
            stream = metadata[0]["json_schema"].get("datatype")
            if level[0:2] in ["L1", "L0"] and stream != "VHF":
                resp = self.raw_search(**_criteria, outputs=_outputs)
            else:
                resp = self.search(**_criteria, outputs=_outputs)
        return resp

    def import_or_update(self, filename):
        """Dynamically decides if file {filename} should be imported or update in SDB

        It uses the import or update endpoint (if uniqueness rule is"burst_id":
        header.get("BURST_ID"), broken)

        WARNING: requires astropy

        Parameters
        ----------
        filename : str
            filename to upload to SDB

        Returns
        -------
        resp : `requests.models.Response`
            SDB response
        """
        log.info("Preparing %s import or update", filename)
        if not self.has_astropy:
            log.error(
                "svom.messaging's import_or_update() method requires astropy "
                "which couldn't be found. If you want to use this method please "
                "install it like so: pip3 install astropy"
            )
            sys.exit(1)
        # Search for a conflicting product in SDB
        log.info("Searching SDB for conflicting product")
        conflict_resp = self.list_conflicting_products(filename)
        json_conflicts = conflict_resp.json()

        # Take action depending of search output
        if json_conflicts == []:
            # No conflict product found in SDB
            # --> import
            log.info("No conflicting product found in SDB, importing the product")
            response = self.import_product(filename)
        else:
            # Product already exists in SDB
            # --> update the product
            log.info("Found conflicting products in SDB:")
            latest_conflict = json_conflicts[-1]
            for entry in reversed(json_conflicts[:-1]):
                log.info("    %s", entry)
                if entry["product_version"] > latest_conflict["product_version"]:
                    latest_conflict = entry
            log.warning("The import of %s would break unicity rules.", filename)
            log.warning(
                "Requesting update of product #%s instead.",
                latest_conflict["product_id"],
            )
            response = self.update_product(latest_conflict["product_id"], filename)

        return response

    def update_procver_and_import(self, filename):
        """Checks SDB for conflicts and imports `path/to/file` either with PROC_VER=1 or with
        PROC_VER+1 with respect to the last SDB version

        Dynamically decides if file {filename} should be imported in SDB as-is
        or if its PROC_VER should be increased (if uniqueness rule is broken).

        WARNING: requires astropy

        Parameters
        ----------
        filename : str
            filename to upload to SDB

        Returns
        -------
        resp : `requests.models.Response`
            SDB response
        """
        if not self.has_astropy:
            log.error(
                "svom.messaging's import_or_update() method requires astropy "
                "which couldn't be found. If you want to use this method please "
                "install it like so: pip3 install astropy"
            )
            sys.exit(1)
        log.info("Preparing %s import with automated PROC_VER update", filename)
        # Search for a conflict product in SDB
        log.info("Searching SDB for conflicting product")
        conflict_resp = self.list_conflicting_products(filename)
        json_conflicts = conflict_resp.json()
        # Take action depending of search output
        if json_conflicts == []:
            # No conflict product found in SDB
            # --> import
            log.info("No conflicting product found in SDB")
            # Set PROC_VER=1 in all HDUs
            new_proc_ver = 1
            with fits.open(filename) as fits_file:
                for hdu in fits_file:
                    if "PROC_VER" in hdu.header:
                        hdu.header["PROC_VER"] = new_proc_ver
                fits_file.writeto(filename, overwrite=True)
        else:
            # Product already exists in SDB
            # --> increment PROC_VER in product
            log.info("Found conflicting products in SDB:")
            # Retrieve latest PROC_VER from svom.messaging.onflicting products
            sdb_proc_ver = json_conflicts[-1]["product_version"]
            for entry in reversed(json_conflicts[:-1]):
                log.info("    %s", entry)
                sdb_proc_ver = max(sdb_proc_ver, entry["product_version"])
            log.warning(
                "The import of %s would break unicity rules. Incrementing PROC_VER",
                filename,
            )
            # Increment PROC_VER in all HDUs
            new_proc_ver = sdb_proc_ver + 1
            with fits.open(filename) as fits_file:
                for hdu in fits_file:
                    if "PROC_VER" in hdu.header:
                        hdu.header["PROC_VER"] = new_proc_ver
                fits_file.writeto(filename, overwrite=True)
        # Import file
        log.info("Attempting product import with PROC_VER=%s", new_proc_ver)
        response = self.import_product(filename)
        return response
