"""
CalDbIo test file
"""

import os
import json
import sys
import pytest
import tempfile
import logging
from unittest import mock

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
from package.svom.messaging.caldbio import CalDbIo

DATA_DIR = os.path.join(os.path.dirname(__file__), "data")

log = logging.getLogger("test_xbandio")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)


def get_pretty_json(dictionnary):
    """
    imported from svom.messaging.ricks, might be useful for the tests
    :return: A pretty string representation of the dictionary
    :rtype: Python Dict
    """
    return json.dumps(dictionnary, indent=2, sort_keys=True)


def print_pretty_json(dictionnary):
    """
    Print  pretty string representation of the dictionary
    imported from svom.messaging.ricks, might be useful for the tests
    """
    print(get_pretty_json(dictionnary))


def read_dict_from_file(filename):
    """
    Read a Dict in filename
    imported from svom.messaging.ricks, might be useful for the tests
    :param filename: filename
    :type filename: string
    :return: the Dict extracted from svom.messaging.he file
    :rtype: Python Dict
    """
    try:
        with open(filename, "r", encoding="utf8") as file_handler:
            return json.load(file_handler)

    except OSError as exception:
        log.error("Can't read %s because %s", filename, exception)
        return None


"""
 Bulding mock responses
"""
HTTPIO_REQUEST = "package.svom.messaging.httpio.requests.Session.request"


# pylint: disable=too-few-public-methods
class MockHeaders:
    """
    mock response header"
    """

    def __init__(self):
        self.filename = None

    def get(self, _):
        """
        mock header accessor
        """
        return f'xyz="{self.filename}"'


class MockMap:
    """
    mock response"
    """

    def __init__(self):
        self.status_code = 200
        self.text = None
        self.headers = MockHeaders()


# pylint: disable=too-few-public-methods
class MockList:
    """
    mock response"
    """

    def __init__(self):
        self.status_code = 200
        self.text = None
        self.headers = MockHeaders()


# pylint: disable=too-few-public-methods
class MockLatest:
    """
    mock response"
    """

    def __init__(self):
        self.status_code = 200
        self.text = None
        self.headers = MockHeaders()


# pylint: disable=too-few-public-methods
class MockSearch:
    """
    mock response"
    """

    def __init__(self):
        self.status_code = 200
        self.content = None
        self.headers = MockHeaders()


@pytest.fixture
# mock a response 200
def sync_200_map():
    """mimics 'requests' success response"""
    retour = MockList()
    retour.text = json.dumps(
        read_dict_from_file(os.path.join(DATA_DIR, "caldbio_mockmap.json"))
    )
    return retour


def sync_200_mxt_map():
    """mimics 'requests' success response"""
    retour = MockList()
    retour.text = json.dumps(
        read_dict_from_file(os.path.join(DATA_DIR, "caldbio_mockmap_mxt.json"))
    )
    return retour


@pytest.fixture
def sync_200_list():
    """mimics 'requests' success response"""
    retour = MockList()
    retour.text = json.dumps(
        read_dict_from_file(os.path.join(DATA_DIR, "caldbio_mocklist_ok.json"))
    )
    return retour


@pytest.fixture
def sync_404_list():
    """mimics 'requests' success response"""
    retour = MockList()
    retour.status_code = 404
    retour.text = json.dumps(
        read_dict_from_file(os.path.join(DATA_DIR, "caldbio_mocklist_KO.json"))
    )
    return retour


@pytest.fixture
def sync_200_get_latest_filename():
    """mimics 'requests' success response"""
    retour = MockLatest()
    retour.headers.filename = "teldef_2022-01-17_12:15:00.fits"
    return retour


@pytest.fixture
def sync_404_get_latest_filename():
    """mimics 'requests' success response"""
    retour = MockLatest()
    retour.status_code = 404
    return retour


@pytest.fixture
def sync_200_search():
    """mimics 'requests' success response"""
    retour = MockSearch()
    with open(os.path.join(DATA_DIR, "caldbio_mockfits.fits"), "rb") as scriptsary_file:
        # Read the whole file at once
        retour.content = scriptsary_file.read()
        retour.headers.filename = "caldbio_mockfits.fits"
    return retour


@pytest.fixture
def sync_404_search():
    """mimics 'requests' success response"""
    retour = MockSearch()
    retour.status_code = 404
    return retour


@pytest.fixture
def sync_201_upload_file():
    """mimics 'requests' success response"""
    retour = MockList()
    retour.status_code = 201
    retour.text = json.dumps(
        read_dict_from_file(os.path.join(DATA_DIR, "caldb_mockupload_tititata.json"))
    )
    return retour


@pytest.fixture
def sync_400_upload_file():
    """mimics 'requests' success response"""
    retour = MockList()
    retour.status_code = 400
    retour.text = json.dumps(
        read_dict_from_file(os.path.join(DATA_DIR, "caldb_mockupload_badformat.json"))
    )
    return retour


@pytest.fixture
def sync_201_valid_file():
    """mimics 'requests' success response"""
    retour = MockList()
    retour.status_code = 201
    retour.text = json.dumps(
        read_dict_from_file(os.path.join(DATA_DIR, "caldb_mockup_valid.json"))
    )
    return retour


@pytest.fixture
def sync_400_valid_file():
    """mimics 'requests' success response"""
    retour = MockList()
    retour.status_code = 201
    retour.text = json.dumps(
        {"valid": False, "name_org": "filename", "message": "Coulnt't be uploaded"}
    )
    return retour


@pytest.fixture(scope="module")
# mock the autentification
def caldb_client():
    """return sync VhfDbIos"""
    # with mock.patch('svom.messaging.tokens.KcTokens._request_tokens'):
    sync_client = CalDbIo("fake://xband/", use_tokens=False)
    yield sync_client


"""
 Test suite
"""


def test_map(caldb_client, sync_200_map):  # pylint: disable=redefined-outer-name
    """test CALDB map"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_map) as _:
        response = caldb_client.global_map()
        assert response == read_dict_from_file(
            os.path.join(DATA_DIR, "caldbio_mockmap.json")
        )
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_map) as _:
        response = caldb_client.ecl_map()
        assert response == read_dict_from_file(
            os.path.join(DATA_DIR, "caldbio_mockmap_ecl.json")
        )
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_map) as _:
        response = caldb_client.mxt_map()
        assert response == read_dict_from_file(
            os.path.join(DATA_DIR, "caldbio_mockmap_mxt.json")
        )
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_map) as _:
        response = caldb_client.vt_map()
        assert response == read_dict_from_file(
            os.path.join(DATA_DIR, "caldbio_mockmap_vt.json")
        )
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_map) as _:
        response = caldb_client.grm_map()
        assert response == read_dict_from_file(
            os.path.join(DATA_DIR, "caldbio_mockmap_grm.json")
        )


def test_list(
    caldb_client, sync_200_list, sync_404_list
):  # pylint: disable=redefined-outer-name
    """test CALDB list found"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_list) as _:
        response = caldb_client.list("mxt", "teldef")
        assert response == [
            "teldef_2017-01-01_00:00:00.fits",
            "teldef_2022-01-17_12:15:00.fits",
        ]
    """test CALDB list not found """
    with mock.patch(HTTPIO_REQUEST, return_value=sync_404_list) as _:
        response = caldb_client.list("ecl", "teldef")
        assert response == []


def test_get_latest_filename(
    caldb_client, sync_200_get_latest_filename, sync_404_get_latest_filename
):  # pylint: disable=redefined-outer-name
    """test CALDB latest file found"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_get_latest_filename) as _:
        fname = caldb_client.get_latest_filename("ecl", "rmf_matrix")
        assert fname == "teldef_2022-01-17_12:15:00.fits"
    """test CALDB latest file not found """
    with mock.patch(HTTPIO_REQUEST, return_value=sync_404_get_latest_filename) as _:
        fname = caldb_client.get_latest_filename("ecl", "teldef")
        assert fname is None


def test_search(
    caldb_client, sync_200_search, sync_404_search
):  # pylint: disable=redefined-outer-name
    """test CALDB file retrieval"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_search) as _:
        outfile = caldb_client.search(
            "mxt", "teldef", download_path=tempfile.gettempdir()
        )
    assert os.path.getsize(outfile) == os.path.getsize(
        os.path.join(DATA_DIR, "caldbio_mockfits.fits")
    )
    os.remove(outfile)
    """test CALDB file failing retrieval """
    with mock.patch(HTTPIO_REQUEST, return_value=sync_404_search) as _:
        outfile = caldb_client.search(
            "mxt", "teldef", download_path=tempfile.gettempdir()
        )
    assert outfile is None


def test_upload_ok(
    caldb_client, sync_201_upload_file
):  # pylint: disable=redefined-outer-name
    """test successful uploads"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_201_upload_file) as _:
        response = caldb_client.upload_file(
            os.path.join(DATA_DIR, "GRM_TITI-TATA-20220821T094529.YML")
        )
        assert response == True

    with mock.patch(HTTPIO_REQUEST, return_value=sync_201_upload_file) as _:
        response = caldb_client.upload_file(
            os.path.join(DATA_DIR, "caldbio_TELDEF_2019.fits")
        )
        assert response == True


def test_upload_badname(
    caldb_client, sync_201_upload_file
):  # pylint: disable=redefined-outer-name
    """test wrong mime type"""
    response = caldb_client.upload_file(
        os.path.join(DATA_DIR, "caldbio_TELDEF_2019.fits.txt")
    )
    assert response == False


def test_upload_badformat(
    caldb_client, sync_400_upload_file
):  # pylint: disable=redefined-outer-name
    """test failing uploads"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_400_upload_file) as _:
        response = caldb_client.upload_file(
            os.path.join(DATA_DIR, "caldbio_WRONG_TELDEF.fits")
        )
        assert response == False


def test_valid_ok(
    caldb_client, sync_201_valid_file
):  # pylint: disable=redefined-outer-name
    """test successful uploads"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_201_valid_file) as _:
        response = caldb_client.valid_file(
            os.path.join(DATA_DIR, "GRM_TITI-TATA-20220821T094529.YML")
        )
        assert response["valid"] == True
        assert response["stored_in"] == "svom/mxt/bcf/teldef"

    with mock.patch(HTTPIO_REQUEST, return_value=sync_201_valid_file) as _:
        response = caldb_client.valid_file(
            os.path.join(DATA_DIR, "caldbio_TELDEF_2019.fits")
        )
        print(response)
        assert response["valid"] == True
        assert response["stored_in"] == "svom/mxt/bcf/teldef"


def test_valid_ko(
    caldb_client, sync_400_valid_file
):  # pylint: disable=redefined-outer-name
    """test successful uploads"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_400_valid_file) as _:
        response = caldb_client.valid_file(
            os.path.join(DATA_DIR, "GRM_TITI-TATA-20220821T094529.YML")
        )
        assert response["valid"] == False
        assert response["message"] == "Coulnt't be uploaded"
