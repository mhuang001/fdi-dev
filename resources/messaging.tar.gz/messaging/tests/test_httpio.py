"""
HttpIo test file
"""
import logging
import os
import sys
from asyncio import Future
from unittest import mock
import pytest
from requests import Response

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
from package.svom.messaging.httpio import HttpIo
from package.svom.messaging.utils import power_delay

log = logging.getLogger("test_httpio")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)

# keycloak token request expected content
KC_PAYLOAD = {"token": "mocked"}
KC_TOKEN_REQUEST = {
    "data": KC_PAYLOAD,
    "headers": {"Content-Type": "application/x-www-form-urlencoded"},
    "json": None,
    "method": "post",
    "url": "https://admin.svom.eu/keycloak/realms/svom-fsc/protocol/openid-connect/token",
}

KC_TOKEN_RESP = Response()
KC_TOKEN_RESP.status_code = 200
KC_TOKEN_RESP.json = lambda: {"ma?": "MAAA"}

HTTPIO_REQUEST = "package.svom.messaging.httpio.requests.Session.request"
TOKENS_REQUEST = "package.svom.messaging.tokens.requests.post"


@pytest.fixture(scope="module")
def kc_token():
    """return sync HttpIo"""
    os.environ["KC_CLIENT_ID"] = "FSC_PUBLIC"
    os.environ["KC_USERNAME"] = "toto@cea.fr"
    os.environ["KC_PASSWORD"] = "ZeFuckingPassword"


@pytest.fixture(scope="module")
def sync_client():
    """return sync HttpIo"""
    http_client = None
    with mock.patch(
        "package.svom.messaging.tokens.KcTokens._request_tokens"
    ), mock.patch(
        "package.svom.messaging.httpio.get_docker_secret",
        return_value="TOKEN_LIFE_MATTERS",
    ):
        http_client = HttpIo("http://fake/", max_tries=2)
    return http_client


@pytest.fixture(scope="module")
def async_client():
    """return async HttpIo"""
    http_client = None
    with mock.patch(
        "package.svom.messaging.tokens.KcTokens._async_request_tokens",
        return_value=None,
    ) as mocked, mock.patch(
        "package.svom.messaging.httpio.get_docker_secret",
        return_value="TOKEN_LIFE_MATTERS",
    ):
        http_client = HttpIo("http://fake/", max_tries=2, asynchronous=True)
        yield http_client
        http_client.stop()


@pytest.fixture(params=[200, 201])
def sync_2xx_response(request):
    """mimics 'requests' success response"""
    fake_response = Response()
    fake_response.status_code = request.param
    fake_response.json = lambda: {"breakfast": "eggs"}
    return fake_response


@pytest.fixture()
def sync_octetstream_response():
    """mimics 'requests' success response with content type octet-stream"""
    fake_response = Response()
    fake_response.status_code = 200
    fake_response.headers["content-type"] = "application/octet-stream"
    fake_response.json = lambda: {"breakfast": "eggs"}
    return fake_response


@pytest.fixture(params=[400, 404])
def sync_4xx_response(request):
    """mimics 'requests' error response"""
    fake_response = Response()
    fake_response.status_code = request.param
    fake_response.json = lambda: {}
    return fake_response


@pytest.fixture(params=[200, 201])
def async_2xx_response(request):
    """mimics 'aiohttp' success response"""
    fut = Future()
    fut.set_result({"breakfast": "eggs"})
    fake_method = lambda: fut
    fake_response = Response()
    fake_response.status = request.param
    fake_response.json = fake_method
    return fake_response


@pytest.fixture(params=[400, 404])
def async_4xx_response(request):
    """mimics 'aiohttp' error response"""
    fut = Future()
    fut.set_result({})
    fake_method = lambda: fut
    fake_response = Response()
    fake_response.status = request.param
    fake_response.json = fake_method
    return fake_response


def test_power_delay():
    """Test power delay"""
    res = power_delay(2)
    assert res == 2


def test_sync_get(
    sync_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test synchronous client get()"""
    with mock.patch(
        HTTPIO_REQUEST, return_value=sync_2xx_response
    ) as mocked, mock.patch(TOKENS_REQUEST, return_value=KC_TOKEN_RESP) as kc_mocked:
        # empty call
        response = sync_client.get()
        # assert response.headers.get('Authorization') == 'Basic TOKEN_LIFE_MATTERS'
        assert response.json() == {"breakfast": "eggs"}
        assert response.status_code == sync_2xx_response.status_code
        # root call with params
        response = sync_client.get("/", params={"breakfast": "eggs"})
        assert response.json() == {"breakfast": "eggs"}
        assert response.status_code == sync_2xx_response.status_code
        # endpoint call with params
        response = sync_client.get("/test", params={"breakfast": ["eggs", "spam"]})
        assert response.json() == {"breakfast": "eggs"}
        assert response.status_code == sync_2xx_response.status_code
        # requests.get should have been called 3 times
        expected_calls = [
            mock.call("GET", "http://fake/"),
            mock.call("GET", "http://fake/", params={"breakfast": "eggs"}),
            mock.call(
                "GET", "http://fake/test", params={"breakfast": ["eggs", "spam"]}
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_octetstream_get(
    sync_client, sync_octetstream_response
):  # pylint: disable=redefined-outer-name
    """test synchronous client get() with octetstream response"""
    with mock.patch(
        HTTPIO_REQUEST, return_value=sync_octetstream_response
    ) as mocked, mock.patch(TOKENS_REQUEST, return_value=KC_TOKEN_RESP) as kc_mocked:
        # assert original json is not empty
        assert sync_octetstream_response.json() == {"breakfast": "eggs"}
        # empty call
        response = sync_client.get()
        # assert response.headers.get('Authorization') == 'Basic TOKEN_LIFE_MATTERS'
        assert response.json() == {}
        assert response.status_code == 200


def test_sync_post(
    sync_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test synchronous client post()"""
    with mock.patch(
        HTTPIO_REQUEST, return_value=sync_2xx_response
    ) as mocked, mock.patch(TOKENS_REQUEST, return_value=KC_TOKEN_RESP) as kc_mocked:
        # empty call
        response = sync_client.post(json={"breakfast": "eggs"})
        assert response.json() == {"breakfast": "eggs"}
        assert response.status_code == sync_2xx_response.status_code
        # root call with params
        response = sync_client.post("/", json={"breakfast": ["eggs", "spam"]})
        assert response.json() == {"breakfast": "eggs"}
        assert response.status_code == sync_2xx_response.status_code
        # endpoint call with params
        response = sync_client.post(
            "/test", json={"breakfast": ["eggs", "bacon", "spam"]}
        )
        assert response.json() == {"breakfast": "eggs"}
        assert response.status_code == sync_2xx_response.status_code
        # requests.post should have been called 3 times
        expected_calls = [
            mock.call("POST", "http://fake/", json={"breakfast": "eggs"}),
            mock.call("POST", "http://fake/", json={"breakfast": ["eggs", "spam"]}),
            mock.call(
                "POST",
                "http://fake/test",
                json={"breakfast": ["eggs", "bacon", "spam"]},
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_sync_put(
    sync_client, sync_2xx_response
):  # pylint: disable=redefined-outer-name
    """test synchronous client post()"""
    with mock.patch(
        HTTPIO_REQUEST, return_value=sync_2xx_response
    ) as mocked, mock.patch(TOKENS_REQUEST, return_value=KC_TOKEN_RESP) as kc_mocked:
        # empty call
        response = sync_client.put(json={"breakfast": "toast"})
        assert response.json() == {"breakfast": "eggs"}
        assert response.status_code == sync_2xx_response.status_code
        # root call with params
        response = sync_client.put("/", json={"breakfast": ["eggs", "spam"]})
        assert response.json() == {"breakfast": "eggs"}
        assert response.status_code == sync_2xx_response.status_code
        # endpoint call with params
        response = sync_client.put(
            "/test", json={"breakfast": ["eggs", "bacon", "spam"]}
        )
        assert response.json() == {"breakfast": "eggs"}
        assert response.status_code == sync_2xx_response.status_code
        # requests.post should have been called 3 times
        expected_calls = [
            mock.call("PUT", "http://fake/", json={"breakfast": "toast"}),
            mock.call("PUT", "http://fake/", json={"breakfast": ["eggs", "spam"]}),
            mock.call(
                "PUT", "http://fake/test", json={"breakfast": ["eggs", "bacon", "spam"]}
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_sync_retry(
    sync_client, sync_4xx_response
):  # pylint: disable=redefined-outer-name
    """test synchronous client retries"""
    with mock.patch(
        HTTPIO_REQUEST, return_value=sync_4xx_response
    ) as mocked, mock.patch(TOKENS_REQUEST, return_value=KC_TOKEN_RESP) as kc_mocked:
        response = sync_client.post(
            "/test", json={"breakfast": ["eggs", "bacon", "spam"]}
        )
        # requests.post should have been called 2 times
        # (original call and 1 retry)
        expected_calls = [
            mock.call(
                "POST",
                "http://fake/test",
                json={"breakfast": ["eggs", "bacon", "spam"]},
            ),
            mock.call(
                "POST",
                "http://fake/test",
                json={"breakfast": ["eggs", "bacon", "spam"]},
            ),
        ]
        assert mocked.mock_calls == expected_calls
        # final response should have status 4xx and empty json
        assert response.json() == {}
        assert response.status_code == sync_4xx_response.status_code


@pytest.mark.asyncio
async def test_async_get(
    async_client, async_2xx_response
):  # pylint: disable=redefined-outer-name
    """test asynchronous client get()"""
    with mock.patch(
        "aiohttp.ClientSession._request", return_value=async_2xx_response
    ) as mocked:
        response = await async_client.async_get("/")
        # assert response.headers.get('Authorization') == 'Basic TOKEN_LIFE_MATTERS'
        expected_calls = [mock.call("GET", "http://fake/")]
        assert mocked.mock_calls == expected_calls
        assert response.json() == {"breakfast": "eggs"}
        assert response.status_code == async_2xx_response.status_code


@pytest.mark.asyncio
async def test_async_post(
    async_client, async_2xx_response
):  # pylint: disable=redefined-outer-name
    """test asynchronous client post()"""
    with mock.patch(
        "aiohttp.ClientSession._request", return_value=async_2xx_response
    ) as mocked:
        response = await async_client.async_post(
            "/test", json={"breakfast": ["eggs", "spam"]}
        )
        expected_calls = [
            mock.call("POST", "http://fake/test", json={"breakfast": ["eggs", "spam"]})
        ]
        assert mocked.mock_calls == expected_calls
        assert response.json() == {"breakfast": "eggs"}
        assert response.status_code == async_2xx_response.status_code


@pytest.mark.asyncio
async def test_async_put(
    async_client, async_2xx_response
):  # pylint: disable=redefined-outer-name
    """test asynchronous client post()"""
    with mock.patch(
        "aiohttp.ClientSession._request", return_value=async_2xx_response
    ) as mocked:
        response = await async_client.async_put(
            "/test", json={"breakfast": ["eggs", "spam"]}
        )
        expected_calls = [
            mock.call("PUT", "http://fake/test", json={"breakfast": ["eggs", "spam"]})
        ]
        assert mocked.mock_calls == expected_calls
        assert response.json() == {"breakfast": "eggs"}
        assert response.status_code == async_2xx_response.status_code


@pytest.mark.asyncio
async def test_async_retry(
    async_client, async_4xx_response
):  # pylint: disable=redefined-outer-name
    """test asynchronous client retries"""
    with mock.patch(
        "aiohttp.ClientSession._request", return_value=async_4xx_response
    ) as mocked:
        response = await async_client.async_post(
            "/test", json={"breakfast": ["eggs", "bacon", "spam"]}
        )
        # aiohttp.ClientSession._request should have been called 2 times
        # (original call and 1 retry)
        expected_calls = [
            mock.call(
                "POST",
                "http://fake/test",
                json={"breakfast": ["eggs", "bacon", "spam"]},
            ),
            mock.call(
                "POST",
                "http://fake/test",
                json={"breakfast": ["eggs", "bacon", "spam"]},
            ),
        ]
        assert mocked.mock_calls <= expected_calls
        # final response should have status 4xx and empty json
        assert response.json() == {}
        assert response.status_code == async_4xx_response.status_code
