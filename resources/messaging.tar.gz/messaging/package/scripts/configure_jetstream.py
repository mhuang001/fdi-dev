#!/usr/scripts/env package3
"""
 Script creating streams and consumers from Jetstream .JSON config file
 Usage info: package3 configure_jetstream.py [/PATH/TO/CONFIG.JSON]

 Henri Louvin - henri.louvin@cea.fr
"""

# Log
import sys
import json
import logging

log = logging.getLogger("js_config")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.DEBUG,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)
# NATS
from svom.messaging import jetstreamio_from_env


def main():
    """
    Instantiate NATS client and creates all streams
    """
    # Check args
    assert len(sys.argv) < 3, "Usage : package3 configure_jetstream.py [/PATH/TO/CONFIG.JSON]"
    if len(sys.argv) == 2:
        log.info("Trying to read NATS JetStream configuration from file '%s'", sys.argv[1])
        with open(sys.argv[1], "r") as json_file:
            js_config = json.load(json_file)
    else:
        log.info("Loading default Svom NATS JetStream configuration")
        # Declare default Svom configuration
        js_config = {
            "stream_test": {
                "name": "test",
                "subjects": ["test"],
                "retention": "limits",
                "max_consumers": -1,
                "max_msgs": -1,
                "max_bytes": -1,
                "max_age": 31536000000000000,
                "max_msg_size": -1,
                "storage": "file",
                "discard": "old",
                "num_replicas": 1,
                "duplicate_window": 120000000000,
            },
            "stream_data": {
                "name": "data",
                "subjects": [
                    "data.vhf",
                    "data.vhfba",
                    "data.sdb",
                    "data.xband",
                    "data.voeventdb",
                ],
                "retention": "limits",
                "max_consumers": -1,
                "max_msgs": -1,
                "max_bytes": -1,
                "max_age": 31536000000000000,
                "max_msg_size": -1,
                "storage": "file",
                "discard": "old",
                "num_replicas": 1,
                "duplicate_window": 120000000000,
            },
            "stream_activity": {
                "name": "activity",
                "subjects": [
                    "activity.infrastructure",
                    "activity.calibration",
                    "activity.core_program",
                    "activity.general_program",
                    "activity.too",
                ],
                "retention": "limits",
                "max_consumers": -1,
                "max_msgs": -1,
                "max_bytes": -1,
                "max_age": 31536000000000000,
                "max_msg_size": -1,
                "storage": "file",
                "discard": "old",
                "num_replicas": 1,
                "duplicate_window": 120000000000,
            },
            "stream_science": {
                "name": "science",
                "subjects": [
                    "science.calibration",
                    "science.core_program",
                    "science.general_program",
                    "science.too",
                ],
                "retention": "limits",
                "max_consumers": -1,
                "max_msgs": -1,
                "max_bytes": -1,
                "max_age": 31536000000000000,
                "max_msg_size": -1,
                "storage": "file",
                "discard": "old",
                "num_replicas": 1,
                "duplicate_window": 120000000000,
            },
        }

    # Retrieve nats_client and channels list from environment variables
    nats_client = jetstreamio_from_env(streaming_id="admin")

    # Apply config
    failures = 0
    for entry, conf in js_config.items():
        if entry.startswith("stream_"):
            resp = nats_client.create_or_update_stream(**conf)
            if resp is None or b"error" in resp.data:
                log.error("Stream '%s' creation failed.", conf.get("name"))
                failures += 1
        elif entry.startswith("consumer_"):
            resp = nats_client.create_or_update_consumer(**conf)
            if resp is None or b"error" in resp.data:
                log.error("Consumer '%s' creation failed.", conf.get("name"))
                failures += 1
        else:
            log.error("JSON config file keys should start with 'stream_' or 'consumer_'")
            raise ValueError("Unhandled key in JSON config file")

    # gracefully stop NATS client
    nats_client.stop()

    # exit with 1 if failures were met
    if failures > 0:
        log.error(
            "%s errors in JetStream configuration attempt. Exiting with status 1",
            failures,
        )
        sys.exit(1)


if __name__ == "__main__":
    main()
