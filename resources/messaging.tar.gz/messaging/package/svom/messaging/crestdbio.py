"""
HTTP client tool to exchange with VHF-PKT-DB

Retries requests with power law delays and a max tries limit

@author: henri.louvin@cea.fr
"""

# Log
import logging

# Files management
from contextlib import ExitStack

# JSON
import json

from svom.messaging.httpio import HttpIo
from svom.messaging.utils import get_crestdb_url

log = logging.getLogger("crestdb_client")


def check_kwargs_validity(kwargs, valid_keys):
    """
    check if all keys in {kwargs} dict are in {valid_keys} list
    """
    for key in kwargs:
        if key not in valid_keys:
            log.error("%s is not in the valid arguments list: %s", key, valid_keys)


def build_params(kwargs):
    """
    create a dict of parameters from svom.messaging.kwargs} dict
    """
    criteria = {}
    for key in kwargs:
        criteria[key] = kwargs[key]
    return criteria


def print_criteria(criteria):
    """Log the criteria search

    Parameters
    ----------
    criteria : str
        criteria string
    """
    log.debug("Use criteria %s", criteria)


class CrestDbIo(HttpIo):
    """(A)synchronous HTTP client with the Crest Database.

    Parameters
    ----------
    server_url :  str, optional
        root server url share by all the endpoints
    max_tries : int, optional
        Number of connection attemps
    asynchronous : bool, optional
        True if asynchronous communication
    loop : optional
        asyncio event loop to use if asynchronous is True. If none, start one.
    use_tokens : bool, optional
        True if Authorization token has to be used
    tokens : dict, optional
        if not None, these tokens will be used instead of requesting keycloak,
        except if the tokens is not valid anymore.
    """

    def __init__(
        self,
        server_url="https://fsc.svom.org/crestdb",
        max_tries=1,
        # pylint: disable=R0913
        asynchronous=False,
        loop=None,
        use_tokens=True,
        tokens=None,
    ):
        server_url = get_crestdb_url(server_url)
        super().__init__(
            server_url,
            max_tries=max_tries,
            asynchronous=asynchronous,
            loop=loop,
            use_tokens=use_tokens,
            tokens=tokens,
        )
        self.endpoints = {
            "tags": "/api/tags",
            "iovs": "/api/iovs",
            "payloads": "/api/payloads",
            "globaltags": "/api/globaltags",
            "monitoring": "/api/monitoring",
            "maps": "/api/globaltagmaps",
        }

        self.headers = {
            "Content-Type": "application/json",
            "Accept": "application/json",
        }
        self.crest_headers = {"X-Crest-PayloadFormat": "BLOB"}

    def set_header(self, hdr):
        """Set {hdr} as self.crest_headers

        Parameters
        ----------
        hdr : dict
            Pair key-value to add to self.crest_headers
        """
        # example : {"X-Crest-PayloadFormat" : "JSON"}
        for key, value in hdr.items():
            self.crest_headers[key] = value

    def build_header(self, hdr=None):
        """Append {hdr} to self.headers

        Parameters
        ----------
        hdr : dict, optional
            Pari key-value to add to self.crest_headers
        """
        # make sure empty dict is created within method
        if hdr is None:
            hdr = {}
        # example : {"X-Crest-PayloadFormat" : "JSON"}
        hdr.update(self.headers)
        hdr.update(self.crest_headers)
        return hdr

    def search_tags(self, page=0, size=100, sort="name:ASC", **kwargs):
        """Request and export tags (IOV container) from svom.messaging.he database in json format

        *Addtional valid filters for the request in kwargs: name, pauloadspec,
        timetype.*

        usage example:

        ::

            search_tags(name="SVOM", payloadspec=JSON)
            ?by=name:SVOM,payloadspec:JSON”.

        Parameters
        ----------
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        kwargs: dict
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Crest DB response
        """
        # define output fields and check request validity
        check_kwargs_validity(kwargs, ["name", "payloadspec", "timetype"])

        # prepare request arguments
        criteria = build_params(kwargs)
        print_criteria(criteria)
        criteria["page"] = page
        criteria["size"] = size
        criteria["sort"] = sort
        loc_headers = self.build_header()
        # send request
        resp = self.get(self.endpoints["tags"], params=criteria, headers=loc_headers)
        return resp

    def search_maps(self, name=None, mode="Trace"):
        """Request and export maps from svom.messaging.he database in json format

        usage example:

        ::

            search_maps(name="A-GT-OR-T-NAME")

        Parameters
        ----------
        mode : str, optional
            trace|backtrace
        name : str, optional
            if mode is trace, then this represents a GT name, otherwise is a
            Tag name

        Returns
        -------
        resp : `requests.models.Response`
            Crest DB response
        """
        # prepare headers
        map_header = {"X-Crest-MapMode": mode}
        # send request
        loc_headers = self.build_header(hdr=map_header)

        resp = self.get(self.endpoints["maps"] + f"/{name}", headers=loc_headers)
        return resp

    def search_globaltags(self, page=0, size=100, sort="name:ASC", **kwargs):
        """request and export global tags from svom.messaging.he database in json format

        *Addtional valid filters for the request in kwargs: name, scenario, release,
        workflow.*

        usage example:

        ::

            search_globaltags(name="SVOM").

        Parameters
        ----------
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        kwargs: dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Crest DB response
        """
        # define output fields and check request validity
        check_kwargs_validity(kwargs, ["name", "scenario", "release", "workflow"])

        criteria = build_params(kwargs)
        print_criteria(criteria)
        criteria["page"] = page
        criteria["size"] = size
        criteria["sort"] = sort
        loc_headers = self.build_header()

        # send request
        resp = self.get(self.endpoints["globaltags"], params=criteria, headers=loc_headers)
        return resp

    def search_iovs(self, page=0, size=100, sort="id.since:ASC", tagname=None, **kwargs):
        """Request and export iovs (Interval Of Validit) from svom.messaging.he database in json
        format.

        *Addtional valid filters for the request in kwargs: insertionTime, time.*

        usage example:

        ::

            search_iovs(tagname="SVOM", insertionTime="1574429040079")

        Parameters
        ----------
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        tagname : str, optional
            the tag name corresponding to the type of payload.
        kwargs: dict, optional
            additional parameters given for the request. Should be in
            valid_filters. Some of them are: method, since, until.
            Method param can be [IOVS] (default) or GROUPS.
            This will decide how the query is performed.
            Since and until are the time range for the query.
            They are ignored if method is GROUPS.

        Returns
        -------
        resp : `requests.models.Response`
            Crest DB response
        """
        # define output fields and check request validity
        check_kwargs_validity(
            kwargs,
            ["method", "since", "until", "snapshot", "timeformat", "groupsize", "hash"],
        )

        criteria = build_params(kwargs)
        criteria["tagname"] = tagname
        if "method" not in criteria:
            criteria["method"] = "IOVS"

        print_criteria(criteria)
        criteria["page"] = page
        criteria["size"] = size
        criteria["sort"] = sort
        loc_headers = self.build_header()

        log.info("Iov search request using %s", criteria)

        # send request
        resp = None
        if criteria["method"] == "INFO":
            resp = self.get(self.endpoints["iovs"] + "/infos", params=criteria, headers=loc_headers)
        else:
            resp = self.get(self.endpoints["iovs"], params=criteria, headers=loc_headers)
        return resp

    def get_tag_size(self, tagname):
        """Get the size of a tag.
        Find number of IOVs in a tag.

        Parameters
        ----------
        tagname : str
            the tag name corresponding to the type of payload.

        Returns
        -------
        resp : `requests.models.Response`
            Crest DB response
        """
        loc_headers = self.build_header()
        criteria = {"tagname": tagname}
        log.info("Tag size request using %s", criteria)
        # send request
        resp = self.get(self.endpoints["iovs"] + "/size", params=criteria, headers=loc_headers)
        return resp

    def create_tags(self, name=None, mode="create", **kwargs):
        """Create a new tag.

        *extra upload argument in kwargs: payloadSpec, timeType, description,
        synchronization.*

        usage example:

            create_tags(name="SVOM-01", payloadSpec="JSON",
            timeType="time",description="a tag",synchronization="none")

        Parameters
        ----------
        name : str, optional
            name of the tag.
        mode : str, optional
            in which mode to upload the new tag.
        kwargs: dict, optional
            extra upload argument. Should be in valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Crest DB response
        """
        # define output fields and check request validity
        check_kwargs_validity(kwargs, ["payloadSpec", "timeType", "description", "synchronization"])

        # prepare request arguments
        body_req = {
            "name": name,
            "payloadSpec": "JSON",
            "timeType": "time",
            "description": "a new tag",
            "synchronization": "none",
            "lastValidatedTime": 0,
            "endOfValidity": 0,
            "insertionTime": None,
            "modificationTime": None,
        }
        for key, val in kwargs.items():
            body_req[key] = val
        log.info("Create tag : %s", json.dumps(body_req))
        loc_headers = self.build_header()
        log.info("create tags: use header %s", loc_headers)
        # send request
        if "create" == mode:
            resp = self.post(self.endpoints["tags"], json=body_req, headers=loc_headers)
        elif "update" == mode:
            resp = self.put(self.endpoints["tags"] + f"/{name}", json=body_req, headers=loc_headers)
        return resp

    def create_maps(self, tag=None, globaltag=None, record=None, label=None):
        """Create a mapping entry, associating a Tag to an existing GlobalTag.

        usage example:

            create_maps(tag="MXT-CONFIG-01", globaltag="SVOM-01",
            record="ok",label="mxt-config")

        Parameters
        ----------
        tag : str, optional
            Name of the tag for the maps
        globaltag : str, optional
            global tag name
        record : str, optional
        label : str

        Returns
        -------
        resp : `requests.models.Response`
            Crest DB response
        """
        # prepare request arguments
        body_req = {
            "globalTagName": globaltag,
            "record": record,
            "label": label,
            "tagName": tag,
        }
        log.info("Create mapping : %s", json.dumps(body_req))
        loc_headers = self.build_header()

        # send request
        resp = self.post(self.endpoints["maps"], json=body_req, headers=loc_headers)
        return resp

    def create_iovs(self, name, since, phash, **kwargs):
        """Create one IOV (the payloads should already exists)

        *extra upload argument in kwargs: insertionTime*

        usage example:

        ::

            create_iovs(name="SVOM-01", phash="somehash", since=1000)

        Parameters
        ----------
        name : str, required
            Name of the tag for the maps
        since : str, required
            time validity
        phash : str, required
            payload hash
        kwargs: dict, optional
            extra upload argument. Should be in valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Crest DB response
        """
        # define output fields and check request validity
        check_kwargs_validity(kwargs, ["insertionTime"])

        # prepare request arguments
        body_req = {
            "tagName": name,
            "since": since,
            "payloadHash": phash,
            "insertionTime": None,
        }
        loc_headers = self.build_header()

        for key, val in kwargs.items():
            body_req[key] = val
        log.info("Create iov if the hash is known : %s", json.dumps(body_req))
        # send request
        resp = self.put(self.endpoints["iovs"], json=body_req, headers=loc_headers)
        return resp

    def create_iov_set(self, name, iovset):
        """Create one or a list of IOVs (the payloads should already exists)

        *extra upload argument in kwargs: insertionTime*

        usage example:

        ::

            create_iov_set(name="SVOM-01", iovset={"size": 1, "format":"IovSetDto",
                "resources":[{"since":1000, "payloadHash":"somehash"}]})

        Parameters
        ----------
        name : str, required
            Name of the tag
        iovset: dict, required
            The dictionary containing the IOV set to be uploaded

        Returns
        -------
        resp : `requests.models.Response`
            Crest DB response
        """
        # prepare request arguments
        loc_headers = self.build_header()
        iovs = iovset["resources"]
        for iov in iovs:
            iov["tagName"] = name
        log.info("Create iov set : %s", json.dumps(iovset))
        # send request
        resp = self.post(self.endpoints["iovs"], json=iovset, headers=loc_headers)
        return resp

    def create_globaltags(self, name=None, **kwargs):
        """Create a new global tag.

        *extra upload argument in kwargs: validity, description, type,
        release, scenario, workflow, snapshotTime.*

        usage example:

        ::

            create_globaltags(name="GT-SVOM-01", validity=0,
            description="some gt",release="a release",scenario="none",workflow="onl",
            type="T",snapshotTime="2020-01-01T10:00:00")

        Parameters
        ----------
        name : str, optional
            Name of the tag for the maps
        kwargs: dict, optional
            extra upload argument. Should be in valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            Crest DB response
        """
        # define output fields and check request validity
        check_kwargs_validity(
            kwargs,
            [
                "validity",
                "description",
                "type",
                "release",
                "scenario",
                "workflow",
                "snapshotTime",
            ],
        )

        # prepare request arguments
        body_req = {
            "name": name,
            "release": "none",
            "type": "T",
            "description": "a new gtag",
            "scenario": "none",
            "validity": 0,
            "workflow": "all",
            "snapshotTime": None,
            "insertionTime": None,
        }
        for key, val in kwargs.items():
            body_req[key] = val
        log.info("Create global tag : %s", json.dumps(body_req))
        loc_headers = self.build_header()

        # send request
        resp = self.post(self.endpoints["globaltags"], json=body_req, headers=loc_headers)
        return resp

    def create_payload(self, tag_name, payloadset, payload_format="FILE", **kwargs):
        """Import payload set into the database.

        The payload set should be a dictionary containing a list of payloads.

        usage example:
        ::
            create_payload(payloadset={"size": 1, "format":"StoreSetDto",
                "resources":[{hash":"none", "data":"somecontent", "since" 10,
                "streamerInfo":"{someinfo}"}]}, payload_format="JSON")

            create_payload(payloadset={"size": 1, "format":"StoreSetDto",
                "resources":[{hash":"none", "data":"file://pathtofile", "since": 10,
                "streamerInfo":"{someinfo}"}}])

        Parameters
        ----------
        tag_name : str, required
            Name of the tag in which the payload will be uploaded.
        payloadset: dict, required
            The list of payloads.
        payload_format : str, optional
            Define if the payload is a file or a JSON encoded string. Default FILE.
        kwargs: dict, optional
            extra upload argument. Should be in valid_filters. Among them you can specify the:
            - objectType : this will be used to define the output
                format of the payload (mime-type). Default txt.
            - compressionType : this will be used to define the compression type
                of the payload. Default none.
            - version : this will be used to define the version of the payload. Default 1.

        Returns
        -------
        resp : `requests.models.Response`
            Crest DB response
        """
        # define output fields and check request validity
        check_kwargs_validity(kwargs, ["objectType", "compressionType", "version", "endtime"])
        files = [
            ("tag", (None, tag_name)),
            ("storeset", (None, json.dumps(payloadset)))
            #        ("files", open("/tmp/test-01.txt", "rb")),
            #        ("files", open("/tmp/test-02.txt", "rb")),
        ]
        for key, val in kwargs.items():
            files.append((key, (None, str(val))))
        if "objectType" not in kwargs:
            files.append(("objectType", (None, "JSON")))
        if "compressionType" not in kwargs:
            files.append(("compressionType", (None, "none")))

        # prepare request response
        resp = None
        # prepare request header
        loc_headers = {"X-Crest-PayloadFormat": payload_format}
        if "authorization" in self.headers:
            loc_headers["authorization"] = self.headers["authorization"]
        log.info("store payload utilizes header : %s", loc_headers)
        # prepare request arguments
        with ExitStack() as stack:
            if payload_format == "FILE":
                for pentry in payloadset["resources"]:
                    fname = pentry["data"]
                    if "file://" in fname:
                        fname = fname.replace("file://", "")
                    files.append(("files", stack.enter_context(open(fname, "rb"))))
                    log.info("Add file : %s", fname)
            log.info("Create payload to upload: %s", files)
            # send request
            resp = self.post(self.endpoints["payloads"], files=files, headers=loc_headers)
        return resp

    def get_payload(self, phash, fout="./out.blob", fmt="BLOB"):
        """Retrieve payload data from svom.messaging.he database

        usage example:

        ::

            get_payload(phash=somehash,fout="/tmp/out.blob")

        Parameters
        ----------
        phash : str, required
            payload phash
        fout : str, optional
            file name where to dump the DB request. Default ./out.blob
        fmt : the format of the output payload:
            BLOB means the payload itself,
            META indicates only metadata,
            and STREAMER is to get only streamerInfo field. Default BLOB.

        Returns
        -------
        resp.json() : `requests.models.Response` or str
            Crest DB response or filename of the files where the payload content was written
        """
        # prepare request arguments
        log.info("Get payload by hash: %s", phash)
        # send request
        loc_url = self.endpoints["payloads"] + "/" + phash
        loc_headers = self.build_header()
        criteria = {"format": fmt}
        resp = self.get(loc_url, params=criteria, headers=loc_headers)
        # If the HTTP GET request can be served
        if resp.status_code == 200:
            # Write the file contents in the response to a file specified by local_file_path
            if fmt != "META":
                with open(fout, "wb") as local_file:
                    for chunk in resp.iter_content(chunk_size=128):
                        local_file.write(chunk)
            else:
                fout = resp
        return fout

    def update_streamer(self, phash, streamer_info):
        """Create a new global tag.

        *extra upload argument in kwargs: validity, description, type,
        release, scenario, workflow, snapshotTime.*

        usage example:

        ::

            update_streamer(phash="mypayloadhash", streamerInfo={"streamerInfo": "some info"})

        Parameters
        ----------
        phash : str, required
            hash of the payload to update
        streamer_info: dict, required
            The new streamerInfo to update the payload with.

        Returns
        -------
        resp : `requests.models.Response`
            Crest DB response
        """

        # prepare request arguments
        log.info("Update streamer info for payload using: %s", json.dumps(streamer_info))
        loc_headers = self.build_header()
        loc_url = self.endpoints["payloads"] + "/" + phash

        # send request
        resp = self.put(loc_url, json=streamer_info, headers=loc_headers)
        return resp
