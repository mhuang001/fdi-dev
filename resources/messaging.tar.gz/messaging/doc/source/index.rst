.. Messaging documentation master file, created by
   sphinx-quickstart on Tue Mar  2 21:49:53 2021.
   You can adapt this file completely to your liking, but it should at least
   contain the root `toctree` directive.

***********************************
Welcome to Messaging documentation!
***********************************

This doc presents the different messaging project functionalities. The project manages the tools and configuration for
messages transfer with *Nats client* and *Mqtt client*. The python module also include multitude of classes with specific
methods to simplify the interaction with the different databases of the FSC.

.. toctree::
    :caption: User Guide
    :maxdepth: 1

    installation/index
    messaging_system/index
    db_communication/index
    authentification/index
    dockerisation/index


Modules
********

Below are listed the different modules of the messaging package. Click below to have
more information on the API on each package:

.. toctree::
    :maxdepth: 1

    modules/index


Indices and tables
******************

* :ref:`genindex`
* :ref:`modindex`
* :ref:`search`

*Code licensed CeCILL.*