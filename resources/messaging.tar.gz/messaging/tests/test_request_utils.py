"""
Request utils test file
"""
import os
import sys

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
import package.svom.messaging.request_utils as request_utils


def test_kwargs_are_valid():
    valid_keys=["color", "size"]
    resp = request_utils.kwargs_are_valid(valid_keys=valid_keys, kwargs={"marker" : "point"})
    assert resp is False
    resp = request_utils.kwargs_are_valid(valid_keys=valid_keys, kwargs={"color" : "blue"})
    assert resp is True

