"""
XbandDbIo test file
"""
import logging
import os
import io
import sys
import types
from unittest import mock
from requests import Response
import pytest

# make sure the svom.messaging used is the local one (for coverage)
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), "../"))
sys.path.insert(0, BASE_DIR)
from package.svom.messaging.xbanddbio import XBandDbIo

log = logging.getLogger("test_xbandio")
logging.basicConfig(
    stream=sys.stdout,
    level=logging.INFO,
    format="%(asctime)s %(levelname)s [%(name)s] %(message)s",
)

HTTPIO_REQUEST = "package.svom.messaging.httpio.requests.Session.request"


@pytest.fixture
# mock a response 200
def sync_200_response():
    """mimics 'requests' success response"""
    fake_response = Response()
    fake_response.status_code = 200
    fake_response.json = lambda: {"breakfast": "eggs"}
    return fake_response


@pytest.fixture(scope="module")
# mock the autentification
def xband_client():
    """return sync VhfDbIos"""
    # with mock.patch('svom.messaging.tokens.KcTokens._request_tokens'):
    sync_client = XBandDbIo(
        "fake://xband-l0c", "fake://xband-packets", use_tokens=False
    )
    yield sync_client


def test_init():
    """Check that the use_tokens param is correctly passed to super()"""

    os.environ["KC_TYPE"] = "pipelines"
    client = XBandDbIo()
    assert client.kc_tokens is not None
    assert client.kc_tokens.tokens_with_expirations_dates is None


def test_init_url_none():
    """Test init url"""
    # with mock.patch('svom.messaging.tokens.KcTokens._request_tokens'):
    sync_client = XBandDbIo(use_tokens=False)
    assert sync_client.endpoints["apids"] == "https://fsc.svom.org/xbsvc_lc/api/apids"
    assert (
        sync_client.endpoints["packets"]
        == "https://fsc.svom.org/xbsvc_packets/api/packets"
    )


def test_search(
    xband_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test XBAND-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test invalid kwargs management
        response = xband_client.search(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        xband_client.search(apid=20)
        xband_client.search(packetid=1, obsidnum=20)
        xband_client.search(
            packettimefrom="2017-08-01T11:45:45+02:00",
            packettimeto="2017-08-01T12:45:45+02:00",
            timeformat="iso",
        )
        # requests.get should have been called 2 times
        expected_calls = [
            mock.call(
                "GET",
                "fake://xband-packets/api/frames",
                params={
                    "apid": 20,
                    "page": 0,
                    "size": 100,
                    "sort": "pktOrder:ASC",
                },
            ),
            mock.call(
                "GET",
                "fake://xband-packets/api/frames",
                params={
                    "packetid": 1,
                    "obsidnum": 20,
                    "page": 0,
                    "size": 100,
                    "sort": "pktOrder:ASC",
                },
            ),
            mock.call(
                "GET",
                "fake://xband-packets/api/frames",
                params={
                    "packettimefrom": "20170801T094545UTC",
                    "packettimeto": "20170801T104545UTC",
                    "timeformat": "iso",
                    "page": 0,
                    "size": 100,
                    "sort": "pktOrder:ASC",
                },
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_search_apid_info(
    xband_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test XBAND-DB search_apids"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        mocked.assert_not_called()
        response = xband_client.search_apid_info(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        xband_client.search_apid_info(pass_id="1_KR000")
        # requests.get should have been called 3 times
        expected_calls = [
            mock.call(
                "GET",
                "fake://xband-l0c/api/apids",
                params={
                    "pass_id": "1_KR000",
                    "page": 0,
                    "size": 100,
                    "sort": "apidValue:ASC",
                },
            )
        ]

        assert mocked.mock_calls == expected_calls


def test_search_obs_id_info_by_passid(
    xband_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test XBAND-DB search_apids"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        mocked.assert_not_called()
        xband_client.search_obs_id_info_by_passid(pass_id="1_KR000")
        xband_client.search_obs_id_info_by_passid(pass_id="1_KR000", apid=1617)
        # requests.get should have been called 3 times
        expected_calls = [
            mock.call(
                "GET",
                "fake://xband-l0c/api/lc/dat/view",
                params={
                    "pass_id": "1_KR000",
                },
            ),
            mock.call(
                "GET",
                "fake://xband-l0c/api/lc/dat/view",
                params={
                    "pass_id": "1_KR000",
                    "apid": 1617,
                },
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_search_apid_info_by_passid(
    xband_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test XBAND-DB search_apids"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        mocked.assert_not_called()
        xband_client.search_apid_info_by_passid(pass_id="1_KR000")
        # requests.get should have been called 3 times
        expected_calls = [
            mock.call(
                "GET",
                "fake://xband-l0c/api/lc/dat/view",
                params={"pass_id": "1_KR000", "field": "apid"},
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_search_lc(
    xband_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test XBAND-DB search_apids"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        mocked.assert_not_called()
        response = xband_client.search_lc(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        xband_client.search_lc(apid=42)
        xband_client.search_lc(pass_id="00044_KP00M")
        xband_client.search_lc(file_type="dat", apid=42)
        xband_client.search_lc(file_type="dat", endtime=42)
        xband_client.search(
            packettimefrom="2017-08-01T11:45:45+02:00",
            packettimeto="2017-08-01T12:45:45+02:00",
            timeformat="iso",
        )
        # requests.get should have been called 2 times
        expected_calls = [
            mock.call(
                "GET",
                "fake://xband-l0c/api/lc/tar",
                params={"apid": 42, "page": 0, "size": 100, "sort": "tarName:ASC"},
            ),
            mock.call(
                "GET",
                "fake://xband-l0c/api/lc/tar",
                params={
                    "station": "KP00M",
                    "orbit": "00044",
                    "page": 0,
                    "size": 100,
                    "sort": "tarName:ASC",
                },
            ),
            mock.call(
                "GET",
                "fake://xband-l0c/api/lc/dat",
                params={"apid": 42, "page": 0, "size": 100, "sort": "lcfileName:ASC"},
            ),
            mock.call(
                "GET",
                "fake://xband-l0c/api/lc/dat",
                params={
                    "endtime": 42,
                    "page": 0,
                    "size": 100,
                    "sort": "lcfileName:ASC",
                },
            ),
            mock.call(
                "GET",
                "fake://xband-packets/api/frames",
                params={
                    "packettimefrom": "20170801T094545UTC",
                    "packettimeto": "20170801T104545UTC",
                    "timeformat": "iso",
                    "page": 0,
                    "size": 100,
                    "sort": "pktOrder:ASC",
                },
            ),
        ]

        assert mocked.mock_calls == expected_calls


def test_search_passids(
    xband_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test XBAND-DB search_apids"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        mocked.assert_not_called()
        response = xband_client.search_pass_ids(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        # test with valid kwargs
        xband_client.search_pass_ids(station="LOLO")
        # requests.get should have been called 2 times
        expected_calls = [
            mock.call(
                "GET",
                "fake://xband-l0c/api/lc/passids",
                params={
                    "station": "LOLO",
                    "page": 0,
                    "size": 100,
                    "sort": "pktOrder:ASC",
                },
            ),
        ]

        assert mocked.mock_calls == expected_calls


def test_download(
    xband_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test XBAND-DB search_apids"""
    # get to work
    open_mock = mock.mock_open()
    with mock.patch("builtins.open", open_mock, create=True):
        with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
            mocked.return_value.raw = types.SimpleNamespace()
            mocked.return_value.raw.stream = lambda x, decode_content: "thisisdata"
            mocked.assert_not_called()
            xband_client.download_l0c_file(lcfilename="dummy_filename")

            expected_calls = [
                mock.call(
                    "GET", "fake://xband-l0c/api/lc/dat/dummy_filename", stream=True
                ),
            ]

            assert mocked.mock_calls == expected_calls


def test_dump_packets(
    xband_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test XBAND-DB search_apids"""
    # get to work
    open_mock = mock.mock_open()
    with mock.patch("builtins.open", open_mock, create=True):
        with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
            mocked.return_value.raw = types.SimpleNamespace()
            mocked.return_value.raw.stream = lambda x, decode_content: "thisisdata"
            mocked.assert_not_called()
            xband_client.dump_packets(
                fout="out2.blob", pass_id="lulu_lala", apid=45, obsid=123, packetid=43
            )

            expected_calls = [
                mock.call(
                    "GET",
                    "fake://xband-packets/api/packets",
                    params={
                        "apid": 45,
                        "obsid": 123,
                        "packetid": 43,
                        "station": "lala",
                        "orbit": "lulu",
                        "obsid": 123,
                        "packetid": 43,
                    },
                ),
            ]

            assert mocked.mock_calls == expected_calls


def test_dump_packets_by_time(
    xband_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test XBAND-DB search_apids"""
    # get to work
    open_mock = mock.mock_open()
    with mock.patch("builtins.open", open_mock, create=True):
        with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
            mocked.return_value.raw = types.SimpleNamespace()
            mocked.return_value.raw.stream = lambda x, decode_content: "thisisdata"
            mocked.assert_not_called()
            xband_client.dump_packets_by_time(
                fout="out2.blob", since=3, until=4, apid=45, obsid=123, packetid=43
            )
            expected_calls = [
                mock.call(
                    "GET",
                    "fake://xband-packets/api/packets",
                    params={
                        "apid": 45,
                        "obsid": 123,
                        "packetid": 43,
                        "since": 3,
                        "until": 4,
                        "obsid": 123,
                        "packetid": 43,
                    },
                ),
            ]

            assert mocked.mock_calls == expected_calls

            with pytest.raises(
                ValueError,
                match="The maximum duration between since and until is 12 hours",
            ):
                # Until more than 12 hours after since
                xband_client.dump_packets_by_time(
                    fout="out2.blob",
                    since=3,
                    until=4 + 43200,
                    apid=45,
                    obsid=123,
                    packetid=43,
                )


def test_upload(
    tmp_path, xband_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test XBAND-DB search by apid,apidName,obsid"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        # test with valid kwargs
        filepath = str(tmp_path / "test.dat")
        os.system(f"touch {filepath}")
        xband_client.upload(filepath=filepath)

        calls = mocked.call_args
        assert calls[0] == ("POST", "fake://xband-l0c/api/lc/tar")

        files_arg = calls[1]["data"].fields["file"]
        assert files_arg[0] == "test.dat"
        assert isinstance(files_arg[1], io.BufferedReader)
        lc_filename = calls[1]["data"].fields["lcFileName"]
        assert lc_filename[1] == "test.dat"


def test_get_upload_status(xband_client, sync_200_response):
    """test XBAND-DB get_upload_status"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        mocked.assert_not_called()
        response = xband_client.get_upload_status(bad_key="bad")
        mocked.assert_not_called()
        assert response == {}
        xband_client.get_upload_status(tarfilename="lolo.tar")
        # requests.get should have been called 3 times
        expected_calls = [
            mock.call(
                "GET",
                "fake://xband-l0c/api/lc/dat/status",
                params={
                    "tarfilename": "lolo.tar",
                },
            ),
        ]
        assert mocked.mock_calls == expected_calls


def test_delete(
    xband_client, sync_200_response
):  # pylint: disable=redefined-outer-name
    """test XBAND-DB delete"""
    with mock.patch(HTTPIO_REQUEST, return_value=sync_200_response) as mocked:
        mocked.assert_not_called()
        # test with valid kwargs
        filename = "test.dat"
        xband_client.delete_datfile(filename=filename)
        mocked.assert_called_once_with(
            "DELETE",
            "fake://xband-packets/api/frames",
            params={"lcFileName": "test.dat"},
        )
