#! /usr/scripts/env package3
# coding: utf-8
"""
A NatsIo argument parser. Ease the utilisation of the NatsIo client

Created on 01/2019
@author: nicolasdeparis
"""
import logging
import os
from get_docker_secret import get_docker_secret

from svom.messaging.jetstreamio import JetStreamIo

log = logging.getLogger("nats_connector")

# Default values
DEFAULT_HOST = "nats"
DEFAULT_PORT = "5522"
DEFAULT_USER = None
DEFAULT_DOCKER_SECRET = "nats_password"
DEFAULT_STREAMING_ID = None


class NatsConnector:
    """
    Use JetStreamIo to connect to a NATS server.

    Use authentification if a user is provided. The 'config' argument is a dictionnary with
    following optionnal keys:

        * host
        * port
        * user
        * password
        * docker_secret
        * streaming_id

    `host` and `port` define the NATS server url, values are checked in
    environment variable, config dictionnary and default values, in this order.

    `cluster`, `user` and `streaming_id` are checked in config dictionnary
    and default values, in this order.

    `password` is checked only if `user` is provided, value is checked
    environment variable, docker secret, and config dictionnary in this order.
    'password' has no default value

    Check the __main__ section at the end of this file for usage example.
    """

    def __init__(self, config):
        self.get_config(config)
        self.get_host(config)
        self.get_port(config)

        if self.need_authentification():
            self.get_password(config)

    def get_config(self, config):
        """Look for configuration in argument, else use default values."""
        self.config = {}

        self.config["user"] = config.get("user", DEFAULT_USER)
        self.config["streaming_id"] = config.get("streaming_id", DEFAULT_STREAMING_ID)

        if "NATS_USER" in os.environ:
            self.config["user"] = os.environ.get("NATS_USER")

    def get_host(self, config):
        """Set HOST of the NATS server

        * Check from svom.messaging.nvironment variables.
        * Use argument values if not present.
        * Use default values if not present.
        """
        if "NATS_SERVER_HOST" in os.environ:
            self.config["host"] = os.environ["NATS_SERVER_HOST"]
            log.info(
                "Using host from svom.messaging.nvironment variable NATS_SERVER_HOST : %s",
                self.config["host"],
            )
        elif "NATS_HOST" in os.environ:
            self.config["host"] = os.environ["NATS_HOST"]
            log.info(
                "Using host from svom.messaging.nvironment variable NATS_HOST : %s",
                self.config["host"],
            )
        elif "host" in config:
            self.config["host"] = config["host"]
            log.info("Using host from svom.messaging.unction argument : %s", self.config["host"])
        else:
            self.config["host"] = DEFAULT_HOST
            log.info("Using default host : %s", self.config["host"])

    def get_port(self, config):
        """Set PORT of the NATS server.

        * Check from svom.messaging.nvironment variables.
        * Use argument values if not present.
        * Use default values if not present.
        """
        if "NATS_SERVER_PORT" in os.environ:
            self.config["port"] = os.environ["NATS_SERVER_PORT"]
            log.info(
                "Using port from svom.messaging.nvironment variable NATS_SERVER_PORT : %s",
                self.config["port"],
            )
        elif "NATS_PORT" in os.environ:
            self.config["port"] = os.environ["NATS_PORT"]
            log.info(
                "Using port from svom.messaging.nvironment variable NATS_PORT : %s",
                self.config["port"],
            )
        elif "port" in config:
            self.config["port"] = config["port"]
            log.info("Using port from svom.messaging.unction argument : %s", self.config["port"])
        else:
            self.config["port"] = DEFAULT_PORT
            log.info("Using default port : %s", self.config["port"])

    def get_password(self, config):
        """Check for NATS password in this order :

            * environment variable
            * argument function
            * docker secret
            * default value

        assert passwort is not None at the end
        """
        if "NATS_PASSWORD" in os.environ:
            self.config["password"] = os.environ["NATS_PASSWORD"]
            log.info("Using password from svom.messaging.ATS_PASSWORD variable")
        else:
            log.info("No NATS password found in NATS_PASSWORD environment variable")
            password = self.get_password_from_docker_secret(config)
            if password is not None:
                self.config["password"] = password
                log.info("Using password from svom.messaging.ocker secret")
            elif "password" in config.keys() and config["password"] is not None:
                log.info("No NATS password found in docker secret")
                self.config["password"] = config["password"]
                log.info("Using password from svom.messaging.unction argument")
            else:
                log.info("No NATS password found in docker secret")
                log.info("No NATS password found in function argument")

        if self.config.get("password") is None:
            err_msg = (
                "Something went wrong while getting the NATS password: "
                "NATS password is still None while a user is set"
            )
            raise RuntimeError(err_msg)

    def get_password_from_docker_secret(self, config):
        """Get password from svom.messaging.ocker secret"""
        secret = ""
        if "NATS_PWD_SECRET" in os.environ:
            secret = os.environ.get("NATS_PWD_SECRET")
        else:
            secret = config.get("docker_secret", DEFAULT_DOCKER_SECRET)
        password = get_docker_secret(secret, secrets_dir="/run/secrets")
        if password is not None:
            password = password.strip()
        return password

    def need_authentification(self):
        """Authentification needed if a user is defined."""
        return self.config["user"] is not None

    def get(self):
        """Connect to NATS server with or without authentification.

        Returns
        -------
        client : `src.jetstreamio.JetStreamIo`
             JetStreamIo object
        """
        config = self.config

        if self.need_authentification():
            log.info("Connecting to NATS with user : %s", config["user"])
            client = JetStreamIo(
                config["host"],
                config["port"],
                streaming_id=config["streaming_id"],
                user=config["user"],
                password=config["password"],
            )
        else:
            log.info("Connecting to NATS without authentification")
            client = JetStreamIo(
                config["host"], config["port"], streaming_id=config["streaming_id"]
            )

        return client


def main():
    """Utilisation example"""
    config = {}
    config["host"] = "svomtest.svom.fr"
    config["port"] = "5522"
    config["user"] = "svom"
    config["streaming_id"] = "my-module"
    client = NatsConnector(config).get()
    client.stop()


if __name__ == "__main__":
    main()
