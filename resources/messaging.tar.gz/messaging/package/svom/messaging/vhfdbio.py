"""
HTTP client tool to exchange with VHF-PKT-DB

Retries requests with power law delays and a max tries limit

@author: henri.louvin@cea.fr
"""

# Log
import datetime
import logging

# JSON
import json

# time zone
import pytz

from svom.messaging.httpio import HttpIo
from svom.messaging.utils import get_vhfdb_url
from svom.messaging.request_utils import kwargs_are_valid

log = logging.getLogger("vhfdb_client")

DEFAULT_SORT_REQUEST = "insertionTime:ASC"


def create_search(cdic={}, by_string=""):
    """Prepare request arguments

    assume that the values in the dictionary are arrays
    """
    by_crit = by_string
    for key, lval in cdic.items():
        log.info("Found in %s, %s in dictionary", key, lval)
        if isinstance(lval, list):
            # loop over values in list values
            for val in lval:
                log.info("Analyzing %s", val)
                # Add ":" in front of value if operator is not specified
                if isinstance(val, str) and val[0] in [">", "<", ":"]:
                    by_crit += f",{key}{val}"
                else:
                    by_crit += f",{key}:{val}"
        else:
            # Add ":" in front of value if operator is not specified
            if isinstance(lval, str) and lval[0] in [">", "<", ":"]:
                by_crit += f",{key}{lval}"
            else:
                by_crit += f",{key}:{lval}"

    if len(by_string) == 0:
        return by_crit[1:]
    return by_crit


class VhfDbIo(HttpIo):
    """
    (A)synchronous HTTP client with the VHF Database.

    Parameters
    ----------
    server_url :  str, optional
        root server url share by all the endpoints
    max_tries : int, optional
        Number of connection attemps
    asynchronous : bool, optional
        True if asynchronous communication
    loop : optional
        asyncio event loop to use if asynchronous is True. If none, start one.
    use_tokens : bool, optional
        True if Authorization token has to be used
    tokens : dict, optional
        if not None, these tokens will be used instead of requesting keycloak,
        except if the tokens is not valid anymore
    """

    def __init__(
        self,
        server_url="https://fsc.svom.org/vhfdb",  # pylint: disable=R0913
        max_tries=5,
        asynchronous=False,
        loop=None,
        use_tokens=True,
        tokens=None,
    ):
        server_url = get_vhfdb_url(server_url)
        super().__init__(
            server_url,
            max_tries=max_tries,
            asynchronous=asynchronous,
            loop=loop,
            use_tokens=use_tokens,
            tokens=tokens,
        )
        self.endpoints = {
            "packets": "/api/vhf/packets",
            # "rawpackets": "/api/vhf/rawpackets",
            "raw": "/api/vhf/raw",
            "data": "/api/vhf/data",
            "apids": "/api/apids",
            "bursts": "/api/bursts",
            "stations": "/api/stations",
            "schedulers": "/api/schedulers",
        }

        headers_application = "application/json"
        self.headers = {
            "Content-Type": headers_application,
            "Accept": headers_application,
        }
        self.orig_headers = {
            "Content-Type": headers_application,
            "Accept": headers_application,
        }

    def search_data(
        self,
        since=None,
        until=None,
        page=0,
        size=1000,
        sort=DEFAULT_SORT_REQUEST,
        timeformat="iso",
        **kwargs,
    ):
        """Request and export data from svom.messaging.he database in json format

        available values for timeformat: "iso", "sec" or "svom".

        This request requires at least since/until or hash or burstid not None.

        [svom] = this format implies that the used time will be the packet time
        in the queries. The packet time is in seconds (so [svom] format represent
        seconds from svom.messaging.VOM epoch).

        For time request, use the timefield key for specifiying the time
        name on which the query is made and the timeformat to indicate the format.
        Possible name: packetTime, insertionTime, default is insertionTime.
        Example: search_data(timefield="packetTime", since="2020-01-30T10:00:00")

        If the timeformat is equal to iso, by default since and until are in
        local time machine, automatically convert to UTC. If you want to
        specified the timezone, you should add a + at then end of the string
        like in the following for time zone UTC+2:
        since="2017-01-01T01:15:10+02:00".

        *Addtional valid filters for the request in kwargs : apid, apidname, obsid,
        obsidnum, obsidtype, burstid, isdup, timefield, isvalid, station, hash*

        Parameters
        ----------
        since : string, optional
            start time specify in timefield
        until : string, optional
            end time specify in timefield
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        timeformat : str, optional
            dateformat for the time argument search. Can be sec, svom or iso
            (Python ISO format string YYYY-MM-DDTHH:MM:SS).
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            VHF DB response
        """
        valid_filters = [
            "apid",
            "apidname",
            "obsid",
            "obsnum",
            "obstype",
            "burstid",
            "isdup",
            "timefield",
            "isvalid",
            "station",
            "hash",
        ]

        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}
        # prepare request arguments
        criteria = {
            "timeformat": timeformat,
            "timefield": "insertionTime",
            "page": page,
            "size": size,
            "sort": sort,
        }
        for key, value in kwargs.items():
            criteria[key] = value

        # define output fields
        if (
            (since is None or until is None)
            and "hash" not in criteria
            and "burstid" not in criteria
        ):
            log.error("This request requires at least since/until or hash or burstid not None")
            return {}
        if timeformat == "iso" and since is not None:
            date_time = datetime.datetime
            strf_time = (
                date_time.fromisoformat(since).astimezone(pytz.utc).strftime("%Y%m%dT%H%M%S%Z")
            )
            since = strf_time
        if timeformat == "iso" and until is not None:
            date_time = datetime.datetime
            strf_time = (
                date_time.fromisoformat(until).astimezone(pytz.utc).strftime("%Y%m%dT%H%M%S%Z")
            )
            until = strf_time
        if since is not None:
            criteria["since"] = since
            criteria["until"] = until
        # send request
        resp = self.get(self.endpoints["data"], params=criteria, headers=self.orig_headers)
        return resp

    def search_raw(
        self,
        since=None,
        until=None,
        page=0,
        size=100,
        sort=DEFAULT_SORT_REQUEST,
        timeformat="iso",
        **kwargs,
    ):
        """Request and export raw data from svom.messaging.he database in json format

        usage example: search_raw(since=100000000, until=200000000)
        ?since=100000000&until=200000000”

        Time request is permitted only on the insertionTime.

        If the timeformat is equal to iso, by default since and until are in
        local time machine, automatically convert to UTC. If you want to
        specified the timezone, you should add a + at then end of the string
        like in the following for time zone UTC+2:
        since="2017-01-01T01:15:10+02:00".

        *Addtional valid filters for the request in kwargs : flag*

        Parameters
        ----------
        since : string, optional
            minimal insertion time
        until : string, optional
            maximal insertion time
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        timeformat : str, optional
            dateformat for the time argument search. Can be ms or
            yyyyMMdd""T""HHmmssz".
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            VHF DB response
        """
        # define output fields
        valid_filters = ["flag"]

        # define output fields
        if since is None or until is None:
            log.error(
                "Cannot query data without range in time: {since} - {until} (yyyyMMddTHHmmssz for "
                "iso)"
            )
            return {}

        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}
        # prepare request arguments
        criteria = {"timeformat": timeformat, "page": page, "size": size, "sort": sort}
        for key, value in kwargs.items():
            criteria[key] = value

        if timeformat == "iso" and since is not None:
            date_time = datetime.datetime
            strf_time = (
                date_time.fromisoformat(since).astimezone(pytz.utc).strftime("%Y%m%dT%H%M%S%Z")
            )
            since = strf_time
        if timeformat == "iso" and until is not None:
            date_time = datetime.datetime
            strf_time = (
                date_time.fromisoformat(until).astimezone(pytz.utc).strftime("%Y%m%dT%H%M%S%Z")
            )
            until = strf_time

        criteria["since"] = since
        criteria["until"] = until

        # send request
        resp = self.get(self.endpoints["raw"], params=criteria)
        return resp

    def search_bursts(
        self,
        since=None,
        until=None,
        page=0,
        size=100,
        timeformat="iso",
        sort=DEFAULT_SORT_REQUEST,
        **kwargs,
    ):
        """Request and export burst data from svom.messaging.he database in json format

        usage example: search_bursts(apidname="TmVhfEclairsAlert", obsid=1002)
        ?apidname=TmVhfEclairsAlert&obsid=1002”

        available values for timeformat: "iso", "sec" or "svom".

        [svom] = this format implies that the used time will be the packet time
        in the queries. The packet time is in seconds (so [svom] format represent
        seconds from svom.messaging.VOM epoch).

        For time request, use the timefield key for specifiying the time
        name on which the query is made and the timeformat to indicate the format.
        Possible name: packetTime, tb0, t0 and insertionTime, default is insertionTime.
        Example: search_data(timefield="packetTime", since="2020-01-30T10:00:00")

        If the timeformat is equal to iso, by default since and until are in
        local time machine, automatically convert to UTC. If you want to
        specified the timezone, you should add a + at then end of the string
        like in the following for time zone UTC+2:
        since="2017-01-01T01:15:10+02:00".

        *Addtional valid filters for the request in kwargs : apid, apidname, obsid, obsidnum,
        obsidtype, burstid, isdup, timefield, isvalid, station, hash*

        Parameters
        ----------
        since : string, optional
            start time specify in timefield
        until : string, optional
            end time specify in timefield
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        timeformat : str, optional
            dateformat for the time argument search. Can be sec, svom or iso
            (Python ISO format string YYYY-MM-DDTHH:MM:SS).
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            VHF DB response
        """
        # define output fields
        valid_filters = ["apidname", "obsid", "burstid", "timefield"]

        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}
        # prepare request arguments
        criteria = {
            "timeformat": timeformat,
            "timefield": "insertionTime",
            "page": page,
            "size": size,
            "sort": sort,
        }
        for key, value in kwargs.items():
            criteria[key] = value

        if timeformat == "iso" and since is not None:
            date_time = datetime.datetime
            strf_time = (
                date_time.fromisoformat(since).astimezone(pytz.utc).strftime("%Y%m%dT%H%M%S%Z")
            )
            since = strf_time
        if timeformat == "iso" and until is not None:
            date_time = datetime.datetime
            strf_time = (
                date_time.fromisoformat(until).astimezone(pytz.utc).strftime("%Y%m%dT%H%M%S%Z")
            )
            until = strf_time

        criteria["since"] = since
        criteria["until"] = until

        # send request
        resp = self.get(self.endpoints["bursts"], params=criteria)
        return resp

    def search_apid_info(self, page=0, size=100, sort="name:ASC", **kwargs):
        """Request and export apid data from svom.messaging.he database in json format

        usage example: search_apid_info(name="ECL")
        ?by=name:ECL”

        *Addtional valid filters for the request in kwargs : id, name and
        description.*

        Parameters
        ----------
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            VHF DB response
        """
        # define output fields
        valid_filters = ["apid", "name", "description"]

        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}

        # prepare request arguments
        criteria = {"page": page, "size": size, "sort": sort}
        for key, value in kwargs.items():
            criteria[key] = value
        # send request
        resp = self.get(self.endpoints["apids"], params=criteria)
        return resp

    def get_apid_info(self, apid=None):
        """Request and export apid info data from svom.messaging.he database in json format

        usage example:

        ::

            get_apid_info(apid=576)

        Parameters
        ----------
        apid : int, optional
            apid for which we want the info

        Returns
        -------
        out : int
          VHF DB response status code
        """
        resp = self.get(f"{self.endpoints['apids']}/{apid}")
        out = resp.json()
        if resp.status_code >= 400:
            out["code"] = resp.status_code
        return out

    def search_stations(self, page=0, size=100, sort="name:ASC", **kwargs):
        """Request and export data from svom.messaging.he database in json format

        usage example: search_stations(name="ECL")
        ?name=ECL”

        *Addtional valid filters for the request in kwargs : stationId, name,
        idstation, loc and location.*

        Parameters
        ----------
        page : int, optional
            page number we want for the request
        size : int, optional
            element resources size on the page for the request
        sort : string, optional
            sorting element for the request
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            VHF DB response
        """
        # define output fields
        valid_filters = ["id", "name", "location"]

        # check request validity
        if not kwargs_are_valid(kwargs, valid_filters):
            return {}

        # prepare request arguments
        criteria = {"page": page, "size": size, "sort": sort}
        for key, value in kwargs.items():
            criteria[key] = value

        # send request
        resp = self.get(self.endpoints["stations"], params=criteria)
        return resp

    def create_apid(self, name=None, apid=0, **kwargs):
        """Create apid data into the database in json format.

        *Additional valid filters for the request in kwargs : description, className,
        instrument, category, expectedPackets, productName and priority.*

        usage example:

        ::

            create_apid(name="ECLALERTL1", apid=576,
            className="some class",packetDescription="alert eclairs",instrument="ECLAIRS",
            expectedPackets=1,priority=1)

        Parameters
        ----------
        name : str
            apid name to be created
        apid : int
            apid value to be created
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            VHF DB response
        """
        # define output fields
        valid_fields = [
            "description",
            "className",
            "instrument",
            "category",
            "expectedPackets",
            "productName",
            "priority",
        ]

        # check request validity
        if not kwargs_are_valid(kwargs, valid_fields):
            return {}

        # prepare request arguments
        body_req = {
            "name": name,
            "apid": apid,
            "description": f"A packet {name}",
            "className": "None",
            "instrument": "",
            "alias": "",
            "details": "",
            "category": "VHF",
            "expectedPackets": 1,
            "productName": "",
            "priority": -1,
        }
        for key, val in kwargs.items():
            body_req[key] = val
        log.info("Create apid : %s", json.dumps(body_req))
        # send request
        resp = self.post(self.endpoints["apids"], json=body_req, headers=self.headers)
        return resp

    def update_apid(self, apid=0, **kwargs):
        """Update apid  into the database in json format.

        *Additional valid filters for the request in kwargs : description, className,
        instrument, category, details, alias, expectedPackets and priority*

        usage example:

        ::

            update_apid(apid=576,
            className="some new class",packetDescription="alert eclairs updated",
            instrument="ECLAIRS", expectedPackets=5,priority=5,packetName="TmVhfAlert")

        Parameters
        ----------
        apid : int
            apid value to be updated
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            VHF DB response
        """
        # define output fields
        valid_fields = [
            "name",
            "description",
            "className",
            "instrument",
            "category",
            "details",
            "alias",
            "expectedPackets",
            "priority",
        ]

        # check request validity
        if not kwargs_are_valid(kwargs, valid_fields):
            return {}

        # prepare request arguments
        body_req = self.get_apid_info(apid=apid)
        for key, val in kwargs.items():
            body_req[key] = val
        log.info("Update apid : %s", json.dumps(body_req))
        # send request
        url = f"{self.endpoints['apids']}/{body_req['apid']}"
        resp = self.put(url, json=body_req, headers=self.headers)
        return resp

    def create_station(self, mode="store", name=None, station_id=0, **kwargs):
        """Create new station into the database in json format

        *Additional valid filters for the request in kwargs : description, country,
        location, id, altitude, latitude, longitude, minElevationAngle and
        macaddress.*

        usage example:

        ::

            create_station(name="STSVOM1", id=0x1,
            ="some class",packetDescription="alert eclairs",instrument="ECLAIRS",
            expectedPackets=1,priority=1)

        Parameters
        ----------
        mode : str
            insertion mode
        name : str
            station name to be created
        station_id : int
            station id value to be created
        kwargs : dict, optional
            additional parameters given for the request. Should be in
            valid_filters.

        Returns
        -------
        resp : `requests.models.Response`
            VHF DB response
        """
        # define output fields
        valid_fields = [
            "description",
            "country",
            "location",
            "id",
            "altitude",
            "latitude",
            "longitude",
            "minElevationAngle",
            "macaddress",
        ]

        # check request validity
        if not kwargs_are_valid(kwargs, valid_fields):
            print("requested field are not in list of valid_fields")
            return {}

        # prepare request arguments
        body_req = {
            "name": name,
            "stationId": station_id,
            "description": f"A station {name}",
            "country": "PAR",
            "location": "Paris",
            "id": "0x1",
            "altitude": 0.0,
            "latitude": 0.0,
            "longitude": 0.0,
            "minElevationAngle": 0.0,
            "macaddress": (f"0.0.0.{station_id}"),
        }
        for key, val in kwargs.items():
            body_req[key] = val
        # send request
        print("Sending request")

        if "store" == mode:
            log.info("Create station : %s", json.dumps(body_req))
            resp = self.post(self.endpoints["stations"], json=body_req, headers=self.headers)
        else:
            log.info("Update station : %s", json.dumps(body_req))
            resp = self.put(
                self.endpoints["stations"] + ("/%d" % station_id),
                json=body_req,
                headers=self.headers,
            )
        return resp

    def update_scheduler(self, name=None, status="DISABLED"):
        """Update vhf_scheduler into the database in json format

        It is used to activate or desactivate the vhf_scheduler (there is 2 running)
        to launch the notifications and to move to non-decoded packet.

        usage example:

        ::

            update_scheduler(name="ApidChecker", status="ACTIVE")
        """
        # prepare request arguments
        log.info("Update scheduler : %s to status %s", name, status)
        # send request
        criteria = {"status": status}
        url = f"{self.endpoints['schedulers']}/{name}"
        resp = self.put(url, params=criteria, headers=self.headers)
        return resp
