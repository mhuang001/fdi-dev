from svom.messaging import SdbIo

import sys
import logging

log = logging.getLogger('sub_example')
logging.basicConfig(stream=sys.stdout, level=logging.INFO, \
                    format='%(asctime)s %(levelname)s [%(name)s] %(message)s')

#SdbIO connection
sdb = SdbIo(import_url=" https://fsc.svom.org/sdb-import",
            export_url='https://fsc.svom.org/sdb')

# Dictionary with the parameters defining the product you are interested in
request_param={"acronym":"QCL_ECL",
                "burst_id" : "sb22042733"}
json_resp = sdb.search(**request_param,
                       outputs=['product_id', 'added_at', 'criteria',
                                'update_nb']).json()
# Number of files inserted in the SDB for the product
product_nb = len(json_resp)
string_product_request=""
for key_param in request_param:
    string_product_request+=f"{key_param} {request_param[key_param]}, "
log.info(f"For {string_product_request} {product_nb} files(s) were inserted in the SDB:")

n_sent_msg = 0

for product in json_resp:
    # The number of notification is at least equal to the number of files.
    # Since at each update a notification is sent, if multiple files, we check
    # the number of times each file were updated to know the number of
    # notifications. To the number of files, we add the number of updates per
    # file.
    update_nb = product['update_nb']
    n_sent_msg = n_sent_msg + 1
    n_sent_msg = n_sent_msg + update_nb
    log.info(
        f"Product ID {product['product_id']}, added at {product['added_at']} "
        f"with a processing version of "
        f"{product['criteria']['PrimaryHDU']['PROC_VER']} and a number "
        f"of update of {update_nb}")


log.info(
    f"There are {n_sent_msg} notification(s) sent to the CSC")
